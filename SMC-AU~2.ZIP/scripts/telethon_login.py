"""One-time Telethon session string generator.

    python scripts/telethon_login.py

Prints a session string — copy it into TELETHON_SESSION_STRING in .env.
"""
from __future__ import annotations

from telethon import TelegramClient
from telethon.sessions import StringSession

if __name__ == "__main__":
    api_id = int(input("API ID: "))
    api_hash = input("API hash: ").strip()
    with TelegramClient(StringSession(), api_id, api_hash) as client:
        print("\nTELETHON_SESSION_STRING=" + client.session.save())
