"""Replay recorded signal messages through the parser + chain detect.

Usage:
    python scripts/replay_calls.py [path/to/calls.json]
Default: data/sample_calls.json

Runs offline — network calls are optional. Passing ``--net`` also queries
DexScreener to enrich the report.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

# Allow running via `python scripts/replay_calls.py` from repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.chain.detect import detect_chain_and_pool
from app.signals.parser import parse_message


async def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default="data/sample_calls.json")
    ap.add_argument("--net", action="store_true", help="query DexScreener")
    args = ap.parse_args()

    with open(args.path, "rb") as fh:
        data = json.load(fh)

    msgs = data.get("messages") or []
    n = len(msgs)
    parsed_rows = []
    for m in msgs:
        text = m.get("text", "")
        p = parse_message(text)
        parsed_rows.append((m.get("ts"), text, p))

    n_parsed = sum(1 for _, _, p in parsed_rows if p)
    n_evm = sum(1 for _, _, p in parsed_rows if p and p.chain == "evm")
    n_sol = sum(1 for _, _, p in parsed_rows if p and p.chain == "solana")

    print(f"input:   {n} messages")
    print(f"parsed:  {n_parsed}   (evm={n_evm}, solana={n_sol}, ignored={n - n_parsed})")
    print()

    for ts, text, p in parsed_rows:
        if p is None:
            print(f"  SKIP  {ts}  {text!r}")
            continue
        line = f"  CALL  {ts}  {p.chain:<6}  {p.ca}"
        if args.net:
            info = await detect_chain_and_pool(p.ca, p.chain)
            liq = f"${info.liquidity_usd:,.0f}" if info.liquidity_usd else "?"
            sym = info.symbol or "?"
            line += f"   → detected={info.chain}  liq={liq}  sym={sym}"
        print(line)


if __name__ == "__main__":
    asyncio.run(main())
