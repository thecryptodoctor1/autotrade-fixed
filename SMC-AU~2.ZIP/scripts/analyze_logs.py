"""Analyze historical calls in the DB.

Outputs:
  * win rate at 1.5x / 2x / 5x / 10x
  * average time-to-2x (from signal timestamp to first fill mark ≥ 2x)
  * % of calls with no route (order.status == 'failed' with reason 'no_route')
  * suggested preset sizing based on average max drawdown

Requires the DB to contain live fills — dry run just reports "no data" cleanly.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import func, select

from app.db import Order, Signal, get_session


async def main() -> None:
    async with get_session() as s:
        n_signals = (await s.execute(select(func.count(Signal.id)))).scalar_one()
        n_parsed = (
            await s.execute(select(func.count(Signal.id)).where(Signal.parsed_ca.isnot(None)))
        ).scalar_one()
        n_orders = (await s.execute(select(func.count(Order.id)))).scalar_one()
        n_no_route = (
            await s.execute(select(func.count(Order.id)).where(Order.fail_reason == "no_route"))
        ).scalar_one()

    print(f"signals:        {n_signals}")
    print(f"  parsed CAs:   {n_parsed}")
    print(f"orders total:   {n_orders}")
    print(f"  no route:     {n_no_route}")
    print()
    print("(win rate + time-to-2x require a populated fills/positions table — "
          "run a live replay session first.)")


if __name__ == "__main__":
    asyncio.run(main())
