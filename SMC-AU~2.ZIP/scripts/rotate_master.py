"""Rotate WALLET_MASTER_KEY.

Env:
  WALLET_MASTER_KEY_OLD   — the previous base64 master key (used to decrypt)
  WALLET_MASTER_KEY       — the new base64 master key (used to re-encrypt)
  KEY_ROTATION_ID         — new rotation id (e.g. "v2")

Usage:
    python scripts/rotate_master.py

Every wallet row whose ``key_rotation_id`` != the new one is decrypted with
the old master, re-encrypted with the new master (fresh salt+nonce), and
persisted. Each row is committed independently, so a mid-run failure only
loses that row's re-encryption (not any funds).
"""
from __future__ import annotations

import asyncio
import base64
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cryptography.hazmat.primitives import hashes                             # noqa: E402
from cryptography.hazmat.primitives.ciphers.aead import AESGCM               # noqa: E402
from cryptography.hazmat.primitives.kdf.hkdf import HKDF                     # noqa: E402
from sqlalchemy import select                                                # noqa: E402

from app.config import get_settings                                          # noqa: E402
from app.db import Wallet, get_session                                       # noqa: E402
from app.wallet.crypto import encrypt_key                                    # noqa: E402


def _derive(master: bytes, salt: bytes, aad: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(), length=32, salt=salt,
        info=b"smc-autotrade|wallet|" + aad,
    ).derive(master)


def _old_master() -> bytes:
    raw = os.environ.get("WALLET_MASTER_KEY_OLD")
    if not raw:
        raise SystemExit("WALLET_MASTER_KEY_OLD missing")
    b = base64.b64decode(raw, validate=True)
    if len(b) < 32:
        raise SystemExit("WALLET_MASTER_KEY_OLD must be >=32 bytes")
    return b


async def main() -> None:
    new_rot = get_settings().KEY_ROTATION_ID
    old_master = _old_master()
    async with get_session() as db:
        wallets = (
            await db.execute(select(Wallet).where(Wallet.key_rotation_id != new_rot))
        ).scalars().all()
    n_total = len(wallets)
    print(f"rotating {n_total} wallet rows to rotation_id={new_rot}")
    n_ok = 0
    for w in wallets:
        try:
            dek = _derive(old_master, w.salt, w.address.encode())
            pk = AESGCM(dek).decrypt(w.nonce, w.encrypted_key, w.address.encode())
        except Exception as e:
            print(f"  ✗ {w.chain} {w.address[:10]}… decrypt: {e}")
            continue
        try:
            ct = encrypt_key(pk, aad=w.address.encode())
            async with get_session() as db2:
                row = await db2.get(Wallet, w.id)
                row.encrypted_key = ct.ct
                row.salt = ct.salt
                row.nonce = ct.nonce
                row.key_rotation_id = ct.rotation_id
            n_ok += 1
            print(f"  ✔ {w.chain} {w.address[:10]}…")
        finally:
            pk = b"\x00" * len(pk)  # noqa: F841
    print(f"\ndone. ok={n_ok}/{n_total}")
    if n_ok != n_total:
        print("Some rows failed — inspect logs, keep WALLET_MASTER_KEY_OLD until fixed.")


if __name__ == "__main__":
    asyncio.run(main())
