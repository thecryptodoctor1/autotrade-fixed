/**
 * SMC AutoTrade · drop-in widget
 * ─────────────────────────────────
 * Paste this on memesolana.com (or anywhere):
 *
 *   <div id="smc-autotrade-widget"></div>
 *   <script src="https://YOUR_VPS_IP:8080/widget.js"></script>
 *
 * That's it. The widget will auto-render live stats + CTA button.
 */
(function () {
  const API_ROOT = document.currentScript.src.replace(/\/widget\.js.*$/, "");
  const TARGET_ID = "smc-autotrade-widget";
  const BOT_URL = "https://t.me/autotrade_smc_bot";

  function css(id) {
    if (document.getElementById(id)) return;
    const s = document.createElement("style");
    s.id = id;
    s.textContent = `
      .smc-w { font-family: system-ui, sans-serif; color: #eaf0f6; max-width: 480px;
               background: linear-gradient(135deg, #14181d, #1a1f26); border: 1px solid #2a3038;
               border-radius: 14px; padding: 20px; margin: 12px 0; }
      .smc-w h4 { margin: 0 0 4px; font-size: 16px; }
      .smc-w .sub { color: #7a8896; font-size: 12px; margin-bottom: 14px; }
      .smc-w .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 14px; }
      .smc-w .box { background: rgba(255,255,255,.03); padding: 10px; border-radius: 8px; }
      .smc-w .val { font-size: 22px; font-weight: 700; }
      .smc-w .val.g { color: #48dc82; }
      .smc-w .val.gold { color: #ffb544; }
      .smc-w .lab { color: #7a8896; font-size: 11px; text-transform: uppercase; letter-spacing: .5px; }
      .smc-w a.cta { display: block; text-align: center; background: linear-gradient(135deg, #8b5cf6, #6366f1);
                     color: #fff; padding: 12px; border-radius: 10px; font-weight: 700; text-decoration: none;
                     margin-top: 4px; }
      .smc-w a.cta:hover { opacity: .9; }
      .smc-w .foot { color: #7a8896; font-size: 10px; margin-top: 10px; text-align: center; }
    `;
    document.head.appendChild(s);
  }

  async function render() {
    const target = document.getElementById(TARGET_ID);
    if (!target) return;
    css("smc-w-style");
    try {
      const r = await fetch(API_ROOT + "/api/stats");
      const d = await r.json();
      const w7 = d.windows["7d"] || {};
      const roi = w7.roi_pct_100usd || 0;
      const roiSign = roi > 0 ? "+" : "";
      target.innerHTML = `
        <div class="smc-w">
          <h4>⚡ SMC AutoTrade · Live</h4>
          <div class="sub">Auto-buys every SMC call · $49/mo · Multi-chain</div>
          <div class="stats">
            <div class="box">
              <div class="lab">$100 → 7 days</div>
              <div class="val gold">$${(w7.ending_value_100usd || 100).toFixed(0)}</div>
              <div class="lab" style="margin-top:2px;">${roiSign}${roi.toFixed(0)}% ROI</div>
            </div>
            <div class="box">
              <div class="lab">Hit rate @ 2x</div>
              <div class="val g">${((w7.wr_2x || 0) * 100).toFixed(0)}%</div>
              <div class="lab" style="margin-top:2px;">${w7.n_signals || 0} signals</div>
            </div>
          </div>
          <a class="cta" href="${BOT_URL}" target="_blank">🚀 Start Auto-Trading</a>
          <div class="foot">${d.active_subs} active subscribers · ${d.total_signals} lifetime signals</div>
        </div>
      `;
    } catch (e) {
      target.innerHTML = `<div class="smc-w"><h4>⚡ SMC AutoTrade</h4><a class="cta" href="${BOT_URL}" target="_blank">🚀 Start on Telegram</a></div>`;
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", render);
  } else {
    render();
  }
  // refresh every 5 minutes
  setInterval(render, 300000);
})();
