# SMC AutoTrade

Telegram bot that auto-buys every contract address posted in a watched signal
channel, applies a built-in exit ladder (recover initials @2x, take profits at
3x / 5x, trail after runners, hard SL before 2x), and charges $49 / 30 days
per user with a referral credit.

Multi-chain out of the box: **Solana** (via Jupiter) + **EVM: ETH / Base / BSC /
Arbitrum** (via 0x). No GMGN key required.

> **Risk warning.** Memecoins can and often do go to zero. This bot buys raw
> contract addresses from a signal source with **no token filter**. Only
> deposit what you can afford to lose. This is not financial advice.

---

## 1. How your money is held

* **Per-user hot wallet.** On `/start` the bot generates a Solana keypair AND
  an EVM keypair for the user. There is no shared hot wallet.
* **Private keys are encrypted at rest** with AES-256-GCM, keyed off
  `WALLET_MASTER_KEY` (32+ bytes) + a per-wallet salt via HKDF-SHA256. Keys
  are decrypted only in memory at sign time and dropped immediately after.
* **Export requires PIN** (Argon2id + server-side pepper). Exported keys are
  posted once in DM and auto-deleted after ~60 seconds.
* **Withdrawals** only to a user-whitelisted address set in `/settings`.
* **Pause** (`/pause`) stops entries without touching funds. Manual sells
  always work.
* **Rotating the master key** is supported — see “Rotation” below.

## 2. Repo layout

```
smc-autotrade/
├── app/
│   ├── main.py                 # entrypoint: dispatcher + workers
│   ├── config.py               # pydantic-settings, .env loader
│   ├── logging_conf.py         # structlog, redacts sensitive fields
│   ├── db/                     # SQLAlchemy async models + engine
│   ├── signals/                # Telegram ingest + CA parser
│   ├── chain/                  # detect · jupiter · 0x · prices
│   ├── wallet/                 # keypair gen · AES-GCM · Argon2 PIN
│   ├── risk/                   # SAFE/STANDARD/DEGEN presets + ladder math
│   ├── worker/                 # price poller + exit engine
│   ├── telegram/               # aiogram3 handlers + keyboards
│   ├── billing/                # subscription + referral
│   ├── pnl/                    # PIL PnL card
│   └── admin/                  # admin-only commands
├── scripts/
│   ├── replay_calls.py         # offline signal-parser replay
│   ├── analyze_logs.py         # DB stats + preset suggestions
│   └── telethon_login.py       # generate session string
├── tests/                      # parser · ladder · crypto
├── data/sample_calls.json      # real CAs from operator screenshots
├── Dockerfile · docker-compose.yml · pyproject.toml · .env.example
```

## 3. Quickstart (local, without chain)

```bash
python -m venv .venv && source .venv/bin/activate       # or .venv\Scripts\Activate.ps1
pip install -e .[dev]

cp .env.example .env
python - <<'PY'
import base64, os
print("WALLET_MASTER_KEY=" + base64.b64encode(os.urandom(32)).decode())
print("PIN_PEPPER=" + base64.b64encode(os.urandom(32)).decode())
PY
# paste those two lines into .env

# Offline parser replay (no network needed):
python scripts/replay_calls.py

# Parser + chain detect via DexScreener:
python scripts/replay_calls.py --net

# Tests
pytest -q
```

## 4. Run the bot

1. `@BotFather` → `/newbot` → copy the token into `BOT_TOKEN`. Set the
   `/setprivacy` = **Disable** so the bot can read group messages if you use
   Bot API ingest.
2. `SIGNAL_INGEST=bot_api` — add the bot to the signal group **as admin** and
   put the group id in `SIGNAL_CHAT_IDS`. Supergroup ids start with `-100…`.
3. `SIGNAL_INGEST=telethon` — run `python scripts/telethon_login.py`, paste
   the printed session string into `TELETHON_SESSION_STRING`. Use this if the
   source channel does not allow bots.
4. Set `OPERATOR_TREASURY_SOL` (your own SOL wallet) if you want to charge
   subs.
5. `docker compose up -d --build` or `python -m app.main`.

## 5. Env vars

See `.env.example`. Key ones:

| var                     | required | notes |
|-------------------------|----------|-------|
| `BOT_TOKEN`             | ✔        | @BotFather |
| `BOT_USERNAME`          | ✔        | for referral deep-links |
| `ADMIN_IDS`             | ✔        | comma-separated TG user ids |
| `SIGNAL_CHAT_IDS`       | ✔        | comma-separated; `-100…` supergroups |
| `SIGNAL_INGEST`         | ✔        | `bot_api` or `telethon` |
| `WALLET_MASTER_KEY`     | ✔        | base64 of ≥32 random bytes |
| `PIN_PEPPER`            | ✔        | base64 of ≥32 random bytes |
| `KEY_ROTATION_ID`       | ✔        | bump when rotating master key |
| `DATABASE_URL`          | ✔        | sqlite dev / postgres prod |
| `OPERATOR_TREASURY_SOL` | for subs | SOL address you own |
| `DEFAULT_RISK_PRESET`   |          | `SAFE` \| `STANDARD` \| `DEGEN` |

## 6. Risk presets

| preset   | SOL / call | EVM native / call | max open | wallet-cap | slip SOL | slip EVM | hard SL |
|----------|-----------:|------------------:|---------:|-----------:|---------:|---------:|--------:|
| SAFE     | 0.05       | 0.002             | 4        | 10 %       | 12 %     | 8 %      | −30 %   |
| STANDARD | 0.15       | 0.005             | 8        | 20 %       | 20 %     | 12 %     | −40 %   |
| DEGEN    | 0.40       | 0.015             | 15       | 40 %       | 35 %     | 20 %     | −50 %   |

Daily cap per user (default $200 equivalent). Never buys when wallet balance
< 2× the buy size + gas reserve.

## 7. Exit ladder (product edge)

For **every** fill (auto or manual):

1. **Recover initials @ 2x** — sell ≥50 % (fee-adjusted; see
   `recover_pct_for_2x` in `app/risk/ladder.py`). Remainder is house money.
2. **+25 % of remainder @ 3x**, then **+25 % of remainder @ 5x**.
3. **Notify at 10x** — no auto-sell.
4. **Trailing stop** on the leftover: 35 % under HWM after step 1, tightens
   to 25 % after 5x, 20 % after 10x.
5. **Hard SL before 2x** — 30 / 40 / 50 % below entry per preset.
6. Manual `sell 25|50|100 <ca>` overrides everything.

## 8. How subscription payments are matched

Each pending invoice gets a unique amount (base price + a small random
lamport tail). A poller lists incoming transfers to
`OPERATOR_TREASURY_SOL` and matches on exact amount. On match:
`subscribed_until = now + 30d`, referrer credit applied for the first 3
paid invoices.

## 9. Rotating `WALLET_MASTER_KEY`

You cannot decrypt old ciphertexts without the old master. The rotation
runbook:

1. Set `KEY_ROTATION_ID=v2` and `WALLET_MASTER_KEY_OLD=<old base64>`.
2. Run `python scripts/rotate_master.py` (stub — implement when needed).
   Each wallet row is re-decrypted with the old key, re-encrypted with the
   new master + new salt, `key_rotation_id` bumped, all in one transaction
   per row.
3. Verify: `SELECT chain, count(*) FROM wallets GROUP BY key_rotation_id;`
   should show only `v2`.
4. Remove `WALLET_MASTER_KEY_OLD` from env.

Back up both `WALLET_MASTER_KEY` and the DB. If you lose either, funds in
the per-user hot wallets are unrecoverable except by the user via their
exported key.

## 10. Roadmap

* Chain-specific fill parsers (real cost basis from tx receipts, not
  aggregator quote).
* Turnkey / Privy integration as the “default” custody path (users keep an
  MPC key; bot only holds a signer share).
* GMGN intel flag (`FEATURES_GMGN=true` + `GMGN_API_KEY`) — read-only token
  security warnings on the receipt, still non-blocking.
* Solana pump.fun local-fee-program fallback for tokens without a Jupiter
  route.
* Base + BSC token approvals + sell path (currently native-→-token buys
  only in the code path).
* Per-user gas price + priority tuning.

---

## Launch checklist (20 minutes)

1. `WALLET_MASTER_KEY` and `PIN_PEPPER` generated with `os.urandom(32)`,
   stored in a password manager and backed up.
2. `BOT_TOKEN` from BotFather, `/setprivacy = Disable`, `/setjoingroups =
   Enable`.
3. `SIGNAL_CHAT_IDS` filled and the bot added as admin, OR
   `TELETHON_SESSION_STRING` generated and pasted.
4. `OPERATOR_TREASURY_SOL` set to a Solana address **you** control.
5. `ADMIN_IDS` includes your TG user id.
6. `docker compose up -d --build`; `docker logs -f smc-autotrade-bot-1`.
7. DM the bot → `/start` → wallet card appears → send yourself 0.01 SOL as
   a smoke test.
8. `pytest -q` all green.
9. `python scripts/replay_calls.py --net` shows the 11 real CAs parsed
   correctly, `/ga 3d` skipped, DexScreener returning liquidity data.
10. Grant yourself a test sub: `/admin_grant <your_tg_id> 30`.
11. Post a test CA in the signal channel from a second account. Watch the
    bot log the signal and (once buy execution is wired) the receipt hit
    your DM.
12. Monitor `docker logs` for any `WARNING`/`ERROR`, especially around key
    encryption + swap quotes.
