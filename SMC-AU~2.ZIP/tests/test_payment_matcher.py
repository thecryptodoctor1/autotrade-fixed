"""Payment matcher parsing — no network required."""
from __future__ import annotations

from app.billing.payment_matcher import _treasury_credit_lamports

TREASURY = "TreasuryAddr11111111111111111111111111111111"


def test_credit_positive_delta():
    tx = {
        "meta": {
            "err": None,
            "preBalances": [1_000_000_000, 5_000],
            "postBalances": [1_000_000_000 + 493_712, 5_000],
        },
        "transaction": {
            "message": {"accountKeys": [TREASURY, "OtherAcct"]},
        },
    }
    assert _treasury_credit_lamports(tx, TREASURY) == 493_712


def test_credit_ignores_failed_tx():
    tx = {
        "meta": {
            "err": {"InstructionError": [0, "Custom"]},
            "preBalances": [0, 1],
            "postBalances": [1_000_000_000, 1],
        },
        "transaction": {"message": {"accountKeys": [TREASURY]}},
    }
    assert _treasury_credit_lamports(tx, TREASURY) is None


def test_credit_accepts_pubkey_dict_encoding():
    tx = {
        "meta": {
            "err": None,
            "preBalances": [100, 200],
            "postBalances": [100, 200 + 42],
        },
        "transaction": {
            "message": {
                "accountKeys": [
                    {"pubkey": "OtherAcct"},
                    {"pubkey": TREASURY},
                ]
            }
        },
    }
    assert _treasury_credit_lamports(tx, TREASURY) == 42
