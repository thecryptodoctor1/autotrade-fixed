"""Ladder math + recovery-at-2x fee model."""
from __future__ import annotations

import pytest

from app.risk.ladder import build_ladder, recover_pct_for_2x, tighten_trail_after
from app.risk.presets import PRESETS


def test_recover_fraction_defaults_to_at_least_half() -> None:
    # No fees → exactly 50%. Realistic fees → slightly more than 50%.
    assert recover_pct_for_2x(0.0) == pytest.approx(0.5, abs=1e-9)
    assert recover_pct_for_2x(0.035) > 0.5
    assert recover_pct_for_2x(0.05) < 0.75  # capped


def test_recover_fraction_returns_cost_basis_at_2x() -> None:
    # Simulate: buy 1 native worth (cost basis after 3.5% fee = 1/(1-0.035))
    # Sell fraction f at 2x with the same fee bite. Net native ≥ cost basis.
    fee = 0.035
    f = recover_pct_for_2x(fee)
    cost_basis = 1.0 / (1 - fee)
    gross_at_2x = 2.0 * f
    net = gross_at_2x * (1 - fee)
    assert net >= cost_basis - 1e-6


def test_build_ladder_has_all_rungs() -> None:
    plan = build_ladder("STANDARD")
    rules = [r.rule for r in plan.rungs]
    assert "sl" in rules
    assert "recover" in rules
    assert "tp3x" in rules
    assert "tp5x" in rules
    assert "notify10x" in rules
    assert "trail" in rules


@pytest.mark.parametrize("preset,expected_sl_mult", [
    ("SAFE", 1.0 - 0.30),
    ("STANDARD", 1.0 - 0.40),
    ("DEGEN", 1.0 - 0.50),
])
def test_hard_sl_matches_preset(preset: str, expected_sl_mult: float) -> None:
    plan = build_ladder(preset)
    sl = next(r for r in plan.rungs if r.rule == "sl")
    assert sl.trigger_mult == pytest.approx(expected_sl_mult)


def test_trail_tightens_after_stages() -> None:
    assert tighten_trail_after("recover") == 0.35
    assert tighten_trail_after("tp5x") == 0.25
    assert tighten_trail_after("notify10x") == 0.20
    assert tighten_trail_after("tp3x") is None


def test_presets_are_ordered() -> None:
    assert (
        PRESETS["SAFE"].sol_size_native
        < PRESETS["STANDARD"].sol_size_native
        < PRESETS["DEGEN"].sol_size_native
    )
    assert (
        PRESETS["SAFE"].hard_sl_pct
        < PRESETS["STANDARD"].hard_sl_pct
        < PRESETS["DEGEN"].hard_sl_pct
    )
