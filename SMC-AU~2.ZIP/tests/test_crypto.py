"""Wallet crypto round-trip + PIN checks."""
from __future__ import annotations

import base64
import os

import pytest


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setenv("WALLET_MASTER_KEY", base64.b64encode(os.urandom(32)).decode())
    monkeypatch.setenv("PIN_PEPPER", base64.b64encode(os.urandom(32)).decode())
    monkeypatch.setenv("KEY_ROTATION_ID", "v1")
    # Clear settings cache since our fixture ran after import.
    from app.config import get_settings
    get_settings.cache_clear()   # type: ignore[attr-defined]


def test_encrypt_decrypt_roundtrip() -> None:
    from app.wallet.crypto import decrypt_key, encrypt_key

    pk = os.urandom(64)
    ct = encrypt_key(pk, aad=b"testaddr")
    out = decrypt_key(ct.ct, ct.nonce, ct.salt, aad=b"testaddr")
    assert out == pk
    assert ct.rotation_id == "v1"


def test_decrypt_with_wrong_aad_fails() -> None:
    from app.wallet.crypto import WalletCryptoError, decrypt_key, encrypt_key

    pk = os.urandom(32)
    ct = encrypt_key(pk, aad=b"addrA")
    with pytest.raises(WalletCryptoError):
        decrypt_key(ct.ct, ct.nonce, ct.salt, aad=b"addrB")


def test_pin_hash_verify() -> None:
    from app.wallet.pin import check_pin_rules, hash_pin, verify_pin

    assert check_pin_rules("abcd") == "PIN must be 4–8 digits."
    assert check_pin_rules("123") == "PIN must be 4–8 digits."
    assert check_pin_rules("123456") is None
    h = hash_pin("123456")
    assert verify_pin("123456", h) is True
    assert verify_pin("654321", h) is False


def test_ref_code_format() -> None:
    from app.wallet.pin import gen_ref_code

    code = gen_ref_code()
    assert 6 <= len(code) <= 12
    # URL-safe base64 charset
    assert all(c.isalnum() or c in "-_" for c in code)
