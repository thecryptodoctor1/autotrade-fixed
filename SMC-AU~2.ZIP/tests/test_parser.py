"""Parser tests using the real CAs from the operator screenshots."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.signals.parser import parse_message

CORPUS = json.loads((Path(__file__).parent.parent / "data" / "sample_calls.json").read_text())


@pytest.mark.parametrize(
    "text,expected_chain,expected_ca",
    [
        # EVM lowercase
        ("0x9ac0efe775ef5eadf1fd106a6efe19d0e1421e18", "evm", "0x9ac0efe775ef5eadf1fd106a6efe19d0e1421e18"),
        # EVM mixed-case (checksum)
        ("0x8093BFa59969b656555283A102D01af021b78c70", "evm", "0x8093BFa59969b656555283A102D01af021b78c70"),
        # Solana base58, 44 chars
        ("7Wh6rxVWUBFCNCWCz7nLaV7z3SDr2M6rFTjWP6aE8p1", "solana", "7Wh6rxVWUBFCNCWCz7nLaV7z3SDr2M6rFTjWP6aE8p1"),
        # Solana wrapped in prose
        ("new call: DtFkKBC3Cmi9j35xBGRUd8gvBLw7nAasrvUJFB69yubM 🚀",
         "solana", "DtFkKBC3Cmi9j35xBGRUd8gvBLw7nAasrvUJFB69yubM"),
    ],
)
def test_parses_real_calls(text: str, expected_chain: str, expected_ca: str) -> None:
    p = parse_message(text)
    assert p is not None
    assert p.chain == expected_chain
    assert p.ca == expected_ca


@pytest.mark.parametrize(
    "text",
    [
        "",
        "/ga 3d",
        "/gp",
        "hello world with no addresses",
        "https://example.com just a url",
        "0xabc",             # too short EVM
        "0x" + "z" * 40,     # invalid hex
    ],
)
def test_ignores_non_calls(text: str) -> None:
    assert parse_message(text) is None


def test_sample_corpus_parses_real_addresses() -> None:
    """The bundled corpus must yield exactly 11 CAs (12 lines - 1 command)."""
    parsed = [parse_message(m["text"]) for m in CORPUS["messages"]]
    hits = [p for p in parsed if p is not None]
    assert len(CORPUS["messages"]) == 12
    assert len(hits) == 11
    # /ga 3d is the one skipped line
    skipped_idx = [i for i, p in enumerate(parsed) if p is None]
    assert skipped_idx == [2]


def test_dedup_key_is_chain_scoped() -> None:
    sol = parse_message("7Wh6rxVWUBFCNCWCz7nLaV7z3SDr2M6rFTjWP6aE8p1")
    evm = parse_message("0x9ac0efe775ef5eadf1fd106a6efe19d0e1421e18")
    assert sol.dedup_key.startswith("solana:")
    assert evm.dedup_key.startswith("evm:")


def test_solana_ignore_list_skips_system_program() -> None:
    # The system program is a valid base58 pubkey and would otherwise pass.
    assert parse_message("11111111111111111111111111111111") is None
