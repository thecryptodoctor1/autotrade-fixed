"""Paper-trade executor — mocks chain layer to prove eligibility gates + ladder attach."""
from __future__ import annotations

import base64
import os
from unittest.mock import AsyncMock, patch

import pytest

pytestmark = pytest.mark.asyncio


@pytest.fixture(autouse=True)
def _env(monkeypatch, tmp_path):
    monkeypatch.setenv("WALLET_MASTER_KEY", base64.b64encode(os.urandom(32)).decode())
    monkeypatch.setenv("PIN_PEPPER", base64.b64encode(os.urandom(32)).decode())
    monkeypatch.setenv("DATABASE_URL", f"sqlite+aiosqlite:///{tmp_path}/test.db")
    from app.config import get_settings
    get_settings.cache_clear()      # type: ignore[attr-defined]


async def _bootstrap_user(session, tg_id: int, active_sub: bool = True):
    from datetime import datetime, timedelta, timezone

    from app.db import Subscription, User, Wallet
    from app.wallet.crypto import encrypt_key
    from app.wallet.generate import generate_evm, generate_solana

    u = User(
        tg_id=tg_id, tg_username="test",
        ref_code=f"ref{tg_id}",   # unique per test
        risk_preset="STANDARD", auto_paused=False,
    )
    session.add(u)
    await session.flush()

    for chain, gen in (("solana", generate_solana), ("evm", generate_evm)):
        w = gen()
        ct = encrypt_key(w.private_key, aad=w.address.encode())
        session.add(Wallet(
            user_id=u.id, chain=chain, address=w.address,
            encrypted_key=ct.ct, salt=ct.salt, nonce=ct.nonce,
            key_rotation_id=ct.rotation_id,
        ))

    if active_sub:
        now = datetime.now(timezone.utc)
        session.add(Subscription(
            user_id=u.id, status="active", started_at=now,
            expires_at=now + timedelta(days=30),
            invoice_amount_lamports=1_000_000, invoice_memo="test",
        ))
    return u


async def test_ineligible_without_subscription():
    from app.db import Signal
    from app.db.base import create_all, get_session
    from app.worker.executor import _eligibility

    await create_all()
    async with get_session() as s:
        u = await _bootstrap_user(s, tg_id=111, active_sub=False)
        g = await _eligibility(s, u, "SoRandomCA111111111111111111111111111111111")
    assert not g.ok
    assert g.reason == "no_sub"


async def test_dedup_blocks_within_window():
    from datetime import datetime, timezone

    from app.db import Order
    from app.db.base import create_all, get_session
    from app.worker.executor import _eligibility

    await create_all()
    async with get_session() as s:
        u = await _bootstrap_user(s, tg_id=222)
        s.add(Order(
            user_id=u.id, side="buy", kind="auto",
            ca="SameCA", chain="solana", slippage_bps=2000,
            status="sent", created_at=datetime.now(timezone.utc),
        ))
        await s.flush()
        g = await _eligibility(s, u, "SameCA")
    assert not g.ok
    assert g.reason == "dedup"


async def test_paused_blocks_autobuy():
    from app.db.base import create_all, get_session
    from app.worker.executor import _eligibility

    await create_all()
    async with get_session() as s:
        u = await _bootstrap_user(s, tg_id=333)
        u.auto_paused = True
        g = await _eligibility(s, u, "AnotherCA")
    assert not g.ok
    assert g.reason == "paused"


async def test_ladder_attached_on_successful_buy():
    """Fully mock the chain layer and verify the ladder + order/fill/position are written."""
    from app.db import ExitRule, Fill, Order, Position
    from app.db.base import create_all, get_session
    from app.worker.executor import execute_buy
    from sqlalchemy import select

    await create_all()
    async with get_session() as s:
        u = await _bootstrap_user(s, tg_id=444)
        user_id = u.id

    fake_bot = AsyncMock()
    fake_bot.send_message = AsyncMock()

    # Fake Jupiter quote → swap → sign
    from app.chain import solana_jupiter
    fake_quote = solana_jupiter.JupiterQuote(
        in_amount=150_000_000, out_amount=1_000_000_000,
        price_impact_pct=0.5, route_json={"routePlan": []},
    )
    fake_info = type("I", (), dict(
        chain="solana", ca="MintFake", pool_address=None,
        liquidity_usd=200_000.0, price_usd=0.0015, dex="raydium", symbol="TEST",
    ))()

    with patch("app.worker.executor.detect_chain_and_pool", return_value=fake_info), \
         patch("app.chain.solana_jupiter.quote", return_value=fake_quote), \
         patch("app.chain.solana_jupiter.build_swap_tx", return_value=b"\x00" * 16), \
         patch("app.chain.solana_jupiter.sign_and_send", return_value="TESTSIG"):
        order = await execute_buy(
            bot=fake_bot, user_id=user_id, ca="MintFake",
            chain_hint="solana", kind="auto",
        )

    assert order.status == "sent"
    assert order.tx_sig == "TESTSIG"

    async with get_session() as s:
        pos = (await s.execute(select(Position).where(Position.user_id == user_id))).scalar_one()
        rules = (await s.execute(select(ExitRule).where(ExitRule.position_id == pos.id))).scalars().all()
        fills = (await s.execute(select(Fill).where(Fill.order_id == order.id))).scalars().all()

    assert pos.tokens_open > 0
    assert pos.avg_entry_native > 0
    rule_names = {r.rule for r in rules}
    assert {"sl", "recover", "tp3x", "tp5x", "notify10x", "trail"} <= rule_names
    assert len(fills) == 1
    assert fills[0].token_delta > 0
    fake_bot.send_message.assert_awaited()   # receipt DM'd
