"""Referral credit. Days are added to the referrer's active subscription immediately."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.config import get_settings
from app.db import Referral, Subscription, User, get_session


def _aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


async def extend_sub_days(db, user_id: int, days: int) -> bool:
    """Add days onto a live subscription. False when the user has none yet."""
    if days <= 0:
        return False
    now = datetime.now(timezone.utc)
    rows = (
        await db.execute(select(Subscription).where(Subscription.user_id == user_id))
    ).scalars().all()
    best = None
    best_exp = now
    for row in rows:
        if (row.plan or "") == "lifetime" or row.status == "lifetime":
            return True
        exp = _aware(row.expires_at)
        if row.status in ("active", "trial") and exp and exp > best_exp:
            best = row
            best_exp = exp
    if best is None:
        return False
    best.expires_at = best_exp + timedelta(days=days)
    return True


async def apply_unapplied_credit(db, user_id: int) -> int:
    """Move earned-but-not-yet-applied referral days onto this user's sub."""
    refs = (
        await db.execute(select(Referral).where(Referral.referrer_id == user_id))
    ).scalars().all()
    extra = 0
    for ref in refs:
        gap = int(ref.credit_days_earned or 0) - int(getattr(ref, "credit_days_applied", 0) or 0)
        if gap > 0:
            extra += gap
    if extra <= 0:
        return 0
    if not await extend_sub_days(db, user_id, extra):
        return 0
    for ref in refs:
        ref.credit_days_applied = int(ref.credit_days_earned or 0)
    return extra


async def credit_referrer_on_payment(referee_tg_id: int) -> None:
    s = get_settings()
    async with get_session() as db:
        referee = (
            await db.execute(select(User).where(User.tg_id == referee_tg_id))
        ).scalar_one()
        if referee.referred_by_id is None:
            return
        ref = (
            await db.execute(
                select(Referral).where(Referral.referee_id == referee.id)
            )
        ).scalar_one_or_none()
        if ref is None:
            ref = Referral(referrer_id=referee.referred_by_id, referee_id=referee.id)
            db.add(ref)
            await db.flush()
        if ref.invoices_credited >= s.REFERRAL_FIRST_N:
            return
        days = int(s.SUB_DURATION_DAYS * (s.REFERRAL_PCT / 100.0))
        ref.invoices_credited += 1
        ref.credit_days_earned += days
        if await extend_sub_days(db, referee.referred_by_id, days):
            ref.credit_days_applied = int(ref.credit_days_earned or 0)
