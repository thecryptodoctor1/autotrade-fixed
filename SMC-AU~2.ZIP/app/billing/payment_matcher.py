"""Poll the operator treasury for incoming SOL transfers and match them to
pending invoices by exact lamport amount.

Approach: every 20s, ask the RPC for the treasury account's recent signatures,
walk them newest→oldest until we hit an already-seen tx, and parse each for a
SOL transfer credited to the treasury. Match on ``invoice_amount_lamports``.

On match:
  * mark subscription active + expires_at = now + SUB_DURATION_DAYS
  * store tx sig
  * credit referrer if any (first N invoices)
  * DM the user
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from typing import Iterable

import httpx
from sqlalchemy import and_, select

from app.billing.referral import credit_referrer_on_payment
from app.config import get_settings
from app.db import Subscription, User, get_session
from app.logging_conf import log


class PaymentMatcher:
    def __init__(self, bot):
        self.bot = bot
        self._seen: set[str] = set()
        self._stop = asyncio.Event()

    async def run(self) -> None:
        s = get_settings()
        if not s.OPERATOR_TREASURY_SOL:
            log().info("payment_matcher.disabled reason=no_treasury")
            return
        log().info("payment_matcher.start treasury=%s", s.OPERATOR_TREASURY_SOL)
        while not self._stop.is_set():
            try:
                await self._tick()
            except Exception:
                log().exception("payment_matcher.tick_error")
            await asyncio.sleep(20)

    def stop(self) -> None:
        self._stop.set()

    async def _tick(self) -> None:
        s = get_settings()
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(hours=2)
        async with get_session() as db:
            invoices = (
                await db.execute(
                    select(Subscription, User).join(
                        User, User.id == Subscription.user_id
                    ).where(Subscription.status == "pending")
                )
            ).all()
            live = []
            for sub, user in invoices:
                created = sub.created_at
                if created is not None and created.tzinfo is None:
                    created = created.replace(tzinfo=timezone.utc)
                if created is not None and created < cutoff:
                    sub.status = "expired"
                    continue
                live.append((sub, user))
        if not live:
            return
        amount_map: dict[int, tuple[Subscription, User]] = {
            sub.invoice_amount_lamports: (sub, user)
            for (sub, user) in live
            if sub.invoice_amount_lamports
        }
        if not amount_map:
            return

        # 2. List recent signatures on the treasury
        sigs = await self._get_signatures(s.SOLANA_RPC, s.OPERATOR_TREASURY_SOL, limit=25)
        if not sigs:
            return

        for entry in sigs:
            sig = entry.get("signature")
            if not sig or sig in self._seen:
                continue
            tx = await self._get_tx(s.SOLANA_RPC, sig)
            self._seen.add(sig)
            if tx is None:
                continue
            # 3. Compute credit amount into the treasury
            credit = _treasury_credit_lamports(tx, s.OPERATOR_TREASURY_SOL)
            if credit is None or credit <= 0:
                continue
            hit = amount_map.get(credit)
            if not hit:
                continue
            sub, user = hit
            await self._mark_paid(sub.id, user, sig)

    async def _mark_paid(self, sub_id: int, user: User, tx_sig: str) -> None:
        from app.billing.referral import apply_unapplied_credit

        now = datetime.now(timezone.utc)
        expires_txt = ""
        lifetime = False
        async with get_session() as db:
            sub = await db.get(Subscription, sub_id)
            if sub is None or sub.status in ("active", "expired"):
                return
            lifetime = (sub.plan or "") == "lifetime"
            others = (
                await db.execute(
                    select(Subscription).where(
                        Subscription.user_id == sub.user_id,
                        Subscription.id != sub.id,
                        Subscription.status.in_(("active", "lifetime", "trial")),
                    )
                )
            ).scalars().all()
            base = now
            for other in others:
                exp = other.expires_at
                if exp is None:
                    continue
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp > base:
                    base = exp
            sub.status = "active"
            sub.started_at = sub.started_at or now
            if lifetime:
                sub.expires_at = datetime(2099, 1, 1, tzinfo=timezone.utc)
            else:
                sub.expires_at = base + timedelta(days=get_settings().SUB_DURATION_DAYS)
            sub.paid_tx_sig = tx_sig
            await apply_unapplied_credit(db, sub.user_id)
            expires_txt = "lifetime" if lifetime else f"{sub.expires_at:%Y-%m-%d}"
        await credit_referrer_on_payment(user.tg_id)
        log().info("payment.matched user=%s tx=%s", user.tg_id, tx_sig[:16])
        try:
            await self.bot.send_message(
                user.tg_id,
                f"✅ <b>Subscription active</b>\n\n"
                f"Payment confirmed: <code>{tx_sig[:20]}…</code>\n"
                f"Expires: {expires_txt}",
                parse_mode="HTML",
            )
        except Exception:
            log().warning("payment.dm_fail tg=%s", user.tg_id)

    async def _get_signatures(self, rpc: str, addr: str, limit: int = 25) -> list[dict]:
        body = {
            "jsonrpc": "2.0", "id": 1,
            "method": "getSignaturesForAddress",
            "params": [addr, {"limit": limit}],
        }
        async with httpx.AsyncClient(timeout=10.0) as cli:
            r = await cli.post(rpc, json=body)
            if r.status_code != 200:
                return []
            return (r.json() or {}).get("result") or []

    async def _get_tx(self, rpc: str, sig: str) -> dict | None:
        body = {
            "jsonrpc": "2.0", "id": 1,
            "method": "getTransaction",
            "params": [sig, {"maxSupportedTransactionVersion": 0, "encoding": "json"}],
        }
        async with httpx.AsyncClient(timeout=10.0) as cli:
            try:
                r = await cli.post(rpc, json=body)
                if r.status_code != 200:
                    return None
                return (r.json() or {}).get("result")
            except Exception:
                return None


def _treasury_credit_lamports(tx: dict, treasury: str) -> int | None:
    """Compute the lamports credited to `treasury` in this tx (post − pre)."""
    meta = tx.get("meta") or {}
    if meta.get("err") is not None:
        return None
    msg = (tx.get("transaction") or {}).get("message") or {}
    keys = msg.get("accountKeys") or []
    if not keys:
        return None
    try:
        idx = keys.index(treasury)
    except ValueError:
        # accountKeys may be dicts in newer encodings
        for i, k in enumerate(keys):
            if isinstance(k, dict) and k.get("pubkey") == treasury:
                idx = i
                break
        else:
            return None
    pre = meta.get("preBalances") or []
    post = meta.get("postBalances") or []
    if idx >= len(pre) or idx >= len(post):
        return None
    return int(post[idx]) - int(pre[idx])
