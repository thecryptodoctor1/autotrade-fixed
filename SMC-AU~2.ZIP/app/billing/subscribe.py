"""Match SOL/USDC deposits to pending subscription invoices.

Approach (simple, no extra rail): every invoice gets a unique amount with a
small random micro-lamport tail (e.g. 0.493712 SOL). A background poller
lists incoming transfers to ``OPERATOR_TREASURY_SOL`` and matches by exact
amount + unpaid pending invoice.
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.config import get_settings
from app.db import Subscription, User, get_session


def _price_in_lamports(base_usd: float, sol_usd: float) -> int:
    """USD → lamports. Adds 4 random low digits so each invoice is unique."""
    sol = base_usd / max(sol_usd, 1e-6)
    lamports = int(sol * 1_000_000_000)
    lamports += random.randint(100, 9999)
    return lamports


async def create_invoice(tg_id: int, sol_usd: float) -> Subscription:
    s = get_settings()
    async with get_session() as db:
        user = (
            await db.execute(select(User).where(User.tg_id == tg_id))
        ).scalar_one()
        old = (
            await db.execute(
                select(Subscription).where(
                    Subscription.user_id == user.id,
                    Subscription.status == "pending",
                )
            )
        ).scalars().all()
        for row in old:
            row.status = "expired"
        amount = _price_in_lamports(s.SUB_PRICE_USD, sol_usd)
        sub = Subscription(
            user_id=user.id,
            status="pending",
            invoice_amount_lamports=amount,
            invoice_memo=f"SMC-{user.id}-{amount % 10000:04d}",
        )
        db.add(sub)
        await db.flush()
        return sub


async def mark_paid(sub_id: int, tx_sig: str) -> None:
    async with get_session() as db:
        sub = await db.get(Subscription, sub_id)
        if sub is None or sub.status == "active":
            return
        now = datetime.now(timezone.utc)
        others = (
            await db.execute(
                select(Subscription).where(
                    Subscription.user_id == sub.user_id,
                    Subscription.id != sub.id,
                    Subscription.status.in_(("active", "lifetime", "trial")),
                )
            )
        ).scalars().all()
        base = now
        for other in others:
            exp = other.expires_at
            if exp is None:
                continue
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp > base:
                base = exp
        if (sub.plan or "") == "lifetime":
            sub.status = "active"
            sub.started_at = now
            sub.expires_at = datetime(2099, 1, 1, tzinfo=timezone.utc)
        else:
            sub.status = "active"
            sub.started_at = now
            sub.expires_at = base + timedelta(days=get_settings().SUB_DURATION_DAYS)
        sub.paid_tx_sig = tx_sig
        from app.billing.referral import apply_unapplied_credit
        await apply_unapplied_credit(db, sub.user_id)
