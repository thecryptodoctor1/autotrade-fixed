"""Subscription + referral bookkeeping."""
