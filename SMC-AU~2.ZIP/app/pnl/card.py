"""Render a PnL card as PNG using Pillow. Kept minimal — pretty templates later."""
from __future__ import annotations

import io
from dataclasses import dataclass

from PIL import Image, ImageDraw, ImageFont


@dataclass(slots=True)
class PnLSummary:
    handle: str
    period: str
    realized_native: float
    unrealized_native: float
    win_rate: float
    trades: int
    best_mult: float


def render_pnl_card(pnl: PnLSummary) -> bytes:
    W, H = 900, 500
    img = Image.new("RGB", (W, H), (14, 17, 22))
    d = ImageDraw.Draw(img)
    try:
        title = ImageFont.truetype("DejaVuSans-Bold.ttf", 44)
        body  = ImageFont.truetype("DejaVuSans.ttf", 28)
        big   = ImageFont.truetype("DejaVuSans-Bold.ttf", 68)
    except Exception:
        title = body = big = ImageFont.load_default()

    green = (72, 220, 130)
    red   = (232, 96, 96)
    grey  = (168, 178, 190)

    d.text((40, 30), "SMC AutoTrade · PnL", font=title, fill=(255, 255, 255))
    d.text((40, 90), f"{pnl.handle}  ·  {pnl.period}", font=body, fill=grey)

    total = pnl.realized_native + pnl.unrealized_native
    color = green if total >= 0 else red
    sign = "+" if total >= 0 else ""
    d.text((40, 160), f"{sign}{total:.4f} native", font=big, fill=color)
    d.text((40, 250), f"Realized {pnl.realized_native:+.4f}   ·   Unrealized {pnl.unrealized_native:+.4f}",
           font=body, fill=grey)
    d.text((40, 320), f"Trades {pnl.trades}   ·   Win rate {pnl.win_rate*100:.0f}%   ·   Best {pnl.best_mult:.1f}x",
           font=body, fill=grey)
    d.text((40, 430), "Not financial advice · memecoins can go to zero", font=body, fill=grey)

    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()
