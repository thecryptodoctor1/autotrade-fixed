"""SMC AutoTrade entrypoint — starts everything the bot needs to run live.

Concurrent tasks:
  * aiogram dispatcher (DMs + optional Bot API signal ingest)
  * Telethon ingest (if SIGNAL_INGEST=telethon)
  * PricePoller       — DexScreener/Jupiter marks for open positions
  * ExitEngine        — fires ladder rungs when prices cross triggers
  * PaymentMatcher    — matches incoming SOL transfers to pending invoices
"""
from __future__ import annotations

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from app.admin import router as admin_router
from app.billing.payment_matcher import PaymentMatcher
from app.config import get_settings
from app.db.base import create_all
from app.logging_conf import configure_logging, log
from app.signals.ingest_bot import router as signal_bot_router
from app.signals.ingest_telethon import run_telethon_ingest
from app.telegram.handlers import router as core_router
from app.http_server import run_http_server
from app.worker.deposit_watcher import DepositWatcher
from app.worker.exit_engine import ExitEngine
from app.worker.price_poller import PricePoller


async def _run() -> None:
    s = get_settings()
    configure_logging(s.LOG_LEVEL, s.LOG_JSON)
    await create_all()

    # Seed demo account if enabled — makes /simulate + dashboard have data on day 1
    if s.DEMO_MODE:
        try:
            from app.demo_seeder import seed_demo_if_needed
            await seed_demo_if_needed()
        except Exception:
            log().exception("demo_seed_failed")

    if not s.BOT_TOKEN:
        raise SystemExit("BOT_TOKEN missing — see .env.example")
    if not s.WALLET_MASTER_KEY:
        raise SystemExit("WALLET_MASTER_KEY missing — see .env.example")
    if not s.PIN_PEPPER:
        raise SystemExit("PIN_PEPPER missing — see .env.example")

    bot = Bot(s.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(admin_router)
    dp.include_router(core_router)
    dp.include_router(signal_bot_router)

    poller = PricePoller.from_settings()
    exiter = ExitEngine(poller=poller, bot=bot)
    payer = PaymentMatcher(bot)
    depwatcher = DepositWatcher(bot)

    await bot.delete_webhook(drop_pending_updates=False)
    log().info("boot", ingest=s.SIGNAL_INGEST, preset=s.DEFAULT_RISK_PRESET,
               treasury=bool(s.OPERATOR_TREASURY_SOL))
    tasks = [
        asyncio.create_task(dp.start_polling(
            bot,
            allowed_updates=[
                "message",
                "edited_message",
                "callback_query",
                "channel_post",
                "edited_channel_post",
                "my_chat_member",
            ],
        ), name="tg-dispatcher"),
        asyncio.create_task(poller.run(),          name="price-poller"),
        asyncio.create_task(exiter.run(),          name="exit-engine"),
        asyncio.create_task(payer.run(),           name="payment-matcher"),
        asyncio.create_task(depwatcher.run(),      name="deposit-watcher"),
        asyncio.create_task(run_http_server(port=8080), name="http-api"),
    ]
    if s.SIGNAL_INGEST == "telethon":
        tasks.append(
            asyncio.create_task(run_telethon_ingest(aio_bot=bot), name="telethon-ingest")
        )
    try:
        await asyncio.gather(*tasks)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        poller.stop()
        exiter.stop()
        payer.stop()
        depwatcher.stop()
        await bot.session.close()


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
