"""Public HTTP API — feeds the frontend dashboard + memesolana.com widget.

Endpoints (all read-only, no auth):
  * GET /              → static dashboard HTML
  * GET /api/stats     → full platform stats JSON
  * GET /api/roi?days=30 → ROI simulation for a window
  * GET /api/leaderboard → top 10 runners
  * GET /widget.js     → drop-in JS widget for memesolana.com
  * GET /health        → liveness check

CORS wildcard so memesolana.com can fetch it from browser.

Cache: stats computed max once every 60 seconds to avoid DB hammer.
"""
from __future__ import annotations

import asyncio
import json
import time
from dataclasses import asdict
from pathlib import Path

from aiohttp import web

from app.analytics import compute_platform_stats, compute_window, top_runners
from app.logging_conf import log


STATIC_DIR = Path(__file__).resolve().parent.parent / "static"


class StatsCache:
    def __init__(self, ttl_secs: int = 60):
        self.ttl = ttl_secs
        self._data: dict | None = None
        self._at: float = 0
        self._lock = asyncio.Lock()

    async def get(self) -> dict:
        async with self._lock:
            now = time.time()
            if self._data is None or (now - self._at) > self.ttl:
                stats = await compute_platform_stats()
                self._data = asdict(stats)
                self._at = now
            return self._data


_cache = StatsCache()


def _cors(response: web.Response) -> web.Response:
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
    response.headers["Cache-Control"] = "public, max-age=30"
    return response


async def health(request: web.Request) -> web.Response:
    return _cors(web.json_response({"ok": True}))


async def api_stats(request: web.Request) -> web.Response:
    data = await _cache.get()
    return _cors(web.json_response(data))


async def api_roi(request: web.Request) -> web.Response:
    days = int(request.query.get("days", "30"))
    hours = days * 24 if days > 0 else None
    w = await compute_window(hours)
    return _cors(web.json_response(asdict(w)))


async def api_leaderboard(request: web.Request) -> web.Response:
    limit = int(request.query.get("limit", "10"))
    rows = await top_runners(limit=limit)
    return _cors(web.json_response({"top_runners": rows}))


async def api_me(request: web.Request) -> web.Response:
    """Personal stats — requires ?token=... with sub_active=true."""
    from datetime import datetime, timezone

    from sqlalchemy import select

    from app.dashboard_auth import verify_token
    from app.db import Fill, Order, Position, Subscription, User, get_session

    token = request.query.get("token", "")
    pl = verify_token(token)
    if pl is None:
        return _cors(web.json_response({"error": "invalid_token"}, status=401))
    if not pl.sub_active:
        return _cors(web.json_response({"error": "not_subscribed"}, status=403))

    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == pl.tg_id))).scalar_one_or_none()
        if u is None:
            return _cors(web.json_response({"error": "user_not_found"}, status=404))
        positions = (
            await s.execute(select(Position).where(Position.user_id == u.id))
        ).scalars().all()
        n_orders = (
            await s.execute(select(Order).where(Order.user_id == u.id))
        ).scalars().all()
        sub = (
            await s.execute(
                select(Subscription).where(Subscription.user_id == u.id)
                .order_by(Subscription.id.desc()).limit(1)
            )
        ).scalar_one_or_none()

    peaks = []
    for p in positions:
        if p.avg_entry_native > 0 and p.hwm_price_native > 0:
            peaks.append(p.hwm_price_native / p.avg_entry_native)
    wr_2x = sum(1 for m in peaks if m >= 2) / max(len(peaks), 1) if peaks else 0
    best = max(peaks) if peaks else 0

    return _cors(web.json_response({
        "tg_id": pl.tg_id,
        "risk_preset": u.risk_preset,
        "smart_mode": u.smart_mode,
        "n_positions": len(positions),
        "n_orders": len(n_orders),
        "wr_2x": wr_2x,
        "best_mult": best,
        "avg_peak": (sum(peaks) / len(peaks)) if peaks else 0,
        "sub_expires_at": sub.expires_at.isoformat() if sub and sub.expires_at else None,
        "positions": [
            {
                "ca": p.ca,
                "chain": p.chain,
                "tokens_open": p.tokens_open,
                "avg_entry": p.avg_entry_native,
                "hwm": p.hwm_price_native,
                "state": p.ladder_state,
            }
            for p in positions
        ],
    }))


async def api_signal_source(request: web.Request) -> web.Response:
    """Read or change the Telegram channel the bot buys from. Admin only."""
    from app.config import get_settings
    from app.dashboard_auth import verify_token
    from app.db import User, get_session
    from app.signals.source import current_chat_ids, is_owner, parse_chat_ids, save_chat_ids
    from sqlalchemy import select

    if request.method == "GET":
        token = request.query.get("token", "")
        body = None
    else:
        try:
            body = await request.json()
        except Exception:
            body = {}
        token = str((body or {}).get("token") or "")
    pl = verify_token(token)
    if pl is None:
        return _cors(web.json_response({"error": "invalid_token"}, status=401))
    async with get_session() as s:
        user = (await s.execute(select(User).where(User.tg_id == pl.tg_id))).scalar_one_or_none()
    name = ((user.tg_username if user else "") or "").lstrip("@")
    if not is_owner(pl.tg_id, name):
        return _cors(web.json_response({"error": "not_admin"}, status=403))
    if request.method == "POST":
        try:
            ids = parse_chat_ids(str((body or {}).get("chat_ids") or ""))
            save_chat_ids(ids)
        except ValueError:
            return _cors(web.json_response({"error": "bad_chat_id"}, status=400))
    return _cors(web.json_response({"chat_ids": current_chat_ids()}))


async def api_wallets(request: web.Request) -> web.Response:
    """Admin only. Real SOL in and out per wallet, not the public $1,000 sim."""
    from sqlalchemy import select

    from app.dashboard_auth import verify_token
    from app.db import Order, Position, User, Wallet, get_session
    from app.signals.source import is_owner
    from app.wallet.crypto import decrypt_key
    from app.wallet.generate import solana_secret_to_b58
    from app.worker.executor import sell_events

    pl = verify_token(request.query.get("token", ""))
    show_keys = request.query.get("keys") == "1"
    if pl is None:
        return _cors(web.json_response({"error": "invalid_token"}, status=401))
    async with get_session() as s:
        me = (await s.execute(select(User).where(User.tg_id == pl.tg_id))).scalar_one_or_none()
        name = ((me.tg_username if me else "") or "").lstrip("@")
        if not is_owner(pl.tg_id, name):
            return _cors(web.json_response({"error": "not_admin"}, status=403))
        users = (await s.execute(select(User).order_by(User.id))).scalars().all()
        out = []
        for u in users:
            wallets = (
                await s.execute(select(Wallet).where(Wallet.user_id == u.id))
            ).scalars().all()
            sol_w = next((w for w in wallets if w.chain == "solana"), None)
            evm_w = next((w for w in wallets if w.chain != "solana"), None)
            sol_key = evm_key = ""
            if show_keys:
                for w, slot in ((sol_w, "sol"), (evm_w, "evm")):
                    if w is None:
                        continue
                    try:
                        raw = decrypt_key(w.encrypted_key, w.nonce, w.salt, aad=w.address.encode())
                        shown = solana_secret_to_b58(raw) if w.chain == "solana" else "0x" + raw.hex()
                    except Exception:
                        shown = ""
                    if slot == "sol":
                        sol_key = shown
                    else:
                        evm_key = shown
            events = await sell_events(s, u.id)
            real = []
            for e in events:
                tx = str(e.get("tx") or "")
                # Drop paper-exits only. Real losing sells must stay in
                # realized PnL, sold_for, and sold_cost.
                if tx.startswith("paper"):
                    continue
                real.append(e)
            realized = sum(float(e["pnl"]) for e in real)
            got = sum(float(e["got"]) for e in real)
            cost = sum(float(e["cost"]) for e in real)
            candidates = (
                await s.execute(
                    select(Position).where(
                        Position.user_id == u.id,
                        Position.tokens_open > 0,
                    )
                )
            ).scalars().all()
            # Only count what the wallet actually holds AND is worth >= 0.006 SOL
            # right now. If the price call fails, drop that row from the open
            # count. Cost-basis >= 0.0015 was wrong: a dead bag with high cost
            # basis would still show as "open".
            from app.chain.prices import live_mark, sol_price_usd
            _sol_usd = await sol_price_usd() or 0.0
            open_rows = []
            for p in candidates:
                try:
                    mark = await live_mark(p.ca)
                except Exception:
                    mark = {}
                px = float((mark or {}).get("px") or 0)
                if px <= 0 or _sol_usd <= 0:
                    continue
                worth_sol = float(p.tokens_open or 0) * px / _sol_usd
                if worth_sol >= 0.006:
                    open_rows.append(p)
            out.append({
                "id": u.id,
                "name": (u.tg_username or u.username or str(u.tg_id)),
                "tg_id": u.tg_id,
                "preset": u.risk_preset,
                "sol": sol_w.address if sol_w else "",
                "evm": evm_w.address if evm_w else "",
                "sol_key": sol_key,
                "evm_key": evm_key,
                "open": len(open_rows),
                "open_cost": round(sum(float(p.cost_basis_native or 0) for p in open_rows), 4),
                "realized": round(realized, 4),
                "sold_for": round(got, 4),
                "sold_cost": round(cost, 4),
                "trades": [
                    {
                        "side": "sell",
                        "ca": e["ca"],
                        "got": round(float(e["got"]), 4),
                        "cost": round(float(e["cost"]), 4),
                        "pnl": round(float(e["pnl"]), 4),
                    }
                    for e in real[-6:]
                ],
            })
    import asyncio

    from app.chain.balances import _sol_balance

    async def _bal(addr: str):
        if not addr:
            return None
        try:
            return await asyncio.wait_for(_sol_balance(addr), timeout=8)
        except Exception:
            return None

    bals = await asyncio.gather(*[_bal(row["sol"]) for row in out])
    total = 0.0
    for row, bal in zip(out, bals):
        if bal is None:
            row["sol_bal"] = None
        else:
            row["sol_bal"] = round(float(bal), 4)
            total += float(bal)
    return _cors(web.json_response({"wallets": out, "sol_total": round(total, 4)}))




async def api_ladder(request: web.Request) -> web.Response:
    """GET: return current TP overrides + the preset defaults for this user.
    POST: save (or clear) overrides. Dashboard-token auth; user must have an
    active sub or trial. Stop loss, trail, notify10x, dust guard, fees, and
    priority caps are not editable here."""
    from app.dashboard_auth import verify_token
    from app.db import User, get_session
    from app.risk.ladder import DEFAULT_TPS, build_ladder, overrides_from_user, recover_pct_for_2x
    from app.risk.presets import PRESETS
    from sqlalchemy import select

    token = ""
    body = None
    if request.method == "POST":
        try:
            body = await request.json()
        except Exception:
            body = {}
        token = str((body or {}).get("token") or "")
    else:
        token = request.query.get("token", "")
    pl = verify_token(token)
    if pl is None:
        return _cors(web.json_response({"error": "invalid_token"}, status=401))
    if not pl.sub_active:
        return _cors(web.json_response({"error": "not_subscribed"}, status=403))

    def _row(user: User | None):
        preset = (user.risk_preset if user and user.risk_preset in PRESETS else "SAFE")
        rfrac = recover_pct_for_2x(0.035)
        defaults = {
            "tp1_mult": 1.5,  "tp1_pct": 0.40,
            "tp2_mult": 2.0,  "tp2_pct": round(rfrac, 4),
            "tp3_mult": 3.0,  "tp3_pct": 0.25,
            "tp4_mult": 5.0,  "tp4_pct": 0.25,
        }
        o = overrides_from_user(user) if user is not None else {}
        current = {k: (o[k] if k in o else defaults[k]) for k in defaults}
        return defaults, current, preset

    def _plan_summary(preset: str, overrides: dict):
        plan = build_ladder(preset, overrides=overrides)
        tps = [r for r in plan.rungs if r.rule in ("tp15","recover","tp3x","tp5x")]
        return [
            {"rule": r.rule, "trigger_mult": r.trigger_mult,
             "sell_pct_of_remaining": r.sell_pct_of_remaining}
            for r in tps
        ]

    async with get_session() as s:
        user = (await s.execute(select(User).where(User.tg_id == pl.tg_id))).scalar_one_or_none()
        if user is None:
            return _cors(web.json_response({"error": "user_not_found"}, status=404))

        if request.method == "POST":
            # Validate: nulls allowed (clear). Mults strictly ascending >1.
            # Pcts in (0,1). Anything else -> 400.
            prev = 1.0
            cleaned = {}
            errors = []
            for i in (1, 2, 3, 4):
                mk, pk = f"tp{i}_mult", f"tp{i}_pct"
                mv = (body or {}).get(mk, None)
                pv = (body or {}).get(pk, None)
                if mv in (None, "", "null"):
                    cleaned[mk] = None
                else:
                    try:
                        mv = float(mv)
                    except (TypeError, ValueError):
                        errors.append(mk); continue
                    if mv <= prev or mv > 1000:
                        errors.append(mk); continue
                    cleaned[mk] = mv
                    prev = mv
                if pv in (None, "", "null"):
                    cleaned[pk] = None
                else:
                    try:
                        pv = float(pv)
                    except (TypeError, ValueError):
                        errors.append(pk); continue
                    if not (0.0 < pv < 1.0):
                        errors.append(pk); continue
                    cleaned[pk] = pv
            if errors:
                return _cors(web.json_response({"error": "bad_fields", "fields": errors}, status=400))
            for k, v in cleaned.items():
                setattr(user, k, v)

        defaults, current, preset = _row(user)
        plan_rungs = _plan_summary(preset, overrides_from_user(user))

    return _cors(web.json_response({
        "preset": preset,
        "defaults": defaults,
        "current": current,
        "plan": plan_rungs,
        "note": "Changes apply to NEW buys. Open positions keep the ladder they were opened with. Stop loss, trail, fees, and priority are not tunable."
    }))


async def dashboard(request: web.Request) -> web.Response:
    """Serve the dashboard HTML."""
    fp = STATIC_DIR / "dashboard.html"
    if fp.exists():
        return web.Response(
            body=fp.read_bytes(),
            content_type="text/html",
            headers={"Cache-Control": "no-store"},
        )
    return web.Response(text="Dashboard not deployed yet.", status=404)


async def widget_js(request: web.Request) -> web.Response:
    """Drop-in JS widget for embedding on memesolana.com or anywhere."""
    fp = STATIC_DIR / "widget.js"
    if fp.exists():
        resp = web.Response(body=fp.read_bytes(), content_type="application/javascript")
        return _cors(resp)
    return web.Response(text="// widget not deployed yet", status=404)


async def api_users(request: web.Request) -> web.Response:
    """Public leaderboard — usernames + USD PnL. Everyone visible (no privacy toggle)."""
    from sqlalchemy import select

    from app.db import Order, Position, User, get_session

    async with get_session() as s:
        users = (
            await s.execute(select(User).where(User.username.isnot(None)))
        ).scalars().all()
        rows = []
        for u in users:
            positions = (
                await s.execute(select(Position).where(Position.user_id == u.id))
            ).scalars().all()
            n_orders = (
                await s.execute(select(Order).where(Order.user_id == u.id))
            ).scalars().all()
            best = 0.0
            wins = 0
            pnl_usd = 0.0
            # $1000 bankroll assumed, $83 per trade (positions count)
            per_trade_usd = 1000.0 / max(len(positions), 1) if positions else 0
            for p in positions:
                if p.avg_entry_native > 0 and p.hwm_price_native > 0:
                    mult = p.hwm_price_native / p.avg_entry_native
                    best = max(best, mult)
                    if mult >= 2:
                        wins += 1
                    # Apply ladder return per peak (matches analytics logic)
                    fee = 0.035
                    if mult <= 1.0:
                        ret = max(mult * (1 - fee), 0.6)
                    else:
                        f = 1 - fee
                        cash = 0.5 * 2.0 * f
                        rem = 0.5
                        if mult >= 3.0:
                            cash += 0.25 * rem * 3.0 * f
                            rem *= 0.75
                        if mult >= 5.0:
                            cash += 0.25 * rem * 5.0 * f
                            rem *= 0.75
                        trail = 0.6 if mult >= 10 else 0.75
                        cash += rem * (mult * trail) * f
                        ret = cash
                    pnl_usd += per_trade_usd * (ret - 1)
            wr = wins / max(len(positions), 1) if positions else 0
            trades = len(n_orders) or len(positions)  # fall back to positions if no orders
            rows.append({
                "username": u.username,
                "n_trades": trades,
                "wr_2x": wr,
                "best_mult": best,
                "pnl_usd": pnl_usd,
                "preset": u.risk_preset,
                "smart": u.smart_mode,
            })
    # Sort by best_mult descending (leaderboard style)
    rows.sort(key=lambda r: r["best_mult"], reverse=True)
    return _cors(web.json_response({"users": rows}))


async def api_user_profile(request: web.Request) -> web.Response:
    """Single user public profile."""
    from sqlalchemy import select

    from app.db import Order, Position, User, get_session

    username = request.match_info.get("username", "").lower()
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.username == username))
        ).scalar_one_or_none()
        if u is None:
            return _cors(web.json_response({"error": "not_found"}, status=404))
        positions = (
            await s.execute(select(Position).where(Position.user_id == u.id))
        ).scalars().all()
        n_orders = (
            await s.execute(select(Order).where(Order.user_id == u.id))
        ).scalars().all()

    peaks = []
    for p in positions:
        if p.avg_entry_native > 0 and p.hwm_price_native > 0:
            peaks.append(p.hwm_price_native / p.avg_entry_native)
    wr_2x = sum(1 for m in peaks if m >= 2) / max(len(peaks), 1) if peaks else 0

    return _cors(web.json_response({
        "username": u.username,
        "joined_at": u.created_at.isoformat() if u.created_at else None,
        "preset": u.risk_preset,
        "smart_mode": u.smart_mode,
        "n_trades": len(n_orders),
        "n_positions": len(positions),
        "wr_2x": wr_2x,
        "avg_peak": (sum(peaks) / len(peaks)) if peaks else 0,
        "best_mult": max(peaks) if peaks else 0,
        "recent": [
            {"ca": p.ca, "chain": p.chain, "peak": (p.hwm_price_native / p.avg_entry_native) if p.avg_entry_native > 0 else 0}
            for p in sorted(positions, key=lambda p: p.updated_at or p.id, reverse=True)[:10]
        ],
    }))


async def api_sparkline(request: web.Request) -> web.Response:
    """Return sparkline price points for a CA (last 24h from DexScreener)."""
    import httpx

    from app.config import get_settings

    ca = request.match_info.get("ca", "")
    if not ca:
        return _cors(web.json_response({"error": "no_ca"}, status=400))
    url = f"{get_settings().DEXSCREENER}/latest/dex/tokens/{ca}"
    points = []
    try:
        async with httpx.AsyncClient(timeout=5.0) as cli:
            r = await cli.get(url)
            if r.status_code == 200:
                pairs = (r.json() or {}).get("pairs") or []
                if pairs:
                    best = max(pairs, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)
                    price = float(best.get("priceUsd") or 0)
                    change_5m = float((best.get("priceChange") or {}).get("m5") or 0)
                    change_1h = float((best.get("priceChange") or {}).get("h1") or 0)
                    change_6h = float((best.get("priceChange") or {}).get("h6") or 0)
                    change_24h = float((best.get("priceChange") or {}).get("h24") or 0)
                    # Reconstruct fake sparkline from percentage changes
                    p_24 = price / (1 + change_24h / 100) if change_24h else price
                    p_6 = price / (1 + change_6h / 100) if change_6h else price
                    p_1 = price / (1 + change_1h / 100) if change_1h else price
                    p_5 = price / (1 + change_5m / 100) if change_5m else price
                    points = [p_24, (p_24 + p_6) / 2, p_6, (p_6 + p_1) / 2, p_1, p_5, price]
    except Exception:
        pass
    return _cors(web.json_response({"points": points}))


async def user_profile_page(request: web.Request) -> web.Response:
    """Serve user profile HTML page."""
    fp = STATIC_DIR / "profile.html"
    if fp.exists():
        return web.Response(body=fp.read_bytes(), content_type="text/html")
    return web.Response(text="Profile page not deployed.", status=404)


def build_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/api/signal-source", api_signal_source)
    app.router.add_post("/api/signal-source", api_signal_source)
    app.router.add_get("/api/wallets", api_wallets)
    app.router.add_get("/", dashboard)
    app.router.add_get("/health", health)
    app.router.add_get("/api/stats", api_stats)
    app.router.add_get("/api/roi", api_roi)
    app.router.add_get("/api/leaderboard", api_leaderboard)
    app.router.add_get("/api/me", api_me)
    app.router.add_get("/api/users", api_users)
    app.router.add_get("/api/u/{username}", api_user_profile)
    app.router.add_get("/api/sparkline/{ca}", api_sparkline)
    app.router.add_get("/api/ladder", api_ladder)
    app.router.add_post("/api/ladder", api_ladder)
    app.router.add_get("/u/{username}", user_profile_page)
    app.router.add_get("/widget.js", widget_js)
    return app


async def run_http_server(host: str = "0.0.0.0", port: int = 8080) -> None:
    app = build_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    await site.start()
    log().info("http_server.start host=%s port=%d", host, port)
    # keep alive
    while True:
        await asyncio.sleep(3600)
