"""Sell Solana memecoins without the Jupiter rate limit.

Pump.fun tokens (mint ends in 'pump') are built by PumpPortal and sent
through the user's own RPC. Other tokens try Jupiter first, then PumpPortal.
"""
from __future__ import annotations

import base64

import httpx
from solders.transaction import VersionedTransaction

from app.chain import solana_jupiter
from app.chain.prices import get_price_usd

_WSOL = "So11111111111111111111111111111111111111112"
_LOCAL = "https://pumpportal.fun/api/trade-local"


async def buy_solana(
    *,
    ca: str,
    amount_lamports: int,
    slippage_bps: int,
    user_pubkey: str,
    secret_key: bytes,
    priority_fee: str = "medium",
) -> tuple[str, float]:
    """Buy a Solana memecoin. Pump first, Jupiter only if that misses."""
    errors: list[str] = []
    try:
        sig = await _pump_buy(
            ca=ca,
            amount_lamports=amount_lamports,
            slippage_bps=slippage_bps,
            user_pubkey=user_pubkey,
            secret_key=secret_key,
        )
        return sig, await _estimate_tokens(ca, amount_lamports / 1e9)
    except Exception as e:
        errors.append(str(e).splitlines()[0][:160])
    try:
        sig, quote = await solana_jupiter.swap_with_retry(
            input_mint=solana_jupiter.WSOL_MINT,
            output_mint=ca,
            amount=amount_lamports,
            slippage_bps=slippage_bps,
            user_pubkey=user_pubkey,
            secret_key=secret_key,
            priority_fee=priority_fee,
            attempts=1,
        )
        return sig, quote.out_amount / 1e6
    except Exception as e:
        errors.append(str(e).splitlines()[0][:160])
    raise RuntimeError(errors[-1] if errors else "buy failed")


async def _pump_buy(*, ca, amount_lamports, slippage_bps, user_pubkey, secret_key) -> str:
    import asyncio
    sol = max(amount_lamports / 1e9, 0.001)
    # Two pools, one try each. A long pool ladder was leaving the user on "Buying" for minutes.
    pools = ("pump", "auto") if str(ca).endswith("pump") else ("auto", "launchlab")
    body = {
        "publicKey": user_pubkey,
        "action": "buy",
        "mint": ca,
        "amount": round(sol, 6),
        "denominatedInSol": "true",
        "slippage": 50,
        "priorityFee": 0.0008,
        "pool": pools[0],
    }
    last = "no market yet"
    for pool in pools:
        body["pool"] = pool
        async with httpx.AsyncClient(timeout=8.0) as cli:
            try:
                r = await cli.post(_LOCAL, json=body)
            except httpx.RequestError as e:
                last = f"pump timeout {e.__class__.__name__}"
                continue
        if r.status_code != 200:
            last = f"pump {pool} HTTP {r.status_code}: {r.text[:100]}"
            continue
        raw = r.content
        if raw[:1] in (b"{", b"["):
            last = f"pump {pool} {r.text[:100]}"
            continue
        try:
            VersionedTransaction.from_bytes(raw)
        except Exception:
            raw = base64.b64decode(raw)
        try:
            return await solana_jupiter.sign_and_send(
                raw_tx=raw, secret_key=secret_key, skip_preflight=True,
            )
        except Exception as e:
            last = str(e).splitlines()[0][:160]
    raise RuntimeError(last)


async def _estimate_tokens(ca: str, sol_spent: float) -> float:
    try:
        px = await get_price_usd(ca, "solana")
        sol = await get_price_usd(_WSOL, "solana")
    except Exception:
        return 0.0
    if not px or not sol or px <= 0:
        return 0.0
    return max(0.0, (sol_spent * sol) / px)


async def sell_solana(
    *,
    ca: str,
    pct: float,
    amount_raw: int,
    slippage_bps: int,
    user_pubkey: str,
    secret_key: bytes,
) -> tuple[str, float]:
    # One fast path for every Solana memecoin. Jupiter only if that misses.
    steps = (_pump, _jupiter)
    errors: list[str] = []
    before = 0
    try:
        before = await solana_jupiter.spl_raw_balance(user_pubkey, ca)
    except Exception:
        before = 0
    for step in steps:
        try:
            sig, out = await step(
                ca=ca,
                pct=pct,
                amount_raw=amount_raw,
                slippage_bps=slippage_bps,
                user_pubkey=user_pubkey,
                secret_key=secret_key,
            )
            return sig, out
        except Exception as e:
            errors.append(str(e).splitlines()[0][:160])
    raise RuntimeError(errors[-1] if errors else "sell failed")


async def _jupiter(**kwargs) -> tuple[str, float]:
    # Sell priority fee hard-capped at 0.0001 SOL per spec. "high" would send
    # 0.001 SOL (10x the cap) and on a dumping coin that fallback bled wallets
    # dry across retries. "low" = 100_000 lamports = 0.0001 SOL.
    sig, quote = await solana_jupiter.swap_with_retry(
        input_mint=kwargs["ca"],
        output_mint=solana_jupiter.WSOL_MINT,
        amount=kwargs["amount_raw"],
        slippage_bps=kwargs["slippage_bps"],
        user_pubkey=kwargs["user_pubkey"],
        secret_key=kwargs["secret_key"],
        priority_fee="low",
        attempts=2,
    )
    return sig, quote.out_amount / solana_jupiter.SOL_LAMPORTS


async def _pump(**kwargs) -> tuple[str, float]:
    import asyncio
    pct_i = int(round(max(0.01, min(1.0, kwargs["pct"])) * 100))
    # auto first. A bad pool used to return a signature and stop the sell
    # while the tokens were still in the wallet.
    pools = ("pump",) if str(kwargs["ca"]).endswith("pump") else ("auto",)
    body = {
        "publicKey": kwargs["user_pubkey"],
        "action": "sell",
        "mint": kwargs["ca"],
        "amount": f"{pct_i}%",
        "denominatedInSol": "false",
        "slippage": 50,
        "priorityFee": 0.0001,
        "pool": pools[0],
    }
    last = "sell did not land"
    before = 0
    try:
        before = await solana_jupiter.spl_raw_balance(kwargs["user_pubkey"], kwargs["ca"])
    except Exception:
        before = 0
    for pool in pools:
        if before > 0:
            try:
                now = await solana_jupiter.spl_raw_balance(kwargs["user_pubkey"], kwargs["ca"])
                if now < before * 0.85:
                    return "landed", await _estimate_sol(kwargs["ca"], kwargs["amount_raw"])
            except Exception:
                pass
        body["pool"] = pool
        async with httpx.AsyncClient(timeout=8.0) as cli:
            try:
                r = await cli.post(_LOCAL, json=body)
            except httpx.RequestError as e:
                last = f"pump timeout {e.__class__.__name__}"
                continue
        if r.status_code != 200 or r.content[:1] in (b"{", b"["):
            last = f"pump {pool} {r.text[:80]}"
            continue
        raw = r.content
        try:
            VersionedTransaction.from_bytes(raw)
        except Exception:
            raw = base64.b64decode(raw)
        try:
            sig = await solana_jupiter.sign_and_send(
                raw_tx=raw,
                secret_key=kwargs["secret_key"],
                skip_preflight=True,
            )
        except Exception as e:
            last = str(e).splitlines()[0][:140]
            continue
        for _ in range(4):
            await asyncio.sleep(1.0)
            if before <= 0:
                return sig, await _estimate_sol(kwargs["ca"], kwargs["amount_raw"])
            try:
                now = await solana_jupiter.spl_raw_balance(kwargs["user_pubkey"], kwargs["ca"])
            except Exception:
                return sig, await _estimate_sol(kwargs["ca"], kwargs["amount_raw"])
            if now < before * 0.85:
                return sig, await _estimate_sol(kwargs["ca"], kwargs["amount_raw"])
        last = f"{pool} tx did not move the tokens"
    raise RuntimeError(last)


async def _estimate_sol(ca: str, amount_raw: int) -> float:
    try:
        px = await get_price_usd(ca, "solana")
        sol = await get_price_usd(_WSOL, "solana")
    except Exception:
        return 0.0
    if not px or not sol:
        return 0.0
    return max(0.0, (px / sol) * (amount_raw / 1_000_000))
