"""EVM swap via 0x Swap API (v1 public — no key required, higher limits with a key)."""
from __future__ import annotations

from dataclasses import dataclass

import httpx
from eth_account import Account
from web3 import Web3

from app.config import get_settings

# Native "token" placeholder that 0x expects for the chain's gas token.
_ZEROX_NATIVE = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"

_CHAIN_HOSTS = {
    "ethereum": "https://api.0x.org",
    "base": "https://base.api.0x.org",
    "bsc": "https://bsc.api.0x.org",
    "arbitrum": "https://arbitrum.api.0x.org",
}
_CHAIN_RPCS = {
    "ethereum": lambda: get_settings().ETH_RPC,
    "base":     lambda: get_settings().BASE_RPC,
    "bsc":      lambda: get_settings().BSC_RPC,
    "arbitrum": lambda: get_settings().ARB_RPC,
}


@dataclass(slots=True)
class ZeroExQuote:
    to: str
    data: str
    value: int
    gas: int
    buy_amount: int
    sell_amount: int
    price: float
    allowance_target: str | None


class EvmSwapError(RuntimeError):
    pass


def _headers() -> dict:
    key = get_settings().ZEROX_API_KEY
    return {"0x-api-key": key} if key else {}


async def quote(
    *,
    chain: str,
    sell_token: str,
    buy_token: str,
    sell_amount: int,
    taker: str,
    slippage_bps: int,
) -> ZeroExQuote:
    host = _CHAIN_HOSTS.get(chain)
    if not host:
        raise EvmSwapError(f"unsupported chain {chain}")
    url = f"{host}/swap/v1/quote"
    params = {
        "sellToken": sell_token,
        "buyToken": buy_token,
        "sellAmount": str(sell_amount),
        "takerAddress": taker,
        "slippagePercentage": f"{slippage_bps / 10_000:.4f}",
    }
    async with httpx.AsyncClient(timeout=10.0, headers=_headers()) as cli:
        r = await cli.get(url, params=params)
        if r.status_code != 200:
            raise EvmSwapError(f"0x quote {r.status_code}: {r.text[:200]}")
        d = r.json()
        return ZeroExQuote(
            to=d["to"],
            data=d["data"],
            value=int(d.get("value") or 0),
            gas=int(d.get("gas") or 300_000),
            buy_amount=int(d["buyAmount"]),
            sell_amount=int(d["sellAmount"]),
            price=float(d.get("price") or 0),
            allowance_target=d.get("allowanceTarget"),
        )


def sign_and_send_native_buy(
    *, chain: str, quote_res: ZeroExQuote, private_key: bytes, gas_gwei: float | None = None
) -> str:
    """Sign a native-token → token buy and broadcast. Returns tx hash."""
    rpc = _CHAIN_RPCS[chain]()
    w3 = Web3(Web3.HTTPProvider(rpc, request_kwargs={"timeout": 15}))
    acct = Account.from_key(private_key)
    if acct.address.lower() != Web3.to_checksum_address(acct.address).lower():
        pass  # normalized
    tx = {
        "to": quote_res.to,
        "data": quote_res.data,
        "value": quote_res.value,
        "gas": quote_res.gas + 30_000,   # buffer
        "nonce": w3.eth.get_transaction_count(acct.address),
        "chainId": w3.eth.chain_id,
    }
    if gas_gwei is not None:
        tx["gasPrice"] = w3.to_wei(gas_gwei, "gwei")
    else:
        tx["maxFeePerGas"] = w3.to_wei(5, "gwei")
        tx["maxPriorityFeePerGas"] = w3.to_wei(2, "gwei")
    signed = acct.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)
    # zero the pk buffer if mutable
    return tx_hash.hex()


def native_sentinel() -> str:
    return _ZEROX_NATIVE
