"""Solana swap via Jupiter Swap API v6."""
from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Optional

import httpx
from solders.keypair import Keypair
from solders.transaction import VersionedTransaction

from app.config import get_settings

WSOL_MINT = "So11111111111111111111111111111111111111112"
SOL_LAMPORTS = 1_000_000_000


@dataclass(slots=True)
class JupiterQuote:
    in_amount: int
    out_amount: int
    price_impact_pct: float
    route_json: dict


class JupiterError(RuntimeError):
    pass


import asyncio
import time

_lock = asyncio.Lock()
_blocked_until = 0.0


def _headers() -> dict:
    key = str(getattr(get_settings(), "JUPITER_API_KEY", "") or "").strip()
    headers = {"User-Agent": "smc-autotrade"}
    if key:
        headers["x-api-key"] = key
    return headers


def _host() -> str:
    s = get_settings()
    if str(s.JUPITER_API_KEY or "").strip():
        return "https://api.jup.ag/swap/v1"
    base = (s.JUPITER_QUOTE or "").rstrip("/")
    if not base or "quote-api.jup.ag" in base:
        return "https://lite-api.jup.ag/swap/v1"
    return base


async def _pace() -> None:
    wait = _blocked_until - time.time()
    if wait > 0:
        await asyncio.sleep(min(wait, 12))


def _mark_busy(response: httpx.Response) -> None:
    global _blocked_until
    if response.status_code != 429:
        return
    try:
        retry = float(response.headers.get("Retry-After") or 8)
    except ValueError:
        retry = 8
    _blocked_until = time.time() + min(max(retry, 6), 15)


async def quote(
    *, input_mint: str, output_mint: str, amount: int, slippage_bps: int,
    max_accounts: int = 64,
) -> JupiterQuote:
    host = _host()
    last_err = "No market for this token yet."
    accounts = max(64, int(max_accounts or 64))
    async with httpx.AsyncClient(timeout=15.0, headers=_headers()) as cli:
        async with _lock:
            for extra in ({}, {"restrictIntermediateTokens": "true"}):
                await _pace()
                params = {
                    "inputMint": input_mint,
                    "outputMint": output_mint,
                    "amount": str(amount),
                    "slippageBps": str(slippage_bps),
                    "maxAccounts": str(accounts),
                    **extra,
                }
                try:
                    r = await cli.get(f"{host}/quote", params=params)
                except httpx.RequestError as e:
                    raise JupiterError("Jupiter is unreachable. Nothing was spent.") from e
                if r.status_code == 429:
                    _mark_busy(r)
                    last_err = "429 rate limit"
                    await _pace()
                    continue
                if r.status_code != 200:
                    last_err = f"quote HTTP {r.status_code}: {r.text[:120]}"
                    continue
                data = r.json()
                if not data or data.get("outAmount") in (None, "0"):
                    last_err = "no route"
                    continue
                return JupiterQuote(
                    in_amount=int(data["inAmount"]),
                    out_amount=int(data["outAmount"]),
                    price_impact_pct=float(data.get("priceImpactPct") or 0),
                    route_json=data,
                )
    raise JupiterError(last_err)


async def build_swap_tx(
    *, quote_json: dict, user_pubkey: str, priority_fee: str = "medium"
) -> bytes:
    pf_lamports = {"low": 100_000, "medium": 400_000, "high": 1_000_000}.get(priority_fee, 400_000)
    # Hard cap: 0.0008 SOL per buy. DEGEN preset says "high" which maps to
    # 0.001 SOL and breaks the spec. Clamp here so no caller can exceed it.
    pf_lamports = min(pf_lamports, 800_000)
    tip = int(float(getattr(get_settings(), "JITO_TIP_SOL", 0) or 0) * SOL_LAMPORTS)
    # A 0.001 tip on a wallet with dust SOL makes the sell itself fail.
    tip = min(tip, 100_000)
    if tip > 0:
        fee: int | dict = {"jitoTipLamports": tip}
    else:
        fee = pf_lamports
    body = {
        "quoteResponse": quote_json,
        "userPublicKey": user_pubkey,
        "wrapAndUnwrapSol": True,
        "dynamicComputeUnitLimit": True,
        "prioritizationFeeLamports": fee,
    }
    host = _host()
    async with httpx.AsyncClient(timeout=15.0, headers=_headers()) as cli:
        async with _lock:
            await _pace()
            try:
                r = await cli.post(f"{host}/swap", json=body)
            except httpx.RequestError as e:
                raise JupiterError("Jupiter is unreachable. Nothing was spent.") from e
            if r.status_code == 429:
                _mark_busy(r)
                await _pace()
                r = await cli.post(f"{host}/swap", json=body)
            if r.status_code == 429:
                _mark_busy(r)
                raise JupiterError("429 rate limit")
            if r.status_code != 200:
                raise JupiterError(f"swap HTTP {r.status_code}: {r.text[:160]}")
            raw_b64 = (r.json() or {}).get("swapTransaction")
            if not raw_b64:
                raise JupiterError("missing swapTransaction")
            return base64.b64decode(raw_b64)


def _send_targets(rpc_url: Optional[str]) -> list[str]:
    """Same signed tx, several doors. First signature back wins."""
    s = get_settings()
    key = (s.HELIUS_API_KEY or "").strip()
    urls = []
    if rpc_url:
        urls.append(rpc_url)
    urls.append(s.SOLANA_RPC)
    if key:
        urls.append(f"http://fra-sender.helius-rpc.com/fast?api-key={key}")
        urls.append(f"http://ams-sender.helius-rpc.com/fast?api-key={key}")
    urls.append("https://frankfurt.mainnet.block-engine.jito.wtf/api/v1/transactions")
    urls.append("https://amsterdam.mainnet.block-engine.jito.wtf/api/v1/transactions")
    urls.append("https://solana-rpc.publicnode.com")
    out: list[str] = []
    for url in urls:
        if url and url not in out:
            out.append(url)
    return out


async def sign_and_send(
    *, raw_tx: bytes, secret_key: bytes, rpc_url: Optional[str] = None,
    skip_preflight: bool = False,
) -> str:
    """Sign and send. Preflight is skipped: public RPCs reject fresh blockhashes."""
    kp = Keypair.from_bytes(secret_key)
    try:
        vt = VersionedTransaction.from_bytes(raw_tx)
        signed = bytes(VersionedTransaction(vt.message, [kp]))
        raw_b64 = base64.b64encode(signed).decode()
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sendTransaction",
            "params": [raw_b64, {
                "encoding": "base64",
                "skipPreflight": True,
                "preflightCommitment": "processed",
                "maxRetries": 0,
            }],
        }
        targets = _send_targets(rpc_url)
        last = "send failed"
        async with httpx.AsyncClient(timeout=8.0) as cli:
            async def _hit(url: str) -> str:
                r = await cli.post(url, json=payload)
                data = r.json()
                if data.get("result"):
                    return str(data["result"])
                err = data.get("error") or {}
                raise RuntimeError(str(err.get("message") or err)[:160])

            tasks = [asyncio.create_task(_hit(url)) for url in targets]
            sig = ""
            pending = set(tasks)
            while pending and not sig:
                done, pending = await asyncio.wait(
                    pending, timeout=8, return_when=asyncio.FIRST_COMPLETED,
                )
                if not done:
                    break
                for task in done:
                    try:
                        sig = task.result()
                    except Exception as e:
                        last = str(e)[:160]
            for task in pending:
                task.cancel()
            if not sig:
                raise JupiterError(last)
            try:
                await _confirm(cli, targets[0], sig)
            except JupiterError as e:
                if "tx failed" in str(e):
                    raise
            return sig
    finally:
        secret_key = b"\x00" * len(secret_key)


async def _confirm(cli: httpx.AsyncClient, rpc: str, sig: str) -> None:
    """A signature is not a buy. Wait until the chain says it landed."""
    import asyncio
    import time
    deadline = time.time() + 8
    while time.time() < deadline:
        try:
            r = await cli.post(rpc, json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getSignatureStatuses",
                "params": [[sig], {"searchTransactionHistory": False}],
            })
            val = ((r.json().get("result") or {}).get("value") or [None])[0]
        except Exception:
            val = None
        if val and val.get("err"):
            raise JupiterError(f"tx failed {val['err']}")
        status = (val or {}).get("confirmationStatus")
        if status in ("processed", "confirmed", "finalized"):
            return
        await asyncio.sleep(0.35)
    raise JupiterError("tx not confirmed")


def _permanent(err: str) -> bool:
    e = err.lower()
    return any(s in e for s in (
        "no record of a prior credit",
        "insufficient",
        "0x1788",
        "no route",
        "zero out",
    ))


async def swap_with_retry(
    *, input_mint: str, output_mint: str, amount: int, slippage_bps: int,
    user_pubkey: str, secret_key: bytes, priority_fee: str, attempts: int = 4,
    max_accounts: int = 64, **_unused,
):
    import asyncio
    last = "swap failed"
    slip = slippage_bps
    for i in range(min(attempts, 3)):
        try:
            q = await quote(
                input_mint=input_mint, output_mint=output_mint,
                amount=amount, slippage_bps=slip, max_accounts=max_accounts,
            )
            raw_tx = await build_swap_tx(
                quote_json=q.route_json, user_pubkey=user_pubkey,
                priority_fee=priority_fee,
            )
            sig = await sign_and_send(
                raw_tx=raw_tx, secret_key=secret_key,
                skip_preflight=(i == min(attempts, 3) - 1),
            )
            return sig, q
        except Exception as e:
            last = str(e)[:200]
            if "429" in last:
                await _pace()
                continue
            if _permanent(last) and i >= 1:
                break
            if "1771" in last or "slippage" in last.lower():
                slip = min(5000, max(slip, 2500) + 1500)
            await asyncio.sleep(0.4)
    raise JupiterError(last)


async def is_spl_mint(ca: str) -> bool | None:
    """True if the account is a token mint. None if the RPC did not answer."""
    body = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getAccountInfo",
        "params": [ca, {"encoding": "jsonParsed"}],
    }
    async with httpx.AsyncClient(timeout=8.0) as cli:
        for rpc in (
            get_settings().SOLANA_RPC,
            "https://solana.publicnode.com",
            "https://api.mainnet-beta.solana.com",
        ):
            try:
                r = await cli.post(rpc, json=body)
                data = r.json()
            except Exception:
                continue
            if data.get("error"):
                continue
            val = (data.get("result") or {}).get("value")
            if not val:
                return False
            parsed = (val.get("data") or {}).get("parsed") if isinstance(val.get("data"), dict) else None
            if not parsed:
                return False
            return parsed.get("type") == "mint"
    return None


async def mint_exists(ca: str) -> bool:
    """False only when an RPC confirms the account is missing."""
    kind = await is_spl_mint(ca)
    if kind is None:
        return True
    return bool(kind)


async def sol_lamports(address: str) -> int:
    body = {"jsonrpc": "2.0", "id": 1, "method": "getBalance", "params": [address]}
    async with httpx.AsyncClient(timeout=12.0) as cli:
        r = await cli.post(get_settings().SOLANA_RPC, json=body)
        r.raise_for_status()
        return int((r.json().get("result") or {}).get("value") or 0)


_TOKEN_PROGRAMS = (
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
    "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",
)
_ATA_PROGRAM = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"


def _ata(owner: str, mint: str, program: str) -> str:
    from solders.pubkey import Pubkey
    ata, _ = Pubkey.find_program_address(
        [
            bytes(Pubkey.from_string(owner)),
            bytes(Pubkey.from_string(program)),
            bytes(Pubkey.from_string(mint)),
        ],
        Pubkey.from_string(_ATA_PROGRAM),
    )
    return str(ata)


async def spl_holding(owner: str, mint: str) -> tuple[int, float] | None:
    """Raw amount and real UI amount. None if no RPC answered.

    One empty reply is not a zero balance. Every RPC has to agree the
    account is missing before this returns 0.
    """
    rpcs = [get_settings().SOLANA_RPC]
    for extra in (
        "https://solana.publicnode.com",
        "https://api.mainnet-beta.solana.com",
    ):
        if extra not in rpcs:
            rpcs.append(extra)
    saw = False
    async with httpx.AsyncClient(timeout=12.0) as cli:
        for program in _TOKEN_PROGRAMS:
            ata = _ata(owner, mint, program)
            empty = 0
            answered = 0
            for rpc in rpcs:
                try:
                    r = await cli.post(rpc, json={
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "getAccountInfo",
                        "params": [ata, {"encoding": "jsonParsed"}],
                    })
                    data = r.json()
                except Exception:
                    continue
                if data.get("error"):
                    continue
                saw = True
                answered += 1
                val = (data.get("result") or {}).get("value")
                if not val:
                    empty += 1
                    continue
                info = ((val.get("data") or {}).get("parsed") or {}).get("info") or {}
                tok = info.get("tokenAmount") or {}
                raw = int(tok.get("amount") or 0)
                ui = float(tok.get("uiAmount") or 0)
                return raw, ui
            if answered and empty < answered:
                return None
    if saw:
        return 0, 0.0
    return None


_SKIP_MINTS = {
    "So11111111111111111111111111111111111111112",
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
}


async def wallet_mints(owner: str) -> list[tuple[str, float]] | None:
    """Every SPL balance in the wallet. None when every RPC failed."""
    rpcs = [get_settings().SOLANA_RPC]
    for extra in (
        "https://solana.publicnode.com",
        "https://api.mainnet-beta.solana.com",
    ):
        if extra not in rpcs:
            rpcs.append(extra)
    found: dict[str, float] = {}
    ok = False
    async with httpx.AsyncClient(timeout=12.0) as cli:
        for program in _TOKEN_PROGRAMS:
            for rpc in rpcs:
                try:
                    r = await cli.post(rpc, json={
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "getTokenAccountsByOwner",
                        "params": [
                            owner,
                            {"programId": program},
                            {"encoding": "jsonParsed"},
                        ],
                    })
                    data = r.json()
                except Exception:
                    continue
                if data.get("error") or "result" not in data:
                    continue
                ok = True
                for row in ((data.get("result") or {}).get("value") or []):
                    info = (((row.get("account") or {}).get("data") or {}).get("parsed") or {}).get("info") or {}
                    mint = info.get("mint") or ""
                    ui = float((info.get("tokenAmount") or {}).get("uiAmount") or 0)
                    if mint and mint not in _SKIP_MINTS and ui > 0:
                        found[mint] = ui
                break
    if not ok:
        return None
    return list(found.items())


async def spl_raw_balance(owner: str, mint: str) -> int:
    """Read the token account directly. getTokenAccountsByOwner fails on public RPCs."""
    held = await spl_holding(owner, mint)
    if held is None:
        raise RuntimeError("balance rpc failed")
    return held[0]
