"""Move SOL into the user's EVM wallet before an EVM buy.

One Solana balance has to pay for Base, Ethereum, Arbitrum and BSC.
deBridge builds a Solana transaction that delivers native ETH or BNB
to the same user's EVM address. The buy then spends that native token.
"""
from __future__ import annotations

import asyncio

import httpx
from sqlalchemy import and_, select
from web3 import Web3

from app.chain import solana_jupiter
from app.chain.evm_swap import _CHAIN_RPCS
from app.config import get_settings
from app.db import Wallet
from app.logging_conf import log
from app.wallet.crypto import decrypt_key

_SRC_SOL = "11111111111111111111111111111111"
_DST_NATIVE = "0x0000000000000000000000000000000000000000"
_DST_CHAIN = {"ethereum": "1", "eth": "1", "base": "8453", "bsc": "56", "arbitrum": "42161"}
_GAS = {"ethereum": 0.0015, "eth": 0.0015, "base": 0.0004, "bsc": 0.0008, "arbitrum": 0.0004}
_SOL_KEEP = 20_000_000
_API = "https://dln.debridge.finance/v1.0/dln/order/create-tx"


class BridgeError(RuntimeError):
    pass


def _wei(chain: str, address: str) -> int:
    rpc = _CHAIN_RPCS[chain]()
    w3 = Web3(Web3.HTTPProvider(rpc, request_kwargs={"timeout": 8}))
    return int(w3.eth.get_balance(Web3.to_checksum_address(address)))


async def _wei_async(chain: str, address: str) -> int:
    return await asyncio.to_thread(_wei, chain, address)


async def _sol_lamports(address: str) -> int:
    body = {"jsonrpc": "2.0", "id": 1, "method": "getBalance", "params": [address]}
    async with httpx.AsyncClient(timeout=12.0) as cli:
        r = await cli.post(get_settings().SOLANA_RPC, json=body)
        r.raise_for_status()
        return int((r.json().get("result") or {}).get("value") or 0)


async def fund_evm_from_sol(session, user_id: int, dest_chain: str, evm_address: str, need_native: float) -> str | None:
    """Bridge SOL to native on dest_chain if the EVM wallet is short. Returns the tx sig, or None."""
    chain = dest_chain.lower()
    if chain not in _DST_CHAIN or chain not in _CHAIN_RPCS:
        raise BridgeError(f"bridge: unsupported chain {dest_chain}")
    have = await _wei_async(chain, evm_address)
    need = int((need_native + _GAS[chain]) * 1e18)
    if have >= need:
        return None
    short = need - have
    sol_wallet = (
        await session.execute(
            select(Wallet).where(and_(Wallet.user_id == user_id, Wallet.chain == "solana"))
        )
    ).scalar_one_or_none()
    if sol_wallet is None:
        raise BridgeError("bridge: no solana wallet")
    address = sol_wallet.address
    enc, nonce, salt = sol_wallet.encrypted_key, sol_wallet.nonce, sol_wallet.salt
    await session.commit()
    bal = await _sol_lamports(address)
    # A small SOL wallet cannot fund Base/ETH/BSC. Skip before the slow quote.
    if bal < _SOL_KEEP + 30_000_000:
        raise BridgeError(
            f"Skipped {chain}. Not enough SOL to bridge. Wallet has {bal / 1e9:.4f} SOL."
        )
    params = {
        "srcChainId": "7565164",
        "srcChainTokenIn": _SRC_SOL,
        "srcChainTokenInAmount": "auto",
        "dstChainId": _DST_CHAIN[chain],
        "dstChainTokenOut": _DST_NATIVE,
        "dstChainTokenOutAmount": str(short),
        "dstChainTokenOutRecipient": evm_address,
        "srcChainOrderAuthorityAddress": address,
        "dstChainOrderAuthorityAddress": evm_address,
        "prependOperatingExpenses": "true",
    }
    async with httpx.AsyncClient(timeout=25.0) as cli:
        r = await cli.get(_API, params=params)
        if r.status_code != 200:
            raise BridgeError(f"bridge quote {r.status_code}: {r.text[:160]}")
        data = r.json()
    src = ((data.get("estimation") or {}).get("srcChainTokenIn") or {})
    spend = int(src.get("amount") or 0)
    if spend <= 0:
        raise BridgeError("bridge quote returned no SOL amount")
    if spend + 5_000_000 > bal - _SOL_KEEP:
        raise BridgeError(
            f"Skipped {chain}. Need {spend / 1e9:.4f} SOL to bridge, wallet has {bal / 1e9:.4f} SOL."
        )
    raw_hex = ((data.get("tx") or {}).get("data") or "")
    if not raw_hex.startswith("0x"):
        raise BridgeError("bridge quote returned no solana tx")
    secret = decrypt_key(enc, nonce, salt, aad=address.encode())
    try:
        sig = await solana_jupiter.sign_and_send(
            raw_tx=bytes.fromhex(raw_hex[2:]), secret_key=secret,
        )
    finally:
        secret = b"\x00" * len(secret)
    order_id = str(data.get("orderId") or "")[:18]
    log().info("bridge.sent", chain=chain, sol=round(spend / 1e9, 4), tx=sig[:16], order=order_id)
    for _ in range(8):
        await asyncio.sleep(4)
        if await _wei_async(chain, evm_address) >= need:
            log().info("bridge.landed", chain=chain, tx=sig[:16])
            return sig
    raise BridgeError(f"bridge tx {sig} sent, {chain} funds not in yet")
