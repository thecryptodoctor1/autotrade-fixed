"""Platform fee collection — send SOL to treasury as a separate on-chain tx.

Fires before every buy (and can be extended to fire after every sell). Kept
tiny and self-contained so it doesn't drag anything down.
"""
from __future__ import annotations

import base64

import httpx
from solders.hash import Hash
from solders.keypair import Keypair
from solders.message import MessageV0
from solders.pubkey import Pubkey
from solders.system_program import TransferParams, transfer
from solders.transaction import VersionedTransaction

from app.config import get_settings


async def send_sol_fee(
    *,
    from_secret: bytes,
    from_pubkey: str,
    to_pubkey: str,
    lamports: int,
) -> str | None:
    """Transfer SOL from user to treasury. Returns tx signature or None on fail.

    Uses a plain SystemProgram transfer (~5000 lamports network fee). The
    lamports arg is the fee AMOUNT the user pays to operator (excludes network
    fee, which is paid by the user's wallet on top).
    """
    if lamports <= 0:
        return None
    s = get_settings()
    kp = Keypair.from_bytes(from_secret)
    from_pk = Pubkey.from_string(from_pubkey)
    to_pk = Pubkey.from_string(to_pubkey)

    async with httpx.AsyncClient(timeout=10.0) as cli:
        # 1) latest blockhash
        r = await cli.post(
            s.SOLANA_RPC,
            json={"jsonrpc": "2.0", "id": 1, "method": "getLatestBlockhash", "params": []},
        )
        if r.status_code != 200:
            return None
        bh = (((r.json() or {}).get("result") or {}).get("value") or {}).get("blockhash")
        if not bh:
            return None
        # 2) build message
        ix = transfer(TransferParams(from_pubkey=from_pk, to_pubkey=to_pk, lamports=lamports))
        msg = MessageV0.try_compile(
            payer=from_pk, instructions=[ix], address_lookup_table_accounts=[],
            recent_blockhash=Hash.from_string(bh),
        )
        tx = VersionedTransaction(msg, [kp])
        raw = base64.b64encode(bytes(tx)).decode()
        # 3) send
        r = await cli.post(
            s.SOLANA_RPC,
            json={
                "jsonrpc": "2.0", "id": 1, "method": "sendTransaction",
                "params": [raw, {"encoding": "base64", "skipPreflight": False}],
            },
        )
        if r.status_code != 200:
            return None
        result = (r.json() or {}).get("result")
        return str(result) if result else None
