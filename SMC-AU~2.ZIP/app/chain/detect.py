"""Detect which chain a CA belongs to using format + DexScreener.

For an EVM CA, DexScreener may return multiple chains (ETH+BSC+Base+Arb
often carry the same-looking address for different tokens). Pick the pool
with the highest 24h USD liquidity and expose it as ``chain`` in the receipt.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import httpx

from app.config import get_settings

# Priority order when DexScreener has no data — matches signal spec.
_EVM_FALLBACK_CHAINS = ("base", "bsc", "ethereum", "arbitrum")


@dataclass(slots=True)
class ChainInfo:
    chain: str            # solana | ethereum | base | bsc | arbitrum
    ca: str
    pool_address: Optional[str] = None
    liquidity_usd: Optional[float] = None
    price_usd: Optional[float] = None
    dex: Optional[str] = None
    symbol: Optional[str] = None


async def _dexscreener_lookup(ca: str) -> list[dict]:
    url = f"{get_settings().DEXSCREENER}/latest/dex/tokens/{ca}"
    async with httpx.AsyncClient(timeout=8.0) as cli:
        try:
            r = await cli.get(url)
            if r.status_code != 200:
                return []
            data = r.json() or {}
            return data.get("pairs") or []
        except Exception:
            return []


async def detect_chain_and_pool(ca: str, format_hint: str) -> ChainInfo:
    """Merge format hint with DexScreener response.

    ``format_hint`` is ``"solana"`` or ``"evm"`` — from the parser.
    Solana always resolves as solana; EVM picks the best pool if data exists.
    """
    if format_hint == "solana":
        pairs = await _dexscreener_lookup(ca)
        sol_pairs = [p for p in pairs if (p.get("chainId") == "solana")]
        if sol_pairs:
            best = max(sol_pairs, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)
            return ChainInfo(
                chain="solana",
                ca=ca,
                pool_address=best.get("pairAddress"),
                liquidity_usd=(best.get("liquidity") or {}).get("usd"),
                price_usd=float(best.get("priceUsd") or 0) or None,
                dex=best.get("dexId"),
                symbol=(best.get("baseToken") or {}).get("symbol"),
            )
        return ChainInfo(chain="solana", ca=ca)

    # EVM path
    pairs = await _dexscreener_lookup(ca)
    if pairs:
        best = max(pairs, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)
        chain_id = (best.get("chainId") or "ethereum").lower()
        return ChainInfo(
            chain=chain_id,
            ca=ca,
            pool_address=best.get("pairAddress"),
            liquidity_usd=(best.get("liquidity") or {}).get("usd"),
            price_usd=float(best.get("priceUsd") or 0) or None,
            dex=best.get("dexId"),
            symbol=(best.get("baseToken") or {}).get("symbol"),
        )
    # No data — default to first configured EVM chain; downstream swap will fail
    # cleanly if there's no route.
    return ChainInfo(chain=_EVM_FALLBACK_CHAINS[0], ca=ca)
