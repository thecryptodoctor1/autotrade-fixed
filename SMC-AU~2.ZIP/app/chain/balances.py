"""Fetch wallet balances across chains for the /wallet expert view."""
from __future__ import annotations

from dataclasses import dataclass

import httpx

from app.config import get_settings


@dataclass(slots=True)
class BalanceSet:
    sol: float = 0.0
    eth: float = 0.0
    base_eth: float = 0.0
    bsc_bnb: float = 0.0
    arb_eth: float = 0.0
    usdc_sol: float = 0.0
    sol_usd_price: float | None = None
    eth_usd_price: float | None = None
    bnb_usd_price: float | None = None

    @property
    def total_usd(self) -> float:
        t = 0.0
        if self.sol_usd_price:
            t += self.sol * self.sol_usd_price
            t += self.usdc_sol  # USDC ~ $1
        if self.eth_usd_price:
            t += (self.eth + self.base_eth + self.arb_eth) * self.eth_usd_price
        if self.bnb_usd_price:
            t += self.bsc_bnb * self.bnb_usd_price
        return t


async def _rpc(url: str, method: str, params: list) -> dict | None:
    async with httpx.AsyncClient(timeout=5.0) as cli:
        try:
            r = await cli.post(url, json={"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
    return None


async def _sol_balance(addr: str) -> float:
    s = get_settings()
    j = await _rpc(s.SOLANA_RPC, "getBalance", [addr])
    if not j:
        return 0.0
    v = (j.get("result") or {}).get("value")
    return (v or 0) / 1_000_000_000


async def _sol_usdc(addr: str) -> float:
    """USDC SPL token balance for a Solana wallet."""
    s = get_settings()
    usdc = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    j = await _rpc(
        s.SOLANA_RPC, "getTokenAccountsByOwner",
        [addr, {"mint": usdc}, {"encoding": "jsonParsed"}]
    )
    if not j:
        return 0.0
    accs = (j.get("result") or {}).get("value") or []
    total = 0.0
    for a in accs:
        try:
            info = (((a.get("account") or {}).get("data") or {}).get("parsed") or {}).get("info") or {}
            amt = (info.get("tokenAmount") or {}).get("uiAmount")
            if amt:
                total += float(amt)
        except Exception:
            pass
    return total


async def _evm_balance(rpc: str, addr: str) -> float:
    j = await _rpc(rpc, "eth_getBalance", [addr, "latest"])
    if not j:
        return 0.0
    hex_val = j.get("result") or "0x0"
    try:
        return int(hex_val, 16) / 1e18
    except Exception:
        return 0.0


async def _price_usd(mint_or_sym: str) -> float | None:
    """Jupiter for SOL, DexScreener for others."""
    async with httpx.AsyncClient(timeout=5.0) as cli:
        try:
            url = f"{get_settings().JUPITER_PRICE}/price?ids={mint_or_sym}"
            r = await cli.get(url)
            if r.status_code == 200:
                d = (r.json() or {}).get("data") or {}
                v = (d.get(mint_or_sym) or {}).get("price")
                if v:
                    return float(v)
        except Exception:
            pass
    return None


async def fetch_all(sol_addr: str, evm_addr: str) -> BalanceSet:
    s = get_settings()
    bs = BalanceSet()
    bs.sol = await _sol_balance(sol_addr)
    bs.usdc_sol = await _sol_usdc(sol_addr)
    bs.eth = await _evm_balance(s.ETH_RPC, evm_addr)
    bs.base_eth = await _evm_balance(s.BASE_RPC, evm_addr)
    bs.bsc_bnb = await _evm_balance(s.BSC_RPC, evm_addr)
    bs.arb_eth = await _evm_balance(s.ARB_RPC, evm_addr)
    # prices
    bs.sol_usd_price = await _price_usd("So11111111111111111111111111111111111111112")
    bs.eth_usd_price = await _price_usd("7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs")  # WETH on SOL
    if bs.eth_usd_price is None:
        bs.eth_usd_price = 3000.0  # sane fallback
    bs.bnb_usd_price = 600.0  # rough fallback; refine later
    return bs
