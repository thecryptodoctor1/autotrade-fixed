"""Live prices. Pump.fun first, because DexScreener lags the chart."""
from __future__ import annotations

import httpx

from app.config import get_settings


async def _pump_mark(ca: str) -> dict | None:
    """Official pump market cap. This is the number the chart is closest to."""
    try:
        async with httpx.AsyncClient(timeout=4.0) as cli:
            r = await cli.get(
                f"https://frontend-api-v3.pump.fun/coins-v2/{ca}",
                headers={"User-Agent": "Mozilla/5.0"},
            )
        if r.status_code != 200:
            return None
        data = r.json() or {}
        mc = float(data.get("usd_market_cap") or data.get("market_cap_usd") or 0)
        if mc <= 0:
            return None
        decimals = int(data.get("base_decimals") or 6)
        supply = 1_000_000_000.0
        try:
            raw = float(data.get("total_supply") or 0)
            if raw > 0:
                supply = raw / (10 ** decimals)
        except (TypeError, ValueError):
            supply = 1_000_000_000.0
        sym = (data.get("symbol") or "").strip()
        if "http" in sym.lower() or len(sym) > 12:
            sym = ""
        ath = float(data.get("ath_market_cap") or data.get("ath_market_cap_usd") or 0)
        return {
            "px": mc / supply if supply else None,
            "mc": mc,
            "ath": ath,
            "sym": sym,
            "decimals": decimals,
        }
    except Exception:
        return None


async def live_mark(ca: str) -> dict:
    """usd price, decimals, symbol and market cap.

    px is the high print (Pump, else the higher of Jupiter and Dex) so a
    fast candle can take profit. px_lo is the low print so a dump still stops.
    """
    import asyncio

    async def _jup() -> tuple[float | None, int]:
        try:
            async with httpx.AsyncClient(timeout=3.0) as cli:
                r = await cli.get(f"https://lite-api.jup.ag/price/v3?ids={ca}")
            if r.status_code != 200:
                return None, 6
            row = (r.json() or {}).get(ca) or {}
            px = float(row["usdPrice"]) if row.get("usdPrice") else None
            return px, int(row.get("decimals") or 6)
        except Exception:
            return None, 6

    async def _dex() -> tuple[float | None, float, str]:
        try:
            s = get_settings()
            async with httpx.AsyncClient(timeout=3.0) as cli:
                r = await cli.get(f"{s.DEXSCREENER}/latest/dex/tokens/{ca}")
            if r.status_code != 200:
                return None, 0.0, ""
            pairs = (r.json() or {}).get("pairs") or []
            if not pairs:
                return None, 0.0, ""

            def _score(p: dict) -> tuple:
                tx = (p.get("txns") or {}).get("m5") or {}
                n = (tx.get("buys") or 0) + (tx.get("sells") or 0)
                vol = (p.get("volume") or {}).get("m5") or 0
                return (n, vol)

            best = max(pairs, key=_score)
            px = float(best.get("priceUsd") or 0) or None
            mc = float(best.get("marketCap") or best.get("fdv") or 0)
            sym = ((best.get("baseToken") or {}).get("symbol") or "").strip()
            if "http" in sym.lower() or len(sym) > 12:
                sym = ""
            return px, mc, sym
        except Exception:
            return None, 0.0, ""

    pump, (jup, decimals), (dex_px, dex_mc, dex_sym) = await asyncio.gather(
        _pump_mark(ca), _jup(), _dex()
    )
    highs = [p for p in (
        (pump or {}).get("px"),
        jup,
        dex_px,
    ) if p and p > 0]
    if not highs:
        return {"px": None, "px_lo": None, "decimals": 6, "mc": 0.0, "sym": ""}
    px_hi = max(highs)
    px_lo = min(highs)
    mc = float((pump or {}).get("mc") or 0) or dex_mc
    if not mc and str(ca).lower().endswith("pump"):
        mc = px_hi * 1_000_000_000
    pump_px = float((pump or {}).get("px") or 0)
    dex = float(dex_px or 0)
    # Jupiter bids sit under the chart and caused fake stops. Ignore them.
    sane = [p for p in (pump_px, dex) if p > 0]
    if not sane:
        sane = [p for p in highs if p > 0]
    hi = max(sane) if sane else 0.0
    lo = min(sane) if sane else 0.0
    if hi > 0 and lo > 0 and hi > lo * 3:
        # One feed is garbage. Keep Pump, else the higher print.
        hi = pump_px or hi
        lo = hi
    sym = ((pump or {}).get("sym") or dex_sym or "")
    ath = float((pump or {}).get("ath") or 0)
    return {
        "px": hi,
        "px_lo": lo or hi,
        "decimals": int((pump or {}).get("decimals") or decimals or 6),
        "mc": mc or (hi * 1_000_000_000 if str(ca).lower().endswith("pump") else 0.0),
        "ath": ath,
        "sym": sym,
    }


async def get_price_usd(ca: str, chain: str) -> float | None:
    """Best-effort price lookup. Returns None if no source responds."""
    mark = await live_mark(ca)
    if mark.get("px"):
        return float(mark["px"])
    return None


async def sol_price_usd() -> float | None:
    """Live SOL price. None when every source failed. Never invent $150."""
    px = await get_price_usd("So11111111111111111111111111111111111111112", "solana")
    if px and px > 5:
        return float(px)
    return None
