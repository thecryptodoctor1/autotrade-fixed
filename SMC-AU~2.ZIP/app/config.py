"""Typed settings loaded from .env."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(ROOT / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Telegram
    BOT_TOKEN: str = ""
    BOT_USERNAME: str = ""
    ADMIN_IDS: str = ""
    SIGNAL_CHAT_IDS: str = ""
    SIGNAL_INGEST: Literal["bot_api", "telethon"] = "bot_api"

    # Telethon
    TELETHON_API_ID: int = 0
    TELETHON_API_HASH: str = ""
    TELETHON_SESSION_STRING: str = ""

    # DB
    DATABASE_URL: str = "sqlite+aiosqlite:///data/smc.db"

    # Security
    WALLET_MASTER_KEY: str = ""   # base64 32+ bytes
    PIN_PEPPER: str = ""           # base64 32+ bytes
    KEY_ROTATION_ID: str = "v1"

    # Chains
    SOLANA_RPC: str = "https://api.mainnet-beta.solana.com"
    SOLANA_RPC_FALLBACK: str = "https://solana-rpc.publicnode.com"
    HELIUS_API_KEY: str = ""
    JITO_TIP_SOL: float = 0.001
    ETH_RPC: str = "https://eth.llamarpc.com"
    BASE_RPC: str = "https://mainnet.base.org"
    BSC_RPC: str = "https://bsc-dataseed.binance.org"
    ARB_RPC: str = "https://arb1.arbitrum.io/rpc"

    # Aggregators
    JUPITER_QUOTE: str = "https://lite-api.jup.ag/swap/v1"
    JUPITER_API_KEY: str = ""
    JUPITER_PRICE: str = "https://price.jup.ag/v6"
    ZEROX_BASE: str = "https://api.0x.org"
    ZEROX_API_KEY: str = ""
    DEXSCREENER: str = "https://api.dexscreener.com"

    # Intel (optional)
    FEATURES_GMGN: bool = False
    GMGN_API_KEY: str = ""

    # Subscription
    SUB_PRICE_USD: float = 49.0
    SUB_DURATION_DAYS: int = 30
    OPERATOR_TREASURY_SOL: str = ""
    REFERRAL_PCT: float = 20.0
    REFERRAL_FIRST_N: int = 3

    # Defaults
    DEFAULT_RISK_PRESET: Literal["SAFE", "STANDARD", "DEGEN"] = "STANDARD"
    DUPLICATE_COOLDOWN_MIN: int = 30
    DAILY_AUTOBUY_CAP_USD: float = 0.0

    # ─── Demo mode ─────────────────────────────────────────────────────────
    DEMO_MODE: bool = False

    # ─── Platform fees (operator revenue on top of $49/mo) ─────────────────
    # Charged on every buy AND sell. 100 bps = 1%. Competitors: Trojan 1%,
    # GMGN 1%, BonkBot 1%. Anything above 200 bps (2%) users will notice.
    FEE_BPS_BUY: int = 100        # 1.00% on buys
    FEE_BPS_SELL: int = 100       # 1.00% on sells
    FEE_TREASURY_SOL: str = ""    # empty → falls back to OPERATOR_TREASURY_SOL
    FEE_TREASURY_EVM: str = ""    # optional, empty = skip EVM fee collection

    # Ops
    LOG_LEVEL: str = "INFO"
    LOG_JSON: bool = True
    PRICE_POLL_SOL_SECS: int = 3
    PRICE_POLL_EVM_SECS: int = 8

    @property
    def admin_ids(self) -> list[int]:
        return [int(x) for x in self.ADMIN_IDS.split(",") if x.strip()]

    @property
    def signal_chat_ids(self) -> list[int]:
        return [int(x) for x in self.SIGNAL_CHAT_IDS.split(",") if x.strip()]

    @field_validator("WALLET_MASTER_KEY", "PIN_PEPPER")
    @classmethod
    def _b64_present_or_empty(cls, v: str) -> str:
        return v.strip()

    @model_validator(mode="after")
    def _use_paid_solana(self):
        key = (self.HELIUS_API_KEY or "").strip()
        if key and "mainnet-beta.solana.com" in self.SOLANA_RPC:
            self.SOLANA_RPC = f"https://mainnet.helius-rpc.com/?api-key={key}"
        if (self.JUPITER_API_KEY or "").strip():
            host = self.JUPITER_QUOTE or ""
            if "lite-api.jup.ag" in host or "quote-api.jup.ag" in host or not host:
                self.JUPITER_QUOTE = "https://api.jup.ag/swap/v1"
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
