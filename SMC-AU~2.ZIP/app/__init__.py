"""SMC AutoTrade — Telegram signal auto-buy bot."""
__version__ = "0.1.0"
