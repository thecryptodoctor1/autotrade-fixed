from aiogram import Router

from .core import router as core_router
from .desk import router as desk_router
from .noob import router as noob_router
from .premium import router as premium_router
from .trading import router as trading_router

router = Router()
router.include_router(desk_router)
router.include_router(premium_router)
router.include_router(noob_router)
router.include_router(trading_router)
router.include_router(core_router)

__all__ = ["router"]
