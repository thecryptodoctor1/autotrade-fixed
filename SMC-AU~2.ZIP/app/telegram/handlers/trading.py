"""Expert-mode Telegram handlers.

Upgrades over v1:
  * /wallet — live balances (SOL/ETH/BNB/USDC), open positions count, deposit
    QR-friendly copy, quick action buttons.
  * /subscribe — countdown timer, real-time sub status, referral savings tip.
  * /risk — includes a SMART mode that reads real signal outcomes and picks
    the preset + sizing for you.
  * /referral — vanity ref codes ("t.me/bot?start=ref_YOURNAME") + live earnings.
  * /export — PIN-gated with lockout after 5 failed attempts.
  * Every action gives a rich receipt with next-step CTAs (max CRO).
"""
from __future__ import annotations

import asyncio
import re
from datetime import datetime, timedelta, timezone

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from sqlalchemy import and_, func, select

from app.billing.subscribe import create_invoice
from app.chain.balances import fetch_all
from app.config import get_settings
from app.db import (
    Fill,
    Order,
    Position,
    Referral,
    Subscription,
    User,
    Wallet,
    get_session,
)
from app.logging_conf import log
from app.pnl.card import PnLSummary, render_pnl_card
from app.risk.presets import PRESETS
from app.risk.smart import compute_smart
from app.signals.parser import parse_message
from app.wallet.crypto import decrypt_key
from app.wallet.generate import solana_secret_to_b58
from app.wallet.pin import check_pin_rules, hash_pin, verify_pin
from app.worker.executor import execute_buy, execute_sell

router = Router()

# ─── UI helpers ─────────────────────────────────────────────────────────────

def _fmt_usd(v: float) -> str:
    if v >= 1000:
        return f"${v:,.0f}"
    return f"${v:.2f}"


def _sub_status_line(sub: Subscription | None) -> tuple[str, str]:
    """Return (badge, description) for sub status."""
    if sub is None:
        return ("❌ INACTIVE", "No subscription. Auto-buy is off. Use /subscribe.")
    if (sub.plan == "lifetime" or sub.status == "lifetime") and sub.status in ("active", "lifetime"):
        return ("✅ LIFETIME", "Lifetime plan. Auto-buy is on.")
    exp = sub.expires_at
    if exp is None or sub.status not in ("active", "lifetime", "trial"):
        return ("❌ INACTIVE", "No subscription. Auto-buy is off. Use /subscribe.")
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    if sub.status not in ("active", "lifetime", "trial") or exp <= now:
        return ("⚠️ EXPIRED", f"Expired {exp:%Y-%m-%d}. Renew via /subscribe.")
    remaining = exp - now
    days = remaining.days
    hours = remaining.seconds // 3600
    if days > 3:
        return ("✅ ACTIVE", f"{days} days left · expires {exp:%Y-%m-%d}")
    if days > 0:
        return ("⏳ EXPIRING", f"Only {days}d {hours}h left · renew soon")
    return ("🚨 GRACE", f"Expires in {hours}h — renew now to avoid pause")


async def _get_active_sub(session, user_id: int) -> Subscription | None:
    rows = (
        await session.execute(
            select(Subscription).where(Subscription.user_id == user_id)
            .order_by(Subscription.id.desc())
        )
    ).scalars().all()
    now = datetime.now(timezone.utc)
    for row in rows:
        exp = row.expires_at
        if exp is not None and exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if row.status in ("active", "lifetime", "trial") and exp and exp > now:
            return row
    return rows[0] if rows else None


# ─── /buy /sell /positions /orders /pause /resume (unchanged from v1) ───────

@router.message(Command("buy"))
async def cmd_buy(msg: Message) -> None:
    parts = (msg.text or "").split()
    if len(parts) < 2:
        await msg.answer("Usage: <code>/buy &lt;CA&gt; [amount_native]</code>", parse_mode="HTML")
        return
    parsed = parse_message(parts[1])
    if parsed is None:
        await msg.answer("Couldn't recognise that as a CA.")
        return
    amount = None
    if len(parts) >= 3:
        try:
            amount = float(parts[2])
        except ValueError:
            await msg.answer("Amount must be a number.")
            return
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
    if u is None:
        await msg.answer("Run /start first.")
        return
    await msg.answer("⏳ Submitting buy…")
    await execute_buy(
        bot=msg.bot, user_id=u.id, ca=parsed.ca, chain_hint=parsed.chain,
        kind="manual", override_amount_native=amount,
    )


@router.message(Command("sell"))
async def cmd_sell(msg: Message) -> None:
    parts = (msg.text or "").split()
    if len(parts) < 2:
        await msg.answer("Usage: <code>/sell &lt;CA&gt; [25|50|100|all]</code>", parse_mode="HTML")
        return
    parsed = parse_message(parts[1])
    if parsed is None:
        await msg.answer("Couldn't recognise that as a CA.")
        return
    pct_arg = parts[2].lower() if len(parts) >= 3 else "100"
    if pct_arg in ("all", "100"):
        pct = 1.0
    else:
        try:
            pct = float(pct_arg) / 100.0
        except ValueError:
            await msg.answer("Pct must be 25 / 50 / 100 / all.")
            return
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
    if u is None:
        await msg.answer("Run /start first.")
        return
    await msg.answer(f"⏳ Selling {int(pct*100)}%…")
    await execute_sell(bot=msg.bot, user_id=u.id, ca=parsed.ca, pct=pct)


@router.message(Command("positions"))
async def cmd_positions(msg: Message) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        rows = (
            await s.execute(
                select(Position).where(and_(Position.user_id == u.id, Position.tokens_open > 0))
                .order_by(Position.id.desc())
            )
        ).scalars().all()
    if not rows:
        await msg.answer("No open positions. Waiting for signals ⏳")
        return
    lines = ["<b>📊 Open positions</b>\n"]
    for p in rows:
        pnl_x = 0.0
        if p.avg_entry_native > 0 and p.hwm_price_native > 0:
            pnl_x = p.hwm_price_native / p.avg_entry_native
        emoji = "🚀" if pnl_x >= 2 else "🔥" if pnl_x >= 1.5 else "💎" if pnl_x >= 1 else "⏳"
        lines.append(
            f"{emoji} <code>{p.ca[:10]}…</code> · {p.chain}\n"
            f"   {p.tokens_open:g} tokens · peak {pnl_x:.2f}x · {p.ladder_state}"
        )
    await msg.answer("\n".join(lines), parse_mode="HTML")


@router.message(Command("orders"))
async def cmd_orders(msg: Message) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        rows = (
            await s.execute(
                select(Order).where(Order.user_id == u.id)
                .order_by(Order.id.desc()).limit(10)
            )
        ).scalars().all()
    if not rows:
        await msg.answer("No orders yet. Deposit and wait for a signal.")
        return
    lines = ["<b>📜 Last 10 orders</b>\n"]
    for o in rows:
        badge = {"sent": "✅", "filled": "✅", "failed": "❌", "pending": "⏳", "cancelled": "🚫"}.get(o.status, "•")
        lines.append(
            f"{badge} {o.side} {o.kind} <code>{o.ca[:8]}…</code> {o.chain}"
            + (f" ({o.fail_reason})" if o.fail_reason else "")
        )
    await msg.answer("\n".join(lines), parse_mode="HTML")


@router.message(Command("pause"))
async def cmd_pause(msg: Message) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        u.auto_paused = True
    await msg.answer("⏸ Auto-buy <b>PAUSED</b>. Manual /buy and /sell still work.", parse_mode="HTML")


@router.message(Command("resume"))
async def cmd_resume(msg: Message) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        u.auto_paused = False
    await msg.answer("▶️ Auto-buy <b>ACTIVE</b>. Watching signals now.", parse_mode="HTML")


# ─── /wallet — EXPERT view with live balances ───────────────────────────────

@router.message(Command("wallet"))
async def cmd_wallet(msg: Message) -> None:
    await _send_wallet_view(msg)


@router.callback_query(F.data == "menu:wallet")
async def cb_wallet(cb: CallbackQuery) -> None:
    try:
        await _send_wallet_view(cb.message, tg_id=cb.from_user.id)
    except Exception as e:
        log().exception("wallet.fail")
        await cb.message.answer(f"Wallet could not open. {type(e).__name__}")
    await cb.answer()


@router.callback_query(F.data == "wallet:refresh")
async def cb_wallet_refresh(cb: CallbackQuery) -> None:
    await cb.answer("Refreshing balances…")
    await _send_wallet_view(cb.message, tg_id=cb.from_user.id)


async def _wallet_coins(addr: str) -> list[str]:
    """SPL coins in the Solana wallet. Dust under $0.20 is skipped."""
    from app.chain.prices import live_mark, sol_price_usd
    from app.chain.solana_jupiter import wallet_mints

    held = await wallet_mints(addr)
    if not held:
        return []
    sol_px = await sol_price_usd() or 0.0
    metas = await asyncio.gather(
        *[live_mark(ca) for ca, _ui in held[:20]],
        return_exceptions=True,
    )
    rows = []
    for (ca, ui), meta in zip(held[:20], metas):
        if isinstance(meta, Exception):
            meta = {}
        px = float((meta or {}).get("px") or 0)
        usd = ui * px if px else 0.0
        if usd < 0.20:
            continue
        sym = ((meta or {}).get("sym") or "").strip() or (ca[:4] + "…" + ca[-4:])
        sol_v = (usd / sol_px) if sol_px else 0.0
        rows.append((usd, f"{sym} · <b>{sol_v:.4f} SOL</b> · about ${usd:.2f}"))
    rows.sort(key=lambda r: r[0], reverse=True)
    return [line for _usd, line in rows[:8]]


async def _send_wallet_view(msg: Message, tg_id: int | None = None) -> None:
    tg_id = tg_id or msg.chat.id
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        wallets = (
            await s.execute(select(Wallet).where(Wallet.user_id == u.id))
        ).scalars().all()
        sub = await _get_active_sub(s, u.id)
        n_positions = (
            await s.execute(
                select(func.count(Position.id)).where(
                    and_(Position.user_id == u.id, Position.tokens_open > 0)
                )
            )
        ).scalar_one()

    sol_w = next((w for w in wallets if w.chain == "solana"), None)
    evm_w = next((w for w in wallets if w.chain == "evm"), None)

    balances_line = "⏳ Fetching balances…"
    lines = [
        "💎 <b>Your SMC AutoTrade Wallet</b>",
        "",
    ]
    sub_badge, sub_desc = _sub_status_line(sub)
    lines.append(f"{sub_badge} · {sub_desc}")
    lines.append(f"📊 Open positions: <b>{n_positions}</b>  ·  Preset: <b>{u.risk_preset}</b>"
                 + (" · SMART" if u.smart_mode else ""))
    lines.append("")

    # Placeholder — send fast, then edit with balances
    if sol_w:
        lines.append("<b>Solana</b>")
        lines.append(f"<code>{sol_w.address}</code>")
        lines.append("")
    if evm_w:
        lines.append("<b>EVM (ETH · Base · BSC · Arbitrum)</b>")
        lines.append(f"<code>{evm_w.address}</code>")
        lines.append("")
    lines.append(balances_line)
    lines.append("")
    lines.append("⚠️ <b>Never share your private key.</b> Only the addresses above are safe to share.")

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Refresh", callback_data="wallet:refresh"),
            InlineKeyboardButton(text="🔓 Export keys", callback_data="wallet:export"),
        ],
        [
            InlineKeyboardButton(text="📊 Positions", callback_data="menu:positions"),
            InlineKeyboardButton(text="💎 Subscribe", callback_data="menu:sub"),
        ],
    ])

    sent = await msg.answer("\n".join(lines), parse_mode="HTML", reply_markup=kb)

    # async fetch + edit
    if sol_w and evm_w:
        try:
            bal = await fetch_all(sol_w.address, evm_w.address)
            bal_lines = [
                "<b>💰 Balances</b>",
                f"◎ SOL: <b>{bal.sol:.4f}</b>  ·  USDC: <b>{bal.usdc_sol:.2f}</b>",
                f"Ξ ETH: <b>{bal.eth:.4f}</b>  ·  Base: <b>{bal.base_eth:.4f}</b>  ·  Arb: <b>{bal.arb_eth:.4f}</b>",
                f"🟡 BNB: <b>{bal.bsc_bnb:.4f}</b>",
                f"<b>Total ≈ {_fmt_usd(bal.total_usd)}</b>",
            ]
            coins = await _wallet_coins(sol_w.address)
            if coins:
                bal_lines.append("")
                bal_lines.append("<b>Coins in this wallet</b>")
                bal_lines.extend(coins)
            else:
                bal_lines.append("")
                bal_lines.append("No coin above $0.20 in this wallet right now.")
            new_text = "\n".join(lines).replace(balances_line, "\n".join(bal_lines))
            try:
                await sent.edit_text(new_text, parse_mode="HTML", reply_markup=kb)
            except Exception:
                pass
        except Exception as e:
            log().warning("wallet.balance_err", err=str(e))


# ─── /subscribe — expert with countdown + CRO copy ──────────────────────────

@router.message(Command("subscribe"))
async def cmd_subscribe(msg: Message) -> None:
    await _send_sub_view(msg)


@router.callback_query(F.data == "menu:sub")
async def cb_sub(cb: CallbackQuery) -> None:
    try:
        await _send_sub_view(cb.message, tg_id=cb.from_user.id)
    except Exception as e:
        log().exception("sub.fail")
        await cb.message.answer(f"Subscribe could not open. {type(e).__name__}")
    await cb.answer()


async def _send_sub_view(msg: Message, tg_id: int | None = None) -> None:
    tg_id = tg_id or msg.chat.id
    s = get_settings()
    async with get_session() as ss:
        u = (await ss.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        sub = await _get_active_sub(ss, u.id)
        # find referrals that user got credit from
        credit_row = (
            await ss.execute(
                select(func.coalesce(func.sum(Referral.credit_days_earned), 0))
                .where(Referral.referrer_id == u.id)
            )
        ).scalar_one() or 0

    badge, desc = _sub_status_line(sub)
    lines = [
        "💎 <b>SMC AutoTrade Subscription</b>",
        "",
        f"Status: {badge}",
        f"{desc}",
        "",
        f"💰 Price: <b>${s.SUB_PRICE_USD:.0f} / {s.SUB_DURATION_DAYS} days</b>",
        f"🎁 Referral credit earned: <b>{credit_row}</b> days (added to your subscription)",
        "",
    ]

    exp = sub.expires_at if sub else None
    if exp is not None and exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    live = (
        sub is not None
        and sub.status in ("active", "lifetime", "trial")
        and exp is not None
        and exp > datetime.now(timezone.utc)
    )
    sol_px = None
    try:
        from app.chain.prices import sol_price_usd
        sol_px = await sol_price_usd()
    except Exception:
        sol_px = None
    if not sol_px:
        lines.append("SOL price is not loading. Tap Subscribe again in a minute.")
    elif not live:
        # Generate live invoice
        try:
            invoice = await create_invoice(u.tg_id, sol_usd=sol_px)
            amount_sol = invoice.invoice_amount_lamports / 1_000_000_000
            lines += [
                "🔥 <b>Ready to activate?</b>",
                "",
                f"Send <b>exactly {amount_sol:.6f} SOL</b> to:",
                f"<code>{s.OPERATOR_TREASURY_SOL}</code>",
                "",
                f"Invoice: <code>{invoice.invoice_memo}</code>",
                "Auto-detected within 20 seconds of confirmation.",
                "",
                "💡 <i>1 good call pays for the month.</i>",
            ]
        except Exception:
            lines.append("⚠️ Treasury not configured yet — check back soon.")
    else:
        left = exp - datetime.now(timezone.utc)
        lines += [
            f"✅ <b>Active</b> · {left.days}d {left.seconds // 3600}h left.",
            "Auto-buy stays on.",
            "",
            "🔥 <b>Add 30 days now.</b> Time you already have is kept.",
        ]
        try:
            invoice = await create_invoice(u.tg_id, sol_usd=sol_px)
            amount_sol = invoice.invoice_amount_lamports / 1_000_000_000
            lines += [
                "",
                f"Send <b>exactly {amount_sol:.6f} SOL</b> to:",
                f"<code>{s.OPERATOR_TREASURY_SOL}</code>",
                "",
                f"Invoice: <code>{invoice.invoice_memo}</code>",
                "Auto-detected within 20 seconds of confirmation.",
            ]
        except Exception:
            lines.append("⚠️ Treasury not configured yet — check back soon.")

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎁 Share for credit", callback_data="menu:ref")],
        [InlineKeyboardButton(text="💰 Back to wallet", callback_data="menu:wallet")],
    ])
    await msg.answer("\n".join(lines), parse_mode="HTML", reply_markup=kb)


# ─── /risk — with SMART option ──────────────────────────────────────────────

@router.message(Command("risk"))
async def cmd_risk(msg: Message) -> None:
    await _send_risk_view(msg, tg_id=msg.from_user.id)


@router.callback_query(F.data == "menu:risk")
async def cb_risk(cb: CallbackQuery) -> None:
    await _send_risk_view(cb.message, tg_id=cb.from_user.id)
    await cb.answer()


async def _send_risk_view(msg: Message, tg_id: int) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        rec = await compute_smart(user_id=u.id)

    p = PRESETS
    active = u.risk_preset + (" 🧠 SMART" if u.smart_mode else "")
    lines = [
        "⚙️ <b>Risk preset · pick your style</b>",
        "",
        f"Current: <b>{active}</b>",
        "",
        f"🛡 <b>SAFE</b> — {p['SAFE'].sol_size_native} SOL / call · max {p['SAFE'].max_open_autobuys} open · SL −{int(p['SAFE'].hard_sl_pct*100)}%",
        f"⚖ <b>STANDARD</b> — {p['STANDARD'].sol_size_native} SOL / call · max {p['STANDARD'].max_open_autobuys} open · SL −{int(p['STANDARD'].hard_sl_pct*100)}%",
        f"⚡ <b>DEGEN</b> — {p['DEGEN'].sol_size_native} SOL / call · max {p['DEGEN'].max_open_autobuys} open · SL −{int(p['DEGEN'].hard_sl_pct*100)}%",
        "",
        f"🧠 <b>SMART</b> — data-driven, adjusts sizing based on YOUR results",
        f"   → Would run: <b>{rec.preset}</b> · {rec.reason}",
        f"   → Stats: WR@2x <b>{rec.wr_2x*100:.0f}%</b> · WR@5x <b>{rec.wr_5x*100:.0f}%</b> · avg peak <b>{rec.avg_peak_mult:.2f}x</b>",
        f"   → Based on {rec.n_positions} trades, {rec.n_signals} signals",
    ]
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🛡 SAFE", callback_data="risk:SAFE"),
            InlineKeyboardButton(text="⚖ STANDARD", callback_data="risk:STANDARD"),
            InlineKeyboardButton(text="⚡ DEGEN", callback_data="risk:DEGEN"),
        ],
        [InlineKeyboardButton(text="🧠 SMART (recommended)", callback_data="risk:SMART")],
        [InlineKeyboardButton(text="← back", callback_data="menu:home")],
    ])
    await msg.answer("\n".join(lines), parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data.startswith("risk:"))
async def cb_set_risk(cb: CallbackQuery) -> None:
    choice = cb.data.split(":", 1)[1]
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == cb.from_user.id))
        ).scalar_one()
        if choice == "SMART":
            u.smart_mode = True
            rec = await compute_smart(user_id=u.id)
            u.risk_preset = rec.preset
            txt = (
                f"🧠 <b>SMART mode ON</b>\n\n"
                f"Active preset: <b>{rec.preset}</b>\n{rec.reason}\n\n"
                f"Bot will re-check after every 10 fills and shift preset as your stats change."
            )
        elif choice in PRESETS:
            u.smart_mode = False
            u.risk_preset = choice
            txt = f"✅ Risk set to <b>{choice}</b> (manual mode — SMART off)"
        else:
            await cb.answer("Unknown preset", show_alert=True)
            return
    await cb.message.answer(txt, parse_mode="HTML")
    await cb.answer()


# ─── /pnl (unchanged) ───────────────────────────────────────────────────────

@router.message(Command("pnl"))
async def cmd_pnl(msg: Message) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        realized = (
            await s.execute(
                select(func.coalesce(func.sum(Fill.native_delta), 0.0))
                .join(Order, Order.id == Fill.order_id)
                .where(Order.user_id == u.id)
            )
        ).scalar_one()
        trades = (
            await s.execute(
                select(func.count(Order.id)).where(
                    and_(Order.user_id == u.id, Order.side == "buy", Order.status == "sent")
                )
            )
        ).scalar_one()
        positions = (
            await s.execute(select(Position).where(Position.user_id == u.id))
        ).scalars().all()
        unreal = 0.0
        best_mult = 0.0
        wins = 0
        for p in positions:
            if p.avg_entry_native > 0 and p.hwm_price_native > 0:
                mult = p.hwm_price_native / p.avg_entry_native
                best_mult = max(best_mult, mult)
                if mult >= 2.0:
                    wins += 1
            unreal += (p.hwm_price_native - p.avg_entry_native) * p.tokens_open
        wr = (wins / max(trades, 1)) if trades else 0.0

    png = render_pnl_card(
        PnLSummary(
            handle=f"@{msg.from_user.username or msg.from_user.id}",
            period="all-time",
            realized_native=realized,
            unrealized_native=unreal,
            win_rate=wr,
            trades=trades,
            best_mult=best_mult,
        )
    )
    await msg.answer_photo(BufferedInputFile(png, filename="pnl.png"))


# ─── /referral — vanity codes ───────────────────────────────────────────────

_VANITY_RE = re.compile(r"^[a-zA-Z0-9_]{3,20}$")


@router.message(Command("referral"))
async def cmd_referral(msg: Message) -> None:
    await _send_ref_view(msg, tg_id=msg.from_user.id)


@router.callback_query(F.data == "menu:ref")
async def cb_ref(cb: CallbackQuery) -> None:
    await _send_ref_view(cb.message, tg_id=cb.from_user.id)
    await cb.answer()


async def _send_ref_view(msg: Message, tg_id: int) -> None:
    s = get_settings()
    async with get_session() as ss:
        u = (await ss.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        n_refs = (
            await ss.execute(
                select(func.count(Referral.id)).where(Referral.referrer_id == u.id)
            )
        ).scalar_one()
        days_earned = (
            await ss.execute(
                select(func.coalesce(func.sum(Referral.credit_days_earned), 0))
                .where(Referral.referrer_id == u.id)
            )
        ).scalar_one() or 0

    link = f"https://t.me/{s.BOT_USERNAME}?start=ref_{u.ref_code}"
    lines = [
        "🎁 <b>Referral program</b>",
        "",
        f"Your code: <code>{u.ref_code}</code>",
        f"Your link:\n<code>{link}</code>",
        "",
        f"📊 Referrals: <b>{n_refs}</b>  ·  Credit earned: <b>{days_earned}</b> days",
        "",
        f"💡 <b>How it works:</b>",
        f"You earn <b>{s.REFERRAL_PCT:.0f}%</b> credit on the first <b>{s.REFERRAL_FIRST_N}</b>",
        f"sub payments of each user who joins with your link.",
        f"That's up to <b>{int(s.SUB_DURATION_DAYS * s.REFERRAL_PCT / 100 * s.REFERRAL_FIRST_N)} free days</b> per active referral.",
        "",
        "✨ Want a custom code? Use <code>/setrefcode &lt;your_name&gt;</code>",
    ]
    await msg.answer("\n".join(lines), parse_mode="HTML")


@router.message(Command("setrefcode"))
async def cmd_setrefcode(msg: Message) -> None:
    parts = (msg.text or "").split()
    if len(parts) != 2:
        await msg.answer(
            "Usage: <code>/setrefcode &lt;name&gt;</code>\n"
            "3–20 chars, letters/digits/underscore only.",
            parse_mode="HTML",
        )
        return
    new_code = parts[1].lower()
    if not _VANITY_RE.match(new_code):
        await msg.answer("Invalid format. Use 3–20 chars: a-z, 0-9, underscore.")
        return
    async with get_session() as s:
        # check uniqueness
        clash = (
            await s.execute(select(User).where(User.ref_code == new_code))
        ).scalar_one_or_none()
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        if clash and clash.id != u.id:
            await msg.answer("❌ That code is taken. Try another.")
            return
        u.ref_code = new_code
    link = f"https://t.me/{get_settings().BOT_USERNAME}?start=ref_{new_code}"
    await msg.answer(
        f"✅ Your new referral link:\n<code>{link}</code>\n\nShare it and earn credit!",
        parse_mode="HTML",
    )


# ─── /setpin + /export (PIN with lockout) ───────────────────────────────────

class ExportFSM(StatesGroup):
    awaiting_pin_to_set = State()
    awaiting_pin_to_confirm = State()
    awaiting_pin_to_export = State()


@router.message(Command("setpin"))
async def cmd_setpin(msg: Message, state: FSMContext) -> None:
    await state.set_state(ExportFSM.awaiting_pin_to_set)
    await msg.answer(
        "🔐 Send a 4–8 digit PIN.\n"
        "Required for exporting private keys and withdrawing.\n"
        "<i>Your message will be auto-deleted.</i>",
        parse_mode="HTML",
    )


@router.message(ExportFSM.awaiting_pin_to_set)
async def cmd_setpin_receive(msg: Message, state: FSMContext) -> None:
    pin = (msg.text or "").strip()
    try:
        await msg.delete()
    except Exception:
        pass
    err = check_pin_rules(pin)
    if err:
        await state.clear()
        await msg.answer(err)
        return
    await state.update_data(pin=pin)
    await state.set_state(ExportFSM.awaiting_pin_to_confirm)
    await msg.answer("Confirm PIN — send it again.")


@router.message(ExportFSM.awaiting_pin_to_confirm)
async def cmd_setpin_confirm(msg: Message, state: FSMContext) -> None:
    pin2 = (msg.text or "").strip()
    try:
        await msg.delete()
    except Exception:
        pass
    data = await state.get_data()
    await state.clear()
    if pin2 != data.get("pin"):
        await msg.answer("PINs didn't match. Run /setpin again.")
        return
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        u.pin_hash = hash_pin(pin2)
        u.pin_fail_count = 0
        u.pin_locked_until = None
    await msg.answer("✅ PIN set. Use /export to see private keys.")


@router.callback_query(F.data == "wallet:export")
async def cb_wallet_export(cb: CallbackQuery, state: FSMContext) -> None:
    await cmd_export(cb.message, state)
    await cb.answer()


@router.message(Command("export"))
async def cmd_export(msg: Message, state: FSMContext) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
    if u is None:
        await msg.answer("Run /start first.")
        return
    if not u.pin_hash:
        await msg.answer("Set a PIN first with /setpin.")
        return
    if u.pin_locked_until and u.pin_locked_until > datetime.now(timezone.utc):
        mins = int((u.pin_locked_until - datetime.now(timezone.utc)).total_seconds() // 60) + 1
        await msg.answer(f"🔒 Too many failed attempts. Try again in {mins} min.")
        return
    await state.set_state(ExportFSM.awaiting_pin_to_export)
    await msg.answer(
        "🔓 Send your PIN.\n"
        "Keys appear once and self-destruct after 60 seconds.\n"
        "<b>Never share them with anyone.</b>",
        parse_mode="HTML",
    )


@router.message(ExportFSM.awaiting_pin_to_export)
async def cmd_export_receive(msg: Message, state: FSMContext) -> None:
    pin = (msg.text or "").strip()
    try:
        await msg.delete()
    except Exception:
        pass
    await state.clear()
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        if not u.pin_hash or not verify_pin(pin, u.pin_hash):
            u.pin_fail_count = (u.pin_fail_count or 0) + 1
            if u.pin_fail_count >= 5:
                u.pin_locked_until = datetime.now(timezone.utc) + timedelta(minutes=15)
                u.pin_fail_count = 0
                await msg.answer("🔒 5 wrong PINs. Locked for 15 minutes.")
                return
            await msg.answer(f"❌ Wrong PIN ({u.pin_fail_count}/5)")
            return
        u.pin_fail_count = 0
        wallets = (
            await s.execute(select(Wallet).where(Wallet.user_id == u.id))
        ).scalars().all()

    exported = []
    for w in wallets:
        try:
            raw = decrypt_key(w.encrypted_key, w.nonce, w.salt, aad=w.address.encode())
        except Exception as e:
            log().warning("export.decrypt_fail", err=str(e))
            continue
        if w.chain == "solana":
            key_str = solana_secret_to_b58(raw)
            fmt = "base58 · Phantom"
        else:
            key_str = "0x" + raw.hex()
            fmt = "hex · MetaMask"
        exported.append((w.chain.upper(), w.address, key_str, fmt))
        raw = b"\x00" * len(raw)  # noqa: F841

    if not exported:
        await msg.answer("No wallets to export.")
        return

    body = ["🔓 <b>PRIVATE KEYS · auto-delete in 60s</b>", ""]
    for chain, addr, key, fmt in exported:
        body += [
            f"<b>{chain}</b>  ({fmt})",
            f"addr: <code>{addr}</code>",
            f"key:  <tg-spoiler><code>{key}</code></tg-spoiler>",
            "",
        ]
    body.append("⚠️ Import into Phantom / MetaMask. Never paste this key on any website.")
    sent = await msg.answer("\n".join(body), parse_mode="HTML")

    async def _delete_later():
        await asyncio.sleep(60)
        try:
            await sent.delete()
        except Exception:
            pass

    asyncio.create_task(_delete_later())


# ─── /settings — withdraw whitelist ────────────────────────────────────────

class WithdrawFSM(StatesGroup):
    awaiting_sol_addr = State()
    awaiting_evm_addr = State()


@router.message(Command("set_withdraw_sol"))
async def set_withdraw_sol(msg: Message, state: FSMContext) -> None:
    await state.set_state(WithdrawFSM.awaiting_sol_addr)
    await msg.answer("Send your Solana withdraw whitelist address.")


@router.message(WithdrawFSM.awaiting_sol_addr)
async def set_withdraw_sol_recv(msg: Message, state: FSMContext) -> None:
    await state.clear()
    addr = (msg.text or "").strip()
    from app.signals.parser import _is_valid_solana
    if not _is_valid_solana(addr):
        await msg.answer("That's not a valid Solana address.")
        return
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        u.withdraw_whitelist_sol = addr
    await msg.answer(f"✅ Solana whitelist: <code>{addr}</code>", parse_mode="HTML")


@router.message(Command("set_withdraw_evm"))
async def set_withdraw_evm(msg: Message, state: FSMContext) -> None:
    await state.set_state(WithdrawFSM.awaiting_evm_addr)
    await msg.answer("Send your EVM withdraw whitelist address (0x…).")


@router.message(WithdrawFSM.awaiting_evm_addr)
async def set_withdraw_evm_recv(msg: Message, state: FSMContext) -> None:
    await state.clear()
    addr = (msg.text or "").strip()
    if not (addr.startswith("0x") and len(addr) == 42):
        await msg.answer("That's not a valid EVM address.")
        return
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        u.withdraw_whitelist_evm = addr
    await msg.answer(f"✅ EVM whitelist: <code>{addr}</code>", parse_mode="HTML")
