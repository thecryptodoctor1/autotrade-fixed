"""Premium flows: /setusername, /trial, /lifetime."""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import select

from app.config import get_settings
from app.db import Subscription, User, get_session

router = Router()

_USERNAME_RE = re.compile(r"^[a-zA-Z0-9_]{3,20}$")


# ─── /setusername ──────────────────────────────────────────────────────────

@router.message(Command("setusername"))
async def cmd_setusername(msg: Message) -> None:
    parts = (msg.text or "").split()
    if len(parts) != 2:
        await msg.answer(
            "Usage: <code>/setusername &lt;name&gt;</code>\n"
            "3-20 chars · letters/digits/underscore only.\n"
            "This shows on the public leaderboard at "
            "<code>dashboard.memesolana.com</code>.",
            parse_mode="HTML",
        )
        return
    new_name = parts[1].strip().lower()
    if not _USERNAME_RE.match(new_name):
        await msg.answer("❌ Invalid format. 3-20 chars, letters/digits/underscore only.")
        return
    async with get_session() as s:
        clash = (
            await s.execute(select(User).where(User.username == new_name))
        ).scalar_one_or_none()
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one()
        if clash and clash.id != u.id:
            await msg.answer("❌ That username is taken. Try another.")
            return
        u.username = new_name
    await msg.answer(
        f"✅ Username set to <b>@{new_name}</b>\n\n"
        f"You'll appear on the public leaderboard as your positions rack up peaks.\n"
        f"Your public profile: <code>dashboard.memesolana.com/u/{new_name}</code>",
        parse_mode="HTML",
    )


# ─── /trial ────────────────────────────────────────────────────────────────

@router.message(Command("trial"))
async def cmd_trial(msg: Message) -> None:
    now = datetime.now(timezone.utc)
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        if u.trial_used:
            await msg.answer(
                "⚠️ You've already used your 3-day trial.\n\n"
                "Ready to keep the AI running? /subscribe or /lifetime"
            )
            return
        # Check if user has any active sub
        existing = (
            await s.execute(
                select(Subscription).where(Subscription.user_id == u.id)
                .order_by(Subscription.id.desc()).limit(1)
            )
        ).scalar_one_or_none()
        if existing and existing.status in ("active", "lifetime"):
            await msg.answer("You're already active. /subscribe for status.")
            return
        # Grant trial
        sub = Subscription(
            user_id=u.id,
            status="active",
            plan="trial",
            started_at=now,
            expires_at=now + timedelta(days=3),
            invoice_memo="trial_3d",
        )
        s.add(sub)
        u.trial_used = True

    await msg.answer(
        "🎉 <b>3-day trial activated!</b>\n\n"
        f"AI auto-buy is <b>LIVE</b> until <b>{(now + timedelta(days=3)):%Y-%m-%d %H:%M} UTC</b>.\n\n"
        "1️⃣ Deposit some SOL: /deposit\n"
        "2️⃣ Set your risk preset: /risk\n"
        "3️⃣ Bot takes over. Watch /positions.\n\n"
        "💡 <i>Trial converts to $49/mo unless you upgrade to /lifetime ($499 one-time).</i>",
        parse_mode="HTML",
    )


# ─── /lifetime ─────────────────────────────────────────────────────────────

@router.message(Command("lifetime"))
async def cmd_lifetime(msg: Message) -> None:
    s = get_settings()
    if not s.OPERATOR_TREASURY_SOL:
        await msg.answer("Lifetime deals not configured yet — check back soon.")
        return

    import random

    async with get_session() as ss:
        u = (await ss.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        # Unique invoice amount
        sol_usd = None
        try:
            from app.chain.prices import sol_price_usd
            sol_usd = await sol_price_usd()
        except Exception:
            sol_usd = None
        if not sol_usd:
            await msg.answer("SOL price is not loading. Try /lifetime again in a minute.")
            return
        old = (
            await ss.execute(
                select(Subscription).where(
                    Subscription.user_id == u.id,
                    Subscription.status == "pending",
                )
            )
        ).scalars().all()
        for row in old:
            row.status = "expired"
        base_lamports = int((499.0 / sol_usd) * 1_000_000_000)
        amount = base_lamports + random.randint(1000, 99999)
        sub = Subscription(
            user_id=u.id,
            status="pending",
            plan="lifetime",
            invoice_amount_lamports=amount,
            invoice_memo=f"lifetime_{u.id}_{amount % 100000:05d}",
        )
        ss.add(sub)
        await ss.flush()

    amount_sol = amount / 1_000_000_000
    await msg.answer(
        "💎 <b>LIFETIME DEAL · $499 one-time</b>\n\n"
        "✨ You never pay again. Forever access. All future upgrades included.\n\n"
        f"Send <b>exactly {amount_sol:.6f} SOL</b> to:\n"
        f"<code>{s.OPERATOR_TREASURY_SOL}</code>\n\n"
        "Auto-activates within 20 seconds of confirmation.\n\n"
        "💡 <i>Break-even after ~10 months vs monthly. Every month after = pure profit.</i>",
        parse_mode="HTML",
    )
