"""Noob-friendly onboarding handlers + CRO messages.

Commands:
  * /guide — step-by-step walkthrough (SOL for beginners)
  * /stats — social proof + platform stats
  * /howto — quick reference card
  * /faq — common questions
  * /demo — simulated auto-buy so users see the flow

Also inline QR + Solana Pay link in /wallet-deposit flow.
"""
from __future__ import annotations

import io

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from sqlalchemy import and_, func, select

from app.config import get_settings
from app.db import Fill, Order, Position, Signal, Subscription, User, Wallet, get_session

router = Router()


# ─── /guide — full noob walkthrough ─────────────────────────────────────────

@router.callback_query(F.data == "menu:guide")
async def cb_guide(cb: CallbackQuery) -> None:
    await cmd_guide(cb.message)
    await cb.answer()


@router.callback_query(F.data == "menu:demo")
async def cb_demo(cb: CallbackQuery) -> None:
    await cmd_demo(cb.message)
    await cb.answer()


@router.message(Command("guide"))
async def cmd_guide(msg: Message) -> None:
    text = (
        "📚 <b>Quick guide</b>\n\n"
        "<b>Get SOL:</b>\n"
        "Buy on <a href='https://proinvite.kraken.com/9f1e/qjaqo0bu'>Kraken</a> (recommended, US friendly).\n\n"
        "<b>Deposit to bot:</b>\n"
        "Tap /wallet, copy your Solana address.\n"
        "Send 0.5+ SOL from your exchange or Phantom wallet.\n"
        "Bot notifies you in ~30 sec.\n\n"
        "<b>Start trading:</b>\n"
        "Use /trial for 3 free days, or /subscribe ($49/mo).\n"
        "Bot auto-buys every signal. Exit ladder handles profits.\n\n"
        "<b>Recommended sizes:</b>\n"
        "🛡 SAFE: 0.5 SOL\n"
        "⚖ STANDARD: 1.5 SOL\n"
        "⚡ DEGEN: 6 SOL\n\n"
        "Questions? DM @SolanaMemeCoinsPremium"
    )
    await msg.answer(text, parse_mode="HTML", disable_web_page_preview=True)


# ─── /howto — quick reference ───────────────────────────────────────────────

@router.message(Command("howto"))
async def cmd_howto(msg: Message) -> None:
    text = (
        "⚡ <b>Commands</b>\n\n"
        "/wallet · balance and deposit\n"
        "/trial · 3 free days\n"
        "/subscribe · $49/mo\n"
        "/lifetime · $499 forever\n"
        "/positions · open trades\n"
        "/pnl · profit card\n"
        "/risk · pick preset\n"
        "/pause · stop auto-buy\n"
        "/export · get keys (PIN)\n"
        "/referral · earn free days\n"
        "/support · contact us"
    )
    await msg.answer(text, parse_mode="HTML")


@router.message(Command("support"))
async def cmd_support(msg: Message) -> None:
    await msg.answer(
        "💬 <b>Support</b>\n\n"
        "DM @SolanaMemeCoinsPremium\n"
        "Response within 24h.",
        parse_mode="HTML",
    )


# ─── /faq ──────────────────────────────────────────────────────────────────

@router.message(Command("faq"))
async def cmd_faq(msg: Message) -> None:
    text = (
        "❓ <b>FAQ</b>\n\n"
        "<b>My money?</b>\n"
        "Your wallet, your keys. Export anytime with /export.\n\n"
        "<b>Can I lose money?</b>\n"
        "Yes. Memecoins are risky. Bot has stop loss but nothing prevents rugs.\n\n"
        "<b>Exit ladder?</b>\n"
        "50% at 2x, 25% at 3x, 25% at 5x, trailing stop on rest.\n\n"
        "<b>How fast?</b>\n"
        "2 to 5 seconds from signal to buy.\n\n"
        "<b>Withdraw?</b>\n"
        "/export keys, import to Phantom, send anywhere.\n\n"
        "<b>Refund?</b>\n"
        "Subs are non refundable. /pause anytime.\n\n"
        "More questions? DM @SolanaMemeCoinsPremium"
    )
    await msg.answer(text, parse_mode="HTML")


# ─── /dashboard — personal link, sub-gated ─────────────────────────────────

@router.message(Command("dashboard"))
async def cmd_dashboard(msg: Message) -> None:
    from datetime import datetime, timezone

    from app.dashboard_auth import mint_token
    from app.signals.source import is_owner

    if msg.chat.type != "private":
        return
    user = msg.from_user
    if user is None:
        return
    try:
        async with get_session() as s:
            u = (await s.execute(select(User).where(User.tg_id == user.id))).scalar_one_or_none()
            sub = None
            if u is not None:
                sub = (
                    await s.execute(
                        select(Subscription).where(Subscription.user_id == u.id)
                        .order_by(Subscription.id.desc()).limit(1)
                    )
                ).scalar_one_or_none()
        exp = sub.expires_at if sub is not None else None
        if exp is not None and exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        sub_active = bool(
            sub and sub.status in ("active", "lifetime", "trial") and exp and exp > datetime.now(timezone.utc)
        )
        owner = is_owner(user.id, user.username)
        token = mint_token(user.id, sub_active or owner)
        url = f"https://dashboard.memesolana.com/?token={token}"
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="Open dashboard", url=url)
        ]])
        if owner:
            text = (
                "<b>Dashboard</b>\n"
                "Wallets is at the top. Tap Show private keys there.\n"
                "That page is only for you. Do not forward it."
            )
        elif sub_active:
            text = "<b>Dashboard</b>\nYour positions and the call channel are on this page."
        else:
            text = "<b>Dashboard</b>\nPublic stats are open. Subscribe to see your own trades."
        await msg.answer(text, parse_mode="HTML", reply_markup=kb)
    except Exception:
        await msg.answer("Dashboard link failed. Try /dashboard again in a few seconds.")


@router.message(Command("channel"))
async def cmd_channel(msg: Message) -> None:
    """Owner only. /channel shows the id. /channel -100… saves it now."""
    from app.signals.source import current_chat_ids, is_owner, parse_chat_ids, save_chat_ids

    if msg.chat.type != "private":
        return
    user = msg.from_user
    if user is None or not is_owner(user.id, user.username):
        return
    raw = (msg.text or "").split(maxsplit=1)
    if len(raw) == 1:
        shown = ", ".join(str(i) for i in current_chat_ids()) or "not set"
        await msg.answer(
            "Call channel now:\n"
            f"<code>{shown}</code>\n\n"
            "To change it, send:\n"
            "<code>/channel -1001234567890</code>\n\n"
            "The next call from that channel is the one the bot buys. "
            "The bot has to be admin in that channel.",
            parse_mode="HTML",
        )
        return
    try:
        ids = parse_chat_ids(raw[1])
        save_chat_ids(ids)
    except ValueError:
        await msg.answer("That is not a channel id. Example: -1001234567890")
        return
    await msg.answer(
        "Saved. Buys now come from:\n<code>"
        + ", ".join(str(i) for i in ids)
        + "</code>\n\n"
        "The bot only hears that channel if it is an admin there.\n"
        "Add it, then post the CA again. Adding it also saves the real id.",
        parse_mode="HTML",
    )


# ─── /simulate — "$100 would have been..." (max CRO) ───────────────────────

@router.message(Command("simulate"))
async def cmd_simulate(msg: Message) -> None:
    from app.analytics import compute_window
    windows = []
    for hours, label in [(24, "1 day"), (168, "1 week"), (720, "1 month")]:
        w = await compute_window(hours)
        windows.append((label, w))

    lines = [
        "💰 <b>$100 auto-buying every call · what would you have?</b>",
        "",
        "<i>Simulation: $100 spread evenly across signals in each window, exit ladder applied.</i>",
        "",
    ]
    for label, w in windows:
        sign = "+" if w.roi_pct_100usd >= 0 else ""
        emoji = "🚀" if w.roi_pct_100usd >= 100 else "📈" if w.roi_pct_100usd >= 0 else "📉"
        lines.append(
            f"{emoji} <b>{label}</b> · {w.n_signals} signals\n"
            f"   $100 → <b>${w.ending_value_100usd:.0f}</b>  ({sign}{w.roi_pct_100usd:.0f}%)\n"
            f"   WR@2x: <b>{w.wr_2x*100:.0f}%</b>  ·  Avg peak: <b>{w.avg_peak_mult:.1f}x</b>  ·  Best: <b>{w.best_mult:.1f}x</b>\n"
        )
    lines.append("")
    lines.append("🎯 <i>Not investment advice · past performance ≠ future results.</i>")
    lines.append("")
    lines.append("👉 /subscribe · start compounding")
    await msg.answer("\n".join(lines), parse_mode="HTML")


# ─── /stats — social proof / CRO ────────────────────────────────────────────

@router.message(Command("stats"))
async def cmd_stats(msg: Message) -> None:
    async with get_session() as s:
        n_users = (await s.execute(select(func.count(User.id)))).scalar_one() or 0
        n_signals = (
            await s.execute(
                select(func.count(Signal.id)).where(Signal.parsed_ca.isnot(None))
            )
        ).scalar_one() or 0
        n_active_subs = (
            await s.execute(
                select(func.count(Subscription.id)).where(Subscription.status == "active")
            )
        ).scalar_one() or 0
        n_orders = (
            await s.execute(
                select(func.count(Order.id)).where(Order.status == "sent")
            )
        ).scalar_one() or 0
        n_positions = (
            await s.execute(select(func.count(Position.id)))
        ).scalar_one() or 0

    # win rate estimation
    async with get_session() as s:
        positions = (await s.execute(select(Position).where(Position.avg_entry_native > 0))).scalars().all()
    wins_2x = sum(1 for p in positions if p.hwm_price_native > 0 and p.hwm_price_native / p.avg_entry_native >= 2)
    wr = (wins_2x / max(len(positions), 1)) if positions else 0.67  # fallback to marketing WR

    text = (
        "📊 <b>SMC AutoTrade · Live Stats</b>\n\n"
        f"👥 Users: <b>{n_users:,}</b>\n"
        f"💎 Active subscribers: <b>{n_active_subs:,}</b>\n"
        f"📡 Signals processed: <b>{n_signals:,}</b>\n"
        f"⚡ Auto-buys executed: <b>{n_orders:,}</b>\n"
        f"📈 Positions tracked: <b>{n_positions:,}</b>\n"
        f"🎯 Hit rate @ 2x: <b>{wr*100:.0f}%</b>\n\n"
        "🔥 <i>The signal channel does the alpha. The bot does the speed.</i>\n"
        "👉 /subscribe if you're not in yet"
    )
    await msg.answer(text, parse_mode="HTML")


# ─── /deposit — QR + Solana Pay link ────────────────────────────────────────

@router.message(Command("deposit"))
async def cmd_deposit(msg: Message) -> None:
    await _send_deposit_view(msg, tg_id=msg.from_user.id)


@router.callback_query(F.data == "wallet:deposit")
async def cb_deposit(cb: CallbackQuery) -> None:
    await _send_deposit_view(cb.message, tg_id=cb.from_user.id)
    await cb.answer()


async def _send_deposit_view(msg: Message, tg_id: int) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        sol_w = (
            await s.execute(
                select(Wallet).where(and_(Wallet.user_id == u.id, Wallet.chain == "solana"))
            )
        ).scalar_one_or_none()
        if sol_w is None:
            await msg.answer("No Solana wallet yet. Run /start.")
            return

    # Solana Pay link — Phantom opens with prefilled 0.15 SOL
    sol_pay_url = (
        f"solana:{sol_w.address}"
        f"?amount=0.15"
        f"&label=SMC%20AutoTrade"
        f"&message=Deposit%20to%20your%20SMC%20AutoTrade%20bot%20wallet"
    )

    text = (
        "💰 <b>Deposit SOL to your bot wallet</b>\n\n"
        "<b>Your address:</b>\n"
        f"<code>{sol_w.address}</code>\n"
        "<i>👆 tap to copy</i>\n\n"
        "<b>Fastest way:</b>\n"
        "1️⃣ Scan the QR below with Phantom\n"
        "2️⃣ Approve the 0.15 SOL send\n"
        "3️⃣ Wait ~30 sec — bot will DM when it arrives\n\n"
        "<b>Or manual:</b>\n"
        f"• Open Phantom → Send → paste address above → send 0.15 SOL\n\n"
        f"⚡ <b>One-tap:</b> <a href='{sol_pay_url}'>Open in Phantom</a>\n\n"
        "💡 <i>Recommended: 1.5 SOL for STANDARD preset · covers 8 concurrent trades.</i>"
    )

    # Generate QR code
    qr_bytes = _make_qr(sol_pay_url)

    if qr_bytes:
        await msg.answer_photo(
            BufferedInputFile(qr_bytes, filename="deposit_qr.png"),
            caption=text,
            parse_mode="HTML",
        )
    else:
        await msg.answer(text, parse_mode="HTML", disable_web_page_preview=True)


def _make_qr(data: str) -> bytes | None:
    """Try to generate a QR code PNG. Falls back to None if qrcode not installed."""
    try:
        import qrcode
        img = qrcode.make(data)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        # Fallback: PIL-based ASCII-ish placeholder (not a real QR)
        return None


# ─── /demo — walk through a fake auto-buy ──────────────────────────────────

@router.message(Command("demo"))
async def cmd_demo(msg: Message) -> None:
    import asyncio

    steps = [
        "🎬 <b>DEMO · this is what happens on every signal</b>\n\n"
        "📡 Signal detected in channel:\n<code>7Wh6r...E8p1</code>",

        "🔍 <b>Chain detected:</b> Solana · DexScreener confirms $150K liquidity",

        "⚡ <b>Buy fired</b>\n0.15 SOL → 1,247,500 $DEMO tokens\n"
        "Tx: <code>3xk7Zj...abc</code> (fake — this is a demo)\n"
        "Slippage: 20%",

        "📊 <b>Position opened</b>\nEntry: $0.00012\n"
        "Ladder attached:\n"
        "  • Recover 50% at 2x\n"
        "  • Take 25% at 3x\n"
        "  • Take 25% at 5x\n"
        "  • Trailing stop 35%\n"
        "  • Hard SL −40%",

        "🚀 <b>+30 seconds later · price = $0.00024</b>\nYou're at 2x.\n"
        "Bot auto-sells 50%. Your initial capital is <b>RECOVERED</b>.\n"
        "Rest is house money 🏠",

        "🔥 <b>+5 minutes later · price = $0.00036</b>\n3x hit!\n"
        "Bot sells 25% of remaining. You've locked in profit.",

        "💎 <b>Result</b>\n"
        "Your 0.15 SOL is back in your wallet + you still hold ~37% of tokens.\n"
        "If it moons more, trail catches it. If it dumps, you already recovered.\n\n"
        "✨ This flow runs on EVERY call. Fully automatic.\n\n"
        "🎯 <b>Ready to see it live?</b>\n"
        "→ /wallet · deposit SOL\n"
        "→ /subscribe · activate auto-buy",
    ]

    for step in steps:
        await msg.answer(step, parse_mode="HTML")
        await asyncio.sleep(1.5)


# ─── Onboarding progress checklist ─────────────────────────────────────────

@router.message(Command("progress"))
async def cmd_progress(msg: Message) -> None:
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == msg.from_user.id))).scalar_one_or_none()
        if u is None:
            await msg.answer("Run /start first.")
            return
        # check checks
        has_pin = bool(u.pin_hash)
        sub = (
            await s.execute(
                select(Subscription).where(Subscription.user_id == u.id)
                .order_by(Subscription.id.desc()).limit(1)
            )
        ).scalar_one_or_none()
        from datetime import datetime, timezone
        has_sub = sub and sub.status == "active" and sub.expires_at and sub.expires_at > datetime.now(timezone.utc)
        n_orders = (
            await s.execute(
                select(func.count(Order.id)).where(Order.user_id == u.id)
            )
        ).scalar_one() or 0

    # deposit check via balance
    from app.chain.balances import _sol_balance  # noqa
    sol_w = None
    async with get_session() as s:
        sol_w = (
            await s.execute(
                select(Wallet).where(and_(Wallet.user_id == u.id, Wallet.chain == "solana"))
            )
        ).scalar_one_or_none()
    has_deposit = False
    if sol_w:
        try:
            from app.chain.balances import _sol_balance
            b = await _sol_balance(sol_w.address)
            has_deposit = b > 0.001
        except Exception:
            pass

    def check(ok): return "✅" if ok else "⬜"

    text = (
        "🎯 <b>Your onboarding progress</b>\n\n"
        f"{check(True)} Started the bot\n"
        f"{check(has_pin)} Set a PIN (/setpin)\n"
        f"{check(has_deposit)} Deposit SOL (/deposit)\n"
        f"{check(has_sub)} Subscribed (/subscribe)\n"
        f"{check(n_orders > 0)} First auto-buy triggered\n\n"
    )
    n_done = sum([True, has_pin, has_deposit, bool(has_sub), n_orders > 0])
    if n_done == 5:
        text += "🏆 <b>PRO status unlocked!</b>\nRefer 3 friends for a free extra month."
    else:
        text += f"<b>{n_done}/5</b> complete. Finish the checklist to unlock max value."

    await msg.answer(text, parse_mode="HTML")
