"""Core Telegram flows: /start, /wallet, /risk, /pause, /positions, /help.

Buy/sell/subscribe are stubbed to safe no-ops that return receipts — they read
from DB and don't touch chain in MVP. Wire executors after paper-trade replay
confirms the ladder math.
"""
from __future__ import annotations

from datetime import datetime, timezone

from aiogram import F, Router
from aiogram.filters import CommandStart, Command
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from app.config import get_settings
from app.db import Position, User, Wallet, get_session
from app.logging_conf import log
from app.risk.presets import PRESETS
from app.telegram.keyboards import main_menu, risk_menu
from app.wallet.crypto import encrypt_key
from app.wallet.generate import generate_evm, generate_solana
from app.wallet.pin import gen_ref_code

router = Router()


async def _ensure_user(tg_id: int, username: str | None) -> tuple[User, list[Wallet]]:
    """Load or create a user + their SOL and EVM wallets."""
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == tg_id))
        ).scalar_one_or_none()
        if u is None:
            u = User(
                tg_id=tg_id,
                tg_username=username,
                ref_code=gen_ref_code(),
                risk_preset=get_settings().DEFAULT_RISK_PRESET,
                smart_mode=True,
                auto_paused=False,
            )
            s.add(u)
            await s.flush()

            for chain, gen in (("solana", generate_solana), ("evm", generate_evm)):
                w = gen()
                ct = encrypt_key(w.private_key, aad=w.address.encode())
                s.add(
                    Wallet(
                        user_id=u.id,
                        chain=chain,
                        address=w.address,
                        encrypted_key=ct.ct,
                        salt=ct.salt,
                        nonce=ct.nonce,
                        key_rotation_id=ct.rotation_id,
                    )
                )
                # zero the key ASAP — Python won't reuse the bytes, but drop the
                # reference so GC can reap it.
                w.private_key = b""

        wallets = (
            await s.execute(select(Wallet).where(Wallet.user_id == u.id))
        ).scalars().all()
        return u, list(wallets)


def _fmt_wallet_card(u: User, wallets: list[Wallet]) -> str:
    lines = [
        "💎 <b>Your SMC AutoTrade wallets</b>",
        "",
        "<b>Never share the private key.</b> Only the addresses below are safe to share.",
    ]
    for w in wallets:
        chain = "Solana" if w.chain == "solana" else "EVM (ETH/Base/BSC/Arbitrum)"
        lines.append(f"\n<b>{chain}</b>\n<code>{w.address}</code>")
    lines.append("\nDeposit SOL / ETH / BNB / USDC and use the Buy button.")
    return "\n".join(lines)


async def _start_money(tg_id: int, wallets: list[Wallet]) -> str:
    """Free SOL plus what the open trades are worth. Never blocks /start."""
    import asyncio

    sol_bal = 0.0
    addr = next((w.address for w in wallets if w.chain == "solana"), None)
    try:
        if addr:
            from app.chain import solana_jupiter
            sol_bal = (await solana_jupiter.sol_lamports(addr)) / 1e9
    except Exception:
        sol_bal = 0.0
    worth = paid = known = 0.0
    n = 0
    sol_usd = 0.0
    try:
        from app.telegram.handlers.desk import _cards, _sol_usd
        sol_usd = await asyncio.wait_for(_sol_usd(), timeout=6)
        summary, _rows = await asyncio.wait_for(_cards(tg_id), timeout=20)
        if summary:
            worth = float(summary["worth"])
            paid = float(summary["paid"])
            known = float(summary.get("known_worth", worth))
            n = int(summary["n"])
    except Exception:
        pass
    usd_worth = f" (${worth * sol_usd:,.0f})" if sol_usd > 5 else ""
    usd_bal = f" · about ${sol_bal * sol_usd:,.0f}" if sol_usd > 5 else ""
    if n <= 0:
        trades = "No open trades."
    elif paid >= 0.001:
        pnl = known - paid
        mark = "🟢" if pnl >= 0 else "🔴"
        trades = (
            f"{n} open · worth <b>{worth:.4f} SOL</b>{usd_worth}\n"
            f"{mark} Open result <b>{pnl:+.4f} SOL</b>"
        )
    else:
        trades = f"{n} open · worth <b>{worth:.4f} SOL</b>{usd_worth}"
    return (
        f"💎 Wallet <b>{sol_bal:.4f} SOL</b>{usd_bal}\n"
        f"📊 {trades}\n\n"
    )


@router.message(CommandStart())
async def cmd_start(msg: Message) -> None:
    args = msg.text.split(maxsplit=1)
    ref = None
    if len(args) > 1 and args[1].startswith("ref_"):
        ref = args[1][4:]
    u, wallets = await _ensure_user(msg.from_user.id, msg.from_user.username)
    # If ref param, try to resolve referrer + link
    if ref:
        async with get_session() as ss:
            referrer = (
                await ss.execute(select(User).where(User.ref_code == ref))
            ).scalar_one_or_none()
            user_row = (
                await ss.execute(select(User).where(User.tg_id == u.tg_id))
            ).scalar_one()
            if referrer and user_row.referred_by_id is None and referrer.id != user_row.id:
                user_row.referred_by_id = referrer.id

    log().info("start", tg_id=u.tg_id, ref=ref)
    ref_note = ""
    if ref:
        ref_note = f"\n\n🎁 Referral joined. Both get bonus days on first sub."
    money = await _start_money(u.tg_id, wallets)
    await msg.answer(
        f"🤖 <b>SMC AutoTrade</b>\n\n"
        f"{money}"
        f"You can sell anytime.\n"
        f"New buys need Free Trial or Subscribe.\n\n"
        f"The bot sells for you. No need to watch:\n"
        f"• Down 30–50% → it sells everything\n"
        f"• At 2× → it sells half and gives your money back\n"
        f"• At 3× and 5× → it takes more profit\n\n"
        f"Send SOL with Wallet, then tap Free Trial.\n"
        f"Help: @SolanaMemeCoinsPremium{ref_note}",
        reply_markup=main_menu(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "menu:home")
async def cb_home(cb: CallbackQuery) -> None:
    await cb.message.edit_text("Main menu", reply_markup=main_menu())
    await cb.answer()




@router.message(Command("wallet"))
async def cmd_wallet(msg: Message) -> None:
    u, wallets = await _ensure_user(msg.from_user.id, msg.from_user.username)
    await msg.answer(_fmt_wallet_card(u, wallets), parse_mode="HTML")






@router.callback_query(F.data == "menu:pause")
async def cb_pause(cb: CallbackQuery) -> None:
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == cb.from_user.id))
        ).scalar_one()
        u.auto_paused = not u.auto_paused
        state = "PAUSED" if u.auto_paused else "ACTIVE"
    await cb.message.answer(f"Auto-buy is now <b>{state}</b>", parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data == "menu:positions-legacy")
async def cb_positions_legacy(cb: CallbackQuery) -> None:
    await cb.answer()


@router.callback_query(F.data == "menu:help")
async def cb_help(cb: CallbackQuery) -> None:
    await cb.message.answer(
        "Commands: /start /wallet /risk /pause /resume /positions /buy /sell /pnl /subscribe /referral"
    )
    await cb.answer()




