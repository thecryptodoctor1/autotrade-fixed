"""Plain buttons: trial, mode, and a position card you can close."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import asyncio

import httpx
from aiogram import F, Router
from aiogram.types import CallbackQuery
from sqlalchemy import func, select

from app.db import Fill, Order, Position, Subscription, User, Wallet, get_session
from app.telegram.keyboards import pnl_kb, position_kb
from app.worker.executor import execute_sell

router = Router()

_TRIAL = {"menu:trial", "trial", "menu:free", "free_trial"}
_MODE = {"menu:mode", "mode"}


def _aware(dt):
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


async def _user(tg_id: int) -> User | None:
    async with get_session() as s:
        return (
            await s.execute(select(User).where(User.tg_id == tg_id))
        ).scalar_one_or_none()


@router.callback_query(F.data.in_(_TRIAL))
async def cb_trial(cb: CallbackQuery) -> None:
    await cb.answer()
    now = datetime.now(timezone.utc)
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == cb.from_user.id))
        ).scalar_one_or_none()
        if u is None:
            await cb.message.answer("Tap /start first.")
            return
        rows = (
            await s.execute(
                select(Subscription).where(Subscription.user_id == u.id).order_by(Subscription.id.desc())
            )
        ).scalars().all()
        live = None
        for row in rows:
            exp = _aware(row.expires_at)
            if row.status in ("active", "lifetime", "trial") and exp and exp > now:
                live = row
                break
        if live is not None:
            left = _aware(live.expires_at) - now
            await cb.message.answer(
                f"You are already active. About {left.days}d {left.seconds // 3600}h left.\n"
                "Auto-buy is on. A new invoice does not turn it off."
            )
            return
        if u.trial_used:
            await cb.message.answer(
                "The 3-day trial is already used.\n"
                "Tap Subscribe to add 30 days. Auto-buy stays off until that payment lands."
            )
            return
        sub = Subscription(
            user_id=u.id,
            status="active",
            plan="trial",
            started_at=now,
            expires_at=now + timedelta(days=3),
            invoice_memo="trial_3d",
        )
        s.add(sub)
        u.trial_used = True
    until = (now + timedelta(days=3)).strftime("%Y-%m-%d %H:%M UTC")
    await cb.message.answer(
        f"3-day trial is on until {until}.\n"
        "Deposit SOL, then leave it. Each buy is capped to a small slice of the wallet."
    )


@router.callback_query(F.data == "menu:support")
async def cb_support(cb: CallbackQuery) -> None:
    await cb.answer()
    await cb.message.answer("Support: DM @SolanaMemeCoinsPremium")


@router.callback_query(F.data.in_(_MODE))
async def cb_mode(cb: CallbackQuery) -> None:
    await cb.answer()
    u = await _user(cb.from_user.id)
    if u is None:
        await cb.message.answer("Tap /start first.")
        return
    smart = "on" if u.smart_mode else "off"
    await cb.message.answer(
        f"<b>{u.risk_preset}</b> · SMART {smart}\n\n"
        "Small wallet: max 0.05 SOL per buy.\n"
        "Change it under Risk.",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "menu:smart")
async def cb_smart_toggle(cb: CallbackQuery) -> None:
    """SMART button: flip User.smart_mode and reply with the new state."""
    await cb.answer()
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == cb.from_user.id))
        ).scalar_one_or_none()
        if u is None:
            await cb.message.answer("Tap /start first.")
            return
        u.smart_mode = not bool(u.smart_mode)
        state = "ON" if u.smart_mode else "OFF"
    await cb.message.answer(
        f"🧠 <b>SMART mode is {state}</b>\n"
        "SMART resizes each buy from your win rate. OFF uses the fixed preset size.",
        parse_mode="HTML",
    )


async def _meta(ca: str) -> dict:
    from app.chain.prices import live_mark
    return await live_mark(ca)


async def _price_usd(ca: str) -> float | None:
    return (await _meta(ca)).get("px")


def _mc(n: float) -> str:
    if n >= 1_000_000:
        return f"${n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"${n / 1_000:.1f}K"
    if n > 0:
        return f"${n:.0f}"
    return "—"


async def _sol_usd() -> float:
    px = await _price_usd("So11111111111111111111111111111111111111112")
    if px and px > 5:
        return float(px)
    return 0.0


async def _restore_bags(s, user_id: int) -> None:
    """If the wallet still holds a coin, it is an open trade."""
    from app.chain.solana_jupiter import spl_holding, wallet_mints

    addr = (
        await s.execute(
            select(Wallet.address).where(Wallet.user_id == user_id, Wallet.chain == "solana")
        )
    ).scalar_one_or_none()
    if not addr:
        return
    held = await wallet_mints(addr)
    if not held:
        cas = {
            row[0]
            for row in (
                await s.execute(
                    select(Position.ca).where(Position.user_id == user_id, Position.chain == "solana")
                )
            ).all()
        }
        cas.update(
            row[0]
            for row in (
                await s.execute(
                    select(Order.ca)
                    .where(Order.user_id == user_id, Order.chain == "solana", Order.side == "buy")
                    .order_by(Order.id.desc())
                    .limit(40)
                )
            ).all()
        )
        held = []
        for ca in list(cas)[:12]:
            bag = await spl_holding(addr, ca)
            if bag and bag[1] > 0:
                held.append((ca, bag[1]))
    for ca, ui in held:
        pos = (
            await s.execute(
                select(Position).where(Position.user_id == user_id, Position.ca == ca)
                .order_by(Position.id.desc()).limit(1)
            )
        ).scalars().first()
        buy = (
            await s.execute(
                select(Order)
                .where(
                    Order.user_id == user_id,
                    Order.ca == ca,
                    Order.side == "buy",
                    Order.quote_amount_native > 0,
                )
                .order_by(Order.id.desc())
                .limit(1)
            )
        ).scalars().first()
        cost = float(buy.quote_amount_native or 0) if buy is not None else 0.0
        if pos is not None and pos.cost_basis_native > cost:
            cost = float(pos.cost_basis_native)
        if pos is None:
            pos = Position(
                user_id=user_id,
                ca=ca,
                chain="solana",
                tokens_open=ui,
                avg_entry_native=(cost / ui) if ui and cost else 0.0,
                cost_basis_native=cost,
                hwm_price_native=(cost / ui) if ui and cost else 0.0,
                ladder_state="active",
            )
            s.add(pos)
        else:
            pos.tokens_open = ui
            pos.closed_at = None
            pos.ladder_state = "active"
            if cost and pos.cost_basis_native <= 0:
                pos.cost_basis_native = cost
                pos.avg_entry_native = cost / ui
        await s.flush()


async def _cards(tg_id: int):
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == tg_id))
        ).scalar_one_or_none()
        if u is None:
            return None, []
        await _restore_bags(s, u.id)
        rows = (
            await s.execute(
                select(Position).where(Position.user_id == u.id, Position.tokens_open > 0)
                .order_by(Position.id.desc())
            )
        ).scalars().all()
        closed = (
            await s.execute(
                select(func.coalesce(func.sum(Fill.native_delta), 0.0))
                .join(Order, Order.id == Fill.order_id)
                .where(Order.user_id == u.id, Order.side == "sell", Order.status.in_(("sent", "filled")))
            )
        ).scalar_one()
        addr = (
            await s.execute(
                select(Wallet.address).where(Wallet.user_id == u.id, Wallet.chain == "solana")
            )
        ).scalar_one_or_none()
        flow_rows = (
            await s.execute(
                select(Order.ca, Order.side, Fill.native_delta, Fill.token_delta, Order.quote_amount_native)
                .join(Fill, Fill.order_id == Order.id)
                .where(Order.user_id == u.id, Order.status.in_(("sent", "filled")))
            )
        ).all()
        snapshot = [
            (p.id, p.ca, p.chain, float(p.cost_basis_native or 0), float(p.avg_entry_native or 0))
            for p in rows
        ]
    books: dict[str, dict] = {}
    for fca, side, native, tokens, quote in flow_rows:
        book = books.setdefault(fca, {"bought": 0.0, "buy_tok": 0.0, "sold": 0.0, "sell_tok": 0.0, "quote": 0.0})
        if side == "buy":
            book["bought"] += abs(float(native or 0))
            book["buy_tok"] += abs(float(tokens or 0))
            book["quote"] += abs(float(quote or 0))
        else:
            book["sold"] += float(native or 0)
            book["sell_tok"] += abs(float(tokens or 0))
    sol = await _sol_usd()
    dust_sol = (0.20 / sol) if sol > 5 else 0.0015
    holds: dict[str, float] = {}
    scanned = False
    if addr:
        try:
            from app.chain.solana_jupiter import wallet_mints
            found = await wallet_mints(addr)
            if found is not None:
                scanned = True
                holds = {mint: ui for mint, ui in found}
        except Exception:
            scanned = False
    metas = await asyncio.gather(*[_meta(ca) for _, ca, *_rest in snapshot], return_exceptions=True)
    cards = []
    dead: list[int] = []
    paid = worth = known_worth = 0.0
    for (pid, ca, chain, cost, entry), meta in zip(snapshot, metas):
        if isinstance(meta, Exception):
            meta = {}
        px = meta.get("px")
        sym = (meta.get("sym") or "").strip()
        short = sym if sym else (ca if len(ca) < 14 else ca[:6] + "…" + ca[-4:])
        book = books.get(ca) or {}
        bought = float(book.get("bought") or 0)
        quoted = float(book.get("quote") or 0)
        buy_tok = float(book.get("buy_tok") or 0)
        sell_tok = float(book.get("sell_tok") or 0)
        base = max(cost, bought, quoted)
        still = base
        if buy_tok > 0 and sell_tok > 0:
            ratio = sell_tok / buy_tok
            if 0.05 <= ratio <= 20:
                still = base * max(0.0, 1.0 - min(1.0, ratio))
        held_ui = holds.get(ca) if scanned else None
        if scanned and holds and ca not in holds:
            dead.append(pid)
            continue
        now = None
        if px and sol > 0 and held_ui and held_ui > 0:
            now = held_ui * px / sol
        elif px and sol > 0 and entry > 0 and still > 0 and not scanned:
            mult = (px / sol) / entry
            if 0.02 <= mult <= 30:
                now = still * mult
        if now is not None and now < dust_sol:
            continue
        if now is None and not held_ui and still < dust_sol:
            continue
        mc = _mc(meta.get("mc") or 0) if meta.get("mc") else ""
        if now is None:
            paid_line = f"Paid <b>{still:.4f}</b> SOL\n" if still >= 0.0001 else ""
            cards.append((pid, (
                f"<b>{short}</b>\n"
                f"{paid_line}"
                f"Price is still loading. You can still sell.\n"
                f"<code>{ca}</code>"
            )))
            if still >= 0.0001:
                paid += still
            continue
        worth += now
        known_worth += now
        paid += still
        diff = now - still
        pct = ((now / still) - 1) * 100 if still >= 0.0001 else 0.0
        mark = "🟢" if diff >= -0.0001 else "🔴"
        mc_line = f"\nMC {mc}" if mc and now >= dust_sol else ""
        cards.append((pid, (
            f"{mark} <b>{short}</b>  {pct:+.0f}%\n"
            f"Paid {still:.4f} · now <b>{now:.4f}</b>\n"
            f"PnL <b>{diff:+.4f} SOL</b>{mc_line}\n"
            f"<code>{ca}</code>"
        )))
    if dead:
        async with get_session() as s:
            for pid in dead:
                pos = await s.get(Position, pid)
                if pos is None or pos.tokens_open <= 0:
                    continue
                pos.tokens_open = 0
                pos.ladder_state = "dead"
                pos.closed_at = datetime.now(timezone.utc)
    return {
        "paid": paid,
        "worth": worth,
        "known_worth": known_worth,
        "closed": float(closed or 0),
        "n": len(cards),
    }, cards


def _spark(vals: list[float]) -> str:
    bars = "▁▂▃▄▅▆▇█"
    if not vals:
        return "────────"
    lo, hi = min(vals), max(vals)
    if abs(hi - lo) < 1e-9:
        return "▄" * 16
    out = []
    for v in vals:
        i = round((v - lo) / (hi - lo) * 7)
        out.append(bars[max(0, min(7, i))])
    return "".join(out)


async def _pnl_text(tg_id: int, key: str) -> str:
    windows = {
        "1h": ("1H", timedelta(hours=1), 12),
        "1d": ("1D", timedelta(days=1), 24),
        "1w": ("1W", timedelta(days=7), 7),
        "1m": ("1M", timedelta(days=30), 30),
    }
    label, span, buckets = windows.get(key, windows["1d"])
    now = datetime.now(timezone.utc)
    start = now - span
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == tg_id))
        ).scalar_one_or_none()
        if u is None:
            return "Tap /start first."
        from app.worker.executor import sell_events
        events = await sell_events(s, u.id)
    chosen = []
    for e in events:
        ts = e["ts"]
        if ts is not None and ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        if ts is None or ts >= start:
            if ts is not None and ts >= start:
                chosen.append((ts, e))
    total = 0.0
    series = []
    for ts, e in chosen:
        total += e["pnl"]
        series.append((ts, total))
    width = span / buckets
    vals: list[float] = []
    running = 0.0
    idx = 0
    for i in range(buckets):
        edge = start + width * (i + 1)
        while idx < len(series) and series[idx][0] <= edge:
            running = series[idx][1]
            idx += 1
        vals.append(running)
    lines = [
        f"<b>PnL · {label}</b>",
        f"<code>{_spark(vals)}</code>",
        f"{(vals[0] if vals else 0):+.4f} → <b>{total:+.4f} SOL</b>",
        "",
    ]
    if not chosen:
        lines.append("No sells in this window.")
    for _ts, e in chosen[-4:]:
        mark = "🟢" if e["pnl"] >= 0 else "🔴"
        short = e["ca"] if len(e["ca"]) < 12 else e["ca"][:4] + "…" + e["ca"][-4:]
        lines.append(f"{mark} {e['pnl']:+.4f} SOL · {short}")
    summary, cards = await _cards(tg_id)
    if summary and cards:
        lines.append("")
        lines.append(f"Open · {summary['n']}")
        for _pid, text in cards[:8]:
            lines.append(text.split("\n", 1)[0])
        diff = summary["worth"] - summary["paid"]
        mark = "🟢" if diff >= 0 else "🔴"
        lines.append(f"{mark} <b>{diff:+.4f} SOL</b> still open")
    elif summary:
        lines.append("")
        lines.append("No open trades above $0.20.")
    lines.append("Closed is SOL received minus what that slice cost.")
    return "\n".join(lines)


@router.callback_query(F.data == "menu:pnl")
async def cb_pnl(cb: CallbackQuery) -> None:
    await cb.answer()
    await cb.message.answer(await _pnl_text(cb.from_user.id, "1d"), parse_mode="HTML", reply_markup=pnl_kb("1d"))


@router.callback_query(F.data.startswith("pnl:"))
async def cb_pnl_window(cb: CallbackQuery) -> None:
    key = (cb.data or "pnl:1d").split(":", 1)[1]
    if key not in ("1h", "1d", "1w", "1m"):
        key = "1d"
    await cb.answer()
    text = await _pnl_text(cb.from_user.id, key)
    try:
        await cb.message.edit_text(text, parse_mode="HTML", reply_markup=pnl_kb(key))
    except Exception:
        await cb.message.answer(text, parse_mode="HTML", reply_markup=pnl_kb(key))


@router.callback_query(F.data == "menu:buy")
async def cb_buy_hint(cb: CallbackQuery) -> None:
    await cb.answer()
    now = datetime.now(timezone.utc)
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == cb.from_user.id))
        ).scalar_one_or_none()
        rows = []
        if u is not None:
            rows = (
                await s.execute(
                    select(Subscription).where(Subscription.user_id == u.id)
                )
            ).scalars().all()
    live = False
    for row in rows:
        exp = _aware(row.expires_at)
        if row.status in ("active", "lifetime", "trial") and exp and exp > now:
            live = True
            break
    if not live:
        await cb.message.answer(
            "Buys need Free Trial or Subscribe.\n"
            "Sells stay on. Open Sell or Positions."
        )
        return
    await cb.message.answer(
        "Auto-buy is on for every call.\n"
        "One manual buy: <code>/buy CA</code>",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "menu:positions")
async def cb_positions(cb: CallbackQuery) -> None:
    await cb.answer()
    try:
        summary, cards = await _cards(cb.from_user.id)
    except Exception:
        await cb.message.answer("Positions did not load. Tap Positions again.")
        return
    if summary is None:
        await cb.message.answer("Tap /start first.")
        return
    if not cards:
        await cb.message.answer("No open trades above $0.20.")
        return
    if summary["paid"] >= 0.001:
        diff = summary["worth"] - summary["paid"]
        mark = "🟢" if diff >= 0 else "🔴"
        head = (
            f"<b>{summary['n']} open</b>\n"
            f"Now {summary['worth']:.4f} SOL\n"
            f"Paid {summary['paid']:.4f} SOL\n"
            f"{mark} <b>{diff:+.4f} SOL</b>"
        )
    else:
        head = f"<b>{summary['n']} open</b> · now {summary['worth']:.4f} SOL"
    await cb.message.answer(head, parse_mode="HTML")
    for pid, text in cards:
        await cb.message.answer(text, parse_mode="HTML", reply_markup=position_kb(pid))


@router.callback_query(F.data.startswith("sell:"))
async def cb_sell(cb: CallbackQuery) -> None:
    await cb.answer()
    parts = (cb.data or "").split(":")
    if len(parts) != 3:
        await cb.message.answer("That button is out of date. Open Positions again.")
        return
    try:
        pid = int(parts[1])
    except ValueError:
        await cb.message.answer("That button is out of date. Open Positions again.")
        return
    raw = parts[2]
    async with get_session() as s:
        u = (
            await s.execute(select(User).where(User.tg_id == cb.from_user.id))
        ).scalar_one_or_none()
        pos = await s.get(Position, pid) if u else None
        if u is None or pos is None or pos.user_id != u.id or pos.tokens_open <= 0:
            await cb.message.answer("That position is already closed.")
            return
        uid, ca = u.id, pos.ca
        cost = float(pos.cost_basis_native or 0)
        entry = float(pos.avg_entry_native or 0)
        chain = pos.chain
    if raw == "init":
        px = await _price_usd(ca) if chain == "solana" else None
        sol = await _sol_usd()
        worth = cost * ((px / sol) / entry) if px and sol > 0 and entry > 0 else 0
        if worth <= 0 or worth <= cost:
            pct = 1.0
            note = "Underwater. Selling all."
        else:
            pct = min(1.0, cost / worth)
            note = f"Selling {int(pct * 100)}% to take the cost out."
    else:
        try:
            pct = int(raw) / 100.0
        except ValueError:
            await cb.message.answer("That button is out of date. Open Positions again.")
            return
        note = f"Selling {int(pct * 100)}%…"
    await cb.message.answer(note)
    await execute_sell(bot=cb.message.bot, user_id=uid, ca=ca, pct=pct, kind="manual")
