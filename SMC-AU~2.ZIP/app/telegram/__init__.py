"""aiogram3-based Telegram interface."""
