"""Square result card sent when the bot sells. Brand matches the site."""
from __future__ import annotations

import io
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

_ROOT = Path(__file__).resolve().parents[2]
_FONT = _ROOT / "static" / "fonts" / "DejaVuSans-Bold.ttf"
_FONT_SM = _ROOT / "static" / "fonts" / "DejaVuSans.ttf"
_LOGO = _ROOT / "static" / "brand" / "logo.png"

_BG = (10, 10, 10)
_GREEN = (0, 255, 136)
_RED = (255, 68, 68)
_WHITE = (255, 255, 255)
_MUTED = (107, 124, 107)


def _font(size: int, bold: bool = True) -> ImageFont.ImageFont:
    path = _FONT if bold else _FONT_SM
    try:
        return ImageFont.truetype(str(path), size)
    except Exception:
        return ImageFont.load_default()


def _logo(size: int) -> Image.Image | None:
    if not _LOGO.exists():
        return None
    try:
        src = Image.open(_LOGO).convert("RGBA").resize((size, size), Image.Resampling.LANCZOS)
    except Exception:
        return None
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse((1, 1, size - 2, size - 2), fill=255)
    src.putalpha(mask)
    return src


def render_pnl_card(*, name: str, multiple: float, pnl_sol: float) -> bytes:
    win = pnl_sol >= 0
    accent = _GREEN if win else _RED
    im = Image.new("RGB", (1080, 1080), _BG)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((36, 36, 1044, 1044), radius=48, outline=accent, width=8)
    logo = _logo(220)
    if logo is not None:
        im.paste(logo, (430, 88), logo)
    d.text((540, 340), "SOLANAMEMECOINS", font=_font(36, bold=False), fill=_GREEN, anchor="ma")
    mult = f"{multiple:.1f}×" if multiple > 0 else ("STOP" if pnl_sol < 0 else "SOLD")
    d.text((540, 470), mult, font=_font(180), fill=accent, anchor="ma")
    d.text((540, 680), (name or "TOKEN")[:18], font=_font(78), fill=_WHITE, anchor="ma")
    sign = "+" if pnl_sol > 0 else ""
    d.text((540, 790), f"{sign}{pnl_sol:.4f} SOL", font=_font(64), fill=accent, anchor="ma")
    d.text((540, 940), "dashboard.memesolana.com", font=_font(32, bold=False), fill=_MUTED, anchor="ma")
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()
