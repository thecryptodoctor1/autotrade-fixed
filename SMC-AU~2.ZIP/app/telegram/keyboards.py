from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💎 Wallet", callback_data="menu:wallet"),
                InlineKeyboardButton(text="📊 Positions", callback_data="menu:positions"),
            ],
            [
                InlineKeyboardButton(text="⚡ Free Trial", callback_data="menu:trial"),
                InlineKeyboardButton(text="💳 Subscribe", callback_data="menu:sub"),
            ],
            [
                InlineKeyboardButton(text="🧠 Mode", callback_data="menu:mode"),
                InlineKeyboardButton(text="⚙️ Risk", callback_data="menu:risk"),
                InlineKeyboardButton(text="⏸ Pause", callback_data="menu:pause"),
            ],
            [
                InlineKeyboardButton(text="✨ SMART", callback_data="menu:smart"),
            ],
            [
                InlineKeyboardButton(text="📈 PnL", callback_data="menu:pnl"),
                InlineKeyboardButton(text="🎁 Refer & earn", callback_data="menu:ref"),
            ],
            [
                InlineKeyboardButton(text="📚 Guide", callback_data="menu:guide"),
                InlineKeyboardButton(text="💬 Support", callback_data="menu:support"),
            ],
        ]
    )


def risk_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🛡 SAFE", callback_data="risk:SAFE"),
                InlineKeyboardButton(text="⚖ STANDARD", callback_data="risk:STANDARD"),
                InlineKeyboardButton(text="⚡ DEGEN", callback_data="risk:DEGEN"),
            ],
            [InlineKeyboardButton(text="← back", callback_data="menu:home")],
        ]
    )


def pnl_kb(active: str = "1d") -> InlineKeyboardMarkup:
    def label(code: str, name: str) -> str:
        return f"• {name}" if code == active else name
    return InlineKeyboardMarkup(
        inline_keyboard=[[
            InlineKeyboardButton(text=label("1h", "1H"), callback_data="pnl:1h"),
            InlineKeyboardButton(text=label("1d", "1D"), callback_data="pnl:1d"),
            InlineKeyboardButton(text=label("1w", "1W"), callback_data="pnl:1w"),
            InlineKeyboardButton(text=label("1m", "1M"), callback_data="pnl:1m"),
        ]]
    )


def position_kb(position_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💸 Sell 50%", callback_data=f"sell:{position_id}:50"),
                InlineKeyboardButton(text="💸 Sell 100%", callback_data=f"sell:{position_id}:100"),
            ],
            [InlineKeyboardButton(text="💰 Sell initials", callback_data=f"sell:{position_id}:init")],
            [
                InlineKeyboardButton(text="← Back", callback_data="menu:home"),
                InlineKeyboardButton(text="🔄 Refresh", callback_data="menu:positions"),
            ],
        ]
    )
