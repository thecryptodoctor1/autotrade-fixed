"""Admin-only Telegram commands. Registered by main.py — see handlers."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import func, select

from app.config import get_settings
from app.db import Fill, Order, Subscription, User, get_session

router = Router()


def _is_admin(tg_id: int) -> bool:
    return tg_id in get_settings().admin_ids


@router.message(Command("admin_stats"))
async def admin_stats(msg: Message) -> None:
    if not _is_admin(msg.from_user.id):
        return
    async with get_session() as s:
        n_users = (await s.execute(select(func.count(User.id)))).scalar_one()
        n_active = (
            await s.execute(
                select(func.count(Subscription.id)).where(Subscription.status == "active")
            )
        ).scalar_one()
        n_orders = (await s.execute(select(func.count(Order.id)))).scalar_one()
        n_fills = (await s.execute(select(func.count(Fill.id)))).scalar_one()
    mrr = n_active * get_settings().SUB_PRICE_USD
    await msg.answer(
        f"users:   {n_users}\nactive subs: {n_active}   (MRR ~${mrr:.0f})\n"
        f"orders: {n_orders}\nfills:   {n_fills}"
    )


@router.message(Command("admin_grant"))
async def admin_grant(msg: Message) -> None:
    if not _is_admin(msg.from_user.id):
        return
    parts = (msg.text or "").split()
    if len(parts) != 3:
        await msg.answer("Usage: /admin_grant <tg_id> <days>")
        return
    tg_id = int(parts[1])
    days = int(parts[2])
    now = datetime.now(timezone.utc)
    async with get_session() as s:
        u = (await s.execute(select(User).where(User.tg_id == tg_id))).scalar_one_or_none()
        if u is None:
            await msg.answer("User not found.")
            return
        sub = Subscription(
            user_id=u.id, status="active",
            started_at=now, expires_at=now + timedelta(days=days),
            invoice_memo="admin_grant",
        )
        s.add(sub)
    await msg.answer(f"Granted {days}d to {tg_id}.")


@router.message(Command("admin_pause_all"))
async def admin_pause_all(msg: Message) -> None:
    if not _is_admin(msg.from_user.id):
        return
    async with get_session() as s:
        users = (await s.execute(select(User))).scalars().all()
        for u in users:
            u.auto_paused = True
    await msg.answer(f"Paused auto-buy for {len(users)} users. Manual sells still allowed.")
