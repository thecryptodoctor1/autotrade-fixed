"""Watch every user's Solana wallet for incoming deposits."""
from __future__ import annotations

import asyncio
import time

import httpx
from sqlalchemy import select

from app.config import get_settings
from app.db import Subscription, User, Wallet, get_session
from app.logging_conf import log

# Sells and buys move SOL too. Those are not deposits.
_quiet_until: dict[str, float] = {}


def quiet_wallet(address: str, seconds: float = 150) -> None:
    _quiet_until[address] = time.time() + seconds


def wallet_is_quiet(address: str) -> bool:
    return time.time() < _quiet_until.get(address, 0.0)


class DepositWatcher:
    """Poll every user's Solana wallet balance and detect new incoming SOL."""

    def __init__(self, bot):
        self.bot = bot
        self._last_balance: dict[str, float] = {}  # address -> lamports
        self._notified_first: set[str] = set()      # address addr with 1st deposit noted
        self._stop = asyncio.Event()

    async def run(self) -> None:
        s = get_settings()
        log().info("deposit_watcher.start")
        # warmup — populate last-balance from RPC so we don't fire for existing funds
        await self._warmup()
        while not self._stop.is_set():
            try:
                await self._tick()
            except Exception:
                log().exception("deposit_watcher.tick_error")
            await asyncio.sleep(30)

    def stop(self) -> None:
        self._stop.set()

    async def _warmup(self) -> None:
        async with get_session() as db:
            wallets = (
                await db.execute(select(Wallet).where(Wallet.chain == "solana"))
            ).scalars().all()
        for w in wallets:
            bal = await self._sol_balance(w.address)
            self._last_balance[w.address] = bal

    async def _tick(self) -> None:
        async with get_session() as db:
            rows = (
                await db.execute(
                    select(Wallet, User).join(User, User.id == Wallet.user_id)
                    .where(Wallet.chain == "solana")
                )
            ).all()

        for wallet, user in rows:
            try:
                bal = await self._sol_balance(wallet.address)
            except Exception:
                continue
            prev = self._last_balance.get(wallet.address, 0.0)
            delta = bal - prev
            self._last_balance[wallet.address] = bal
            if wallet_is_quiet(wallet.address):
                continue
            if delta >= 0.001:
                await self._notify_deposit(user, wallet, delta, bal, first_time=prev < 0.01)

    async def _sol_balance(self, addr: str) -> float:
        s = get_settings()
        async with httpx.AsyncClient(timeout=6.0) as cli:
            r = await cli.post(
                s.SOLANA_RPC,
                json={"jsonrpc": "2.0", "id": 1, "method": "getBalance", "params": [addr]},
            )
            if r.status_code != 200:
                return self._last_balance.get(addr, 0.0)
            v = ((r.json() or {}).get("result") or {}).get("value")
        return (v or 0) / 1_000_000_000

    async def _notify_deposit(self, user, wallet, delta: float, total: float, first_time: bool = False) -> None:

        # Check sub status for CTA
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        active = False
        async with get_session() as db:
            rows = (
                await db.execute(
                    select(Subscription).where(Subscription.user_id == user.id)
                )
            ).scalars().all()
            for row in rows:
                if row.status == "lifetime" or row.plan == "lifetime":
                    active = True
                    break
                exp = row.expires_at
                if exp is not None and exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if row.status in ("active", "trial") and exp and exp > now:
                    active = True
                    break

        if first_time:
            head = f"🎉 <b>FIRST DEPOSIT DETECTED · {delta:.4f} SOL</b>"
            body = (
                f"Your balance: <b>{total:.4f} SOL</b> ready to trade\n\n"
                f"⚡ Bot will auto-buy every call in the signal channel\n"
                f"📈 Exit ladder fires automatically — you literally do nothing\n"
            )
        else:
            head = f"💰 <b>+{delta:.4f} SOL deposit</b>"
            body = f"New balance: <b>{total:.4f} SOL</b>\n"

        if active:
            cta = (
                "\n✅ You're subscribed — auto-buy is <b>LIVE</b>.\n"
                "Next call in the channel gets fired for you 🚀\n"
                "Check /positions anytime."
            )
        else:
            cta = (
                "\n🔒 Auto-buy is <b>PAUSED</b> until you subscribe.\n"
                "$49/mo · 1 good call pays for the month.\n"
                "👉 /subscribe to activate now"
            )

        try:
            await self.bot.send_message(user.tg_id, head + "\n\n" + body + cta, parse_mode="HTML")
            log().info("deposit.notified user=%s delta=%.4f sub_active=%s", user.tg_id, delta, active)
        except Exception:
            log().warning("deposit.dm_fail user=%s", user.tg_id)
