"""Background price poller for open positions.

Polls only tokens with at least one open position, at the configured cadence
per chain. Prices are cached in memory keyed by (chain, ca).
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from app.chain.prices import get_price_usd
from app.config import get_settings
from app.logging_conf import log


@dataclass(slots=True)
class PriceCacheEntry:
    price_usd: float
    ts: float
    hwm: float = 0.0


@dataclass
class PricePoller:
    interval_sol: float = 3.0
    interval_evm: float = 8.0
    watched: dict[tuple[str, str], PriceCacheEntry] = field(default_factory=dict)
    _stop: asyncio.Event = field(default_factory=asyncio.Event)

    @classmethod
    def from_settings(cls) -> "PricePoller":
        s = get_settings()
        return cls(interval_sol=s.PRICE_POLL_SOL_SECS, interval_evm=s.PRICE_POLL_EVM_SECS)

    def watch(self, chain: str, ca: str) -> None:
        self.watched.setdefault((chain, ca), PriceCacheEntry(price_usd=0.0, ts=0.0))

    def unwatch(self, chain: str, ca: str) -> None:
        self.watched.pop((chain, ca), None)

    def get(self, chain: str, ca: str) -> PriceCacheEntry | None:
        return self.watched.get((chain, ca))

    def stop(self) -> None:
        self._stop.set()

    async def run(self) -> None:
        log().info("price_poller.start", n=len(self.watched))
        while not self._stop.is_set():
            try:
                await self._sync_open()
            except Exception:
                log().exception("price_poller.sync_error")
            tasks = []
            for chain, ca in list(self.watched):
                tasks.append(self._tick(chain, ca))
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
            await asyncio.sleep(min(self.interval_sol, self.interval_evm))

    async def _sync_open(self) -> None:
        from sqlalchemy import select

        from app.db import Position, get_session

        async with get_session() as s:
            rows = (
                await s.execute(
                    select(Position.chain, Position.ca).where(Position.tokens_open > 0)
                )
            ).all()
        live = {(chain, ca) for chain, ca in rows}
        for key in list(self.watched):
            if key not in live:
                self.watched.pop(key, None)
        for chain, ca in live:
            self.watch(chain, ca)

    async def _tick(self, chain: str, ca: str) -> None:
        p = await get_price_usd(ca, chain)
        if p is None:
            return
        import time

        e = self.watched.get((chain, ca))
        if e is None:
            return
        e.price_usd = p
        e.ts = time.time()
        if p > e.hwm:
            e.hwm = p
