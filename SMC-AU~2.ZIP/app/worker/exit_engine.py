"""Fire ladder rungs off live prices and actually sell."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone

from sqlalchemy import select

from app.db import ExitRule, Fill, Order, Position, User, get_session
from app.logging_conf import log
from app.risk.ladder import tighten_trail_after
from app.risk.presets import PRESETS
from app.worker.price_poller import PricePoller

_SOL = "So11111111111111111111111111111111111111112"


@dataclass
class ExitEngine:
    poller: PricePoller
    bot: object | None = None
    interval_secs: float = 1.0
    _stop: asyncio.Event | None = None
    _retry_at: dict[tuple[int, int], float] = field(default_factory=dict)
    _fetched: dict[tuple[str, str], float] = field(default_factory=dict)
    _band: dict[int, int] = field(default_factory=dict)
    _seen: dict[int, float] = field(default_factory=dict)
    _ping_at: dict[int, float] = field(default_factory=dict)
    _sl_hits: dict[int, int] = field(default_factory=dict)
    _also: dict[tuple[int, int], list[int]] = field(default_factory=dict)
    _peak: dict[int, float] = field(default_factory=dict)
    _trough: dict[int, float] = field(default_factory=dict)
    _entry_px: dict[int, float] = field(default_factory=dict)
    _fail_n: dict[int, int] = field(default_factory=dict)
    # (bag_tokens, fetched_at). Missing field made every scan tick raise
    # AttributeError and the whole exit engine silently died, so no stop or
    # take-profit ever fired. See prod incidents 1, 2 and the ghost positions.
    _held: dict[int, tuple[float, float]] = field(default_factory=dict)
    _sol_usd: float = 0.0
    _sol_at: float = 0.0

    async def run(self) -> None:
        self._stop = asyncio.Event()
        log().info("exit_engine.start")
        while not self._stop.is_set():
            try:
                await self._scan_once()
            except Exception:
                log().exception("exit_engine.tick_error")
            await asyncio.sleep(self.interval_secs)

    def stop(self) -> None:
        if self._stop is not None:
            self._stop.set()

    async def _quote_usd(self, chain: str) -> float:
        now = time.time()
        if chain == "solana":
            if now - self._sol_at > 30:
                from app.chain.prices import get_price_usd
                px = await get_price_usd(_SOL, "solana")
                if px and px > 5:
                    self._sol_usd = float(px)
                self._sol_at = now
            return self._sol_usd
        return 1.0

    async def _scan_once(self) -> None:
        from app.chain.prices import get_price_usd, live_mark

        async with get_session() as s:
            open_rows = (
                await s.execute(
                    select(Position.ca, Position.chain).where(Position.tokens_open > 0)
                )
            ).all()
        cas = list({ca for ca, chain in open_rows if chain == "solana"})

        async def _one_mark(ca: str) -> tuple[str, dict]:
            try:
                mark = await asyncio.wait_for(live_mark(ca), timeout=3.5)
            except Exception:
                mark = {}
            return ca, mark or {}

        marks = {}
        if cas:
            for ca, mark in await asyncio.gather(*[_one_mark(ca) for ca in cas]):
                marks[ca] = mark

        jobs: list[tuple] = []
        async with get_session() as s:
            positions = (
                await s.execute(select(Position).where(Position.tokens_open > 0))
            ).scalars().all()
            for pos in positions:
                fresh = marks.get(pos.ca) or {}
                px_hi = float(fresh.get("px") or 0)
                px_lo = float(fresh.get("px_lo") or 0) or px_hi
                if px_hi <= 0:
                    px_hi = await self._mark_usd(pos.chain, pos.ca, get_price_usd) or 0
                    px_lo = px_lo or px_hi
                if px_hi <= 0:
                    continue
                quote = self._sol_usd if pos.chain == "solana" else 1.0
                if pos.chain == "solana" and quote < 5:
                    quote = await self._quote_usd(pos.chain)
                if quote >= 5:
                    self._sol_usd = quote
                elif self._sol_usd >= 5:
                    quote = self._sol_usd
                else:
                    continue
                bag = None
                cached = self._held.get(pos.id)
                if pos.chain == "solana" and not (cached and time.time() - cached[1] < 8):
                    try:
                        from app.chain.solana_jupiter import spl_holding
                        from app.db import Wallet
                        w = (
                            await s.execute(
                                select(Wallet).where(
                                    Wallet.user_id == pos.user_id, Wallet.chain == "solana"
                                )
                            )
                        ).scalar_one_or_none()
                        bag = await asyncio.wait_for(spl_holding(w.address, pos.ca), timeout=2.5) if w else None
                        if bag and bag[1] > 0:
                            self._held[pos.id] = (bag[1], time.time())
                            pos.tokens_open = bag[1]
                        elif bag is not None and bag[0] == 0:
                            pos.tokens_open = 0
                            pos.ladder_state = "dead"
                            pos.closed_at = datetime.now(timezone.utc)
                            continue
                    except Exception:
                        pass
                if pos.avg_entry_native <= 0:
                    continue
                chart_hi = (px_hi / quote) / pos.avg_entry_native
                chart_lo = (px_lo / quote) / pos.avg_entry_native
                if chart_lo <= 0:
                    continue
                self._trough[pos.id] = min(self._trough.get(pos.id, chart_lo), chart_lo)
                if chart_hi > 1:
                    self._peak[pos.id] = max(self._peak.get(pos.id, 0.0), chart_hi)
                sl_mult = self._trough[pos.id]
                mult = max(chart_hi, self._peak.get(pos.id, 0.0))
                mark = px_hi / quote
                if mark > (pos.hwm_price_native or 0):
                    pos.hwm_price_native = mark
                owner = await s.get(User, pos.user_id)
                sl_pct = 0.30
                if owner is not None and owner.risk_preset in PRESETS:
                    sl_pct = PRESETS[owner.risk_preset].hard_sl_pct
                floor = 1.0 - sl_pct
                # A wick through the stop still sells, unless the coin has
                # climbed back above entry. Then the peak take-profit runs.
                under_stop = chart_lo <= floor + 0.03 or (
                    sl_mult <= floor and chart_hi < 1.0
                )
                if under_stop:
                    key = (pos.id, 0)
                    if time.time() < self._retry_at.get(key, 0):
                        continue
                    if await self._paper(s, pos):
                        ok = await self._paper_sell(s, pos, 1.0, sl_mult, "sl")
                        if not ok:
                            self._retry_at[key] = time.time() + 15
                        continue
                    jobs.append((pos.user_id, pos.ca, pos.id, 0, 1.0, sl_mult, "sl"))
                    continue
                self._trough.pop(pos.id, None)
                rules = (
                    await s.execute(
                        select(ExitRule).where(ExitRule.position_id == pos.id)
                    )
                ).scalars().all()
                if not any(r.rule == "recover" for r in rules):
                    from app.risk.ladder import build_ladder, overrides_from_user
                    preset_name = owner.risk_preset if owner and owner.risk_preset in PRESETS else "SAFE"
                    _overrides = overrides_from_user(owner) if owner is not None else None
                    for rung in build_ladder(preset_name, overrides=_overrides).rungs:
                        s.add(ExitRule(
                            position_id=pos.id,
                            rule=rung.rule,
                            trigger_mult=rung.trigger_mult,
                            sell_pct_of_remaining=rung.sell_pct_of_remaining,
                            trail_pct=rung.trail_pct,
                            fired=False,
                        ))
                    await s.flush()
                    rules = (
                        await s.execute(
                            select(ExitRule).where(ExitRule.position_id == pos.id)
                        )
                    ).scalars().all()
                if not any(r.rule == "tp15" for r in rules):
                    s.add(ExitRule(
                        position_id=pos.id,
                        rule="tp15",
                        trigger_mult=1.5,
                        sell_pct_of_remaining=0.40,
                        trail_pct=None,
                        fired=False,
                    ))
                    await s.flush()
                    rules = (
                        await s.execute(
                            select(ExitRule).where(ExitRule.position_id == pos.id)
                        )
                    ).scalars().all()
                rules.sort(key=lambda r: (
                    0 if r.rule == "sl" else 1,
                    r.trigger_mult if r.trigger_mult is not None else 99,
                ))
                due = []
                for rule in rules:
                    if rule.rule in ("sl", "trail", "notify10x"):
                        continue
                    if rule.fired or not rule.sell_pct_of_remaining:
                        continue
                    if rule.trigger_mult is None or mult + 1e-9 < rule.trigger_mult:
                        continue
                    due.append(rule)
                if due:
                    remain = 1.0
                    for rule in due:
                        remain *= 1.0 - float(rule.sell_pct_of_remaining)
                    pct = max(0.05, min(0.95, 1.0 - remain))
                    hit = due[-1]
                    key = (pos.id, hit.id)
                    if time.time() < self._retry_at.get(key, 0):
                        continue
                    self._also[key] = [r.id for r in due]
                    label = "tp3x" if any(r.rule == "tp3x" for r in due) else hit.rule
                    if await self._paper(s, pos):
                        ok = await self._paper_sell(s, pos, pct, mult, label)
                        if ok:
                            now_dt = datetime.now(timezone.utc)
                            for rule in due:
                                rule.fired = True
                                rule.fired_at = now_dt
                            self._retry_at.pop(key, None)
                        else:
                            self._retry_at[key] = time.time() + 20
                        continue
                    jobs.append((pos.user_id, pos.ca, pos.id, hit.id, pct, mult, label))
                    continue
                hit = None
                for rule in rules:
                    if rule.fired and not (rule.rule == "sl" and pos.tokens_open > 0):
                        continue
                    if rule.fired and rule.rule == "sl":
                        rule.fired = False
                    if not self._hit(rule, mult, mark, pos):
                        continue
                    hit = rule
                    break
                if hit is None:
                    await self._ping(owner, pos, mult)
                    continue
                key = (pos.id, hit.id)
                if time.time() < self._retry_at.get(key, 0):
                    continue
                if await self._paper(s, pos):
                    ok = await self._paper_sell(
                        s, pos, float(hit.sell_pct_of_remaining or 1), mult, hit.rule,
                    )
                    if ok:
                        hit.fired = True
                        from datetime import datetime, timezone
                        hit.fired_at = datetime.now(timezone.utc)
                        self._retry_at.pop(key, None)
                    else:
                        self._retry_at[key] = time.time() + 180
                    continue
                if not hit.sell_pct_of_remaining or hit.rule == "notify10x":
                    jobs.append((
                        pos.user_id, pos.ca, pos.id, hit.id, 0.0, mult, hit.rule,
                    ))
                    continue
                jobs.append((
                    pos.user_id, pos.ca, pos.id, hit.id,
                    float(hit.sell_pct_of_remaining), mult, hit.rule,
                ))

        jobs.sort(key=lambda j: j[5])
        tps = [j for j in jobs if j[4] > 0 and j[6] != "sl"]
        stops = [j for j in jobs if j[6] == "sl"]
        notes = [j for j in jobs if j[4] <= 0]
        batch = []
        if tps:
            batch.append(max(tps, key=lambda j: j[5]))
        if stops:
            batch.append(min(stops, key=lambda j: j[5]))
        for uid, ca, pid, rid, pct, mult, rule_name in (batch + notes):
            key = (pid, rid)
            if rule_name == "notify10x" or pct <= 0:
                self._retry_at.pop(key, None)
                await self._mark_fired(uid, pid, rid, pct, mult, rule_name)
                continue
            result = await self._live_sell(uid, ca, pct, rule_name)
            if result == "empty":
                self._retry_at.pop(key, None)
                async with get_session() as s:
                    pos = await s.get(Position, pid)
                    if pos is not None and pos.tokens_open > 0:
                        pos.tokens_open = 0
                        pos.ladder_state = "dead"
                        pos.closed_at = datetime.now(timezone.utc)
                continue
            if result != "ok":
                n = self._fail_n.get(pid, 0) + 1
                self._fail_n[pid] = n
                # Two misses, then half an hour. A retry every few seconds
                # was paying a fee each time and emptying wallets.
                wait = 1800 if n >= 2 else 60
                self._retry_at[key] = time.time() + wait
                continue
            self._fail_n.pop(pid, None)
            self._retry_at.pop(key, None)
            await self._mark_fired(uid, pid, rid, pct, mult, rule_name)
            extra = self._also.pop(key, [])
            if extra:
                async with get_session() as s:
                    now_dt = datetime.now(timezone.utc)
                    for rule_id in extra:
                        rule = await s.get(ExitRule, rule_id)
                        if rule is not None:
                            rule.fired = True
                            rule.fired_at = now_dt

    async def _mark_usd(self, chain: str, ca: str, get_price_usd) -> float | None:
        cache = self.poller.get(chain, ca)
        now = time.time()
        if cache is not None and cache.price_usd > 0 and now - cache.ts < 4:
            return cache.price_usd
        key = (chain, ca)
        if now - self._fetched.get(key, 0) < 3:
            return cache.price_usd if cache and cache.price_usd > 0 else None
        self._fetched[key] = now
        px = await get_price_usd(ca, chain)
        if px and px > 0:
            self.poller.watch(chain, ca)
            entry = self.poller.get(chain, ca)
            if entry is not None:
                entry.price_usd = px
                entry.ts = now
            return px
        return cache.price_usd if cache and cache.price_usd > 0 else None

    async def _live_sell(self, uid: int, ca: str, pct: float, kind: str) -> str:
        if self.bot is None or pct <= 0:
            return "fail"
        from app.worker.executor import execute_sell
        try:
            order = await execute_sell(
                bot=self.bot, user_id=uid, ca=ca, pct=pct, kind=kind, quiet=True,
            )
        except Exception:
            log().exception("exit.sell_error", ca=ca[:8])
            return "fail"
        reason = (order.fail_reason or "").lower()
        if order.status in ("sent", "filled"):
            return "ok"
        if "no tokens" in reason:
            return "empty"
        return "fail"

    async def _mark_fired(self, uid: int, pid: int, rid: int, pct: float, mult: float, rule_name: str) -> None:
        from datetime import datetime, timezone

        tg = None
        ca = ""
        async with get_session() as s:
            user = await s.get(User, uid)
            pos = await s.get(Position, pid)
            if user is not None:
                tg = user.tg_id
            if pos is not None:
                ca = pos.ca
            if rid:
                rule = await s.get(ExitRule, rid)
                if rule is not None:
                    rule.fired = True
                    rule.fired_at = datetime.now(timezone.utc)
                    new_trail = tighten_trail_after(rule.rule)
                    if new_trail is not None:
                        trail = (
                            await s.execute(
                                select(ExitRule).where(
                                    ExitRule.position_id == pid, ExitRule.rule == "trail"
                                )
                            )
                        ).scalar_one_or_none()
                        if trail is not None:
                            trail.trail_pct = new_trail
        if tg:
            from app.worker.executor import sell_events
            got = cost = pnl = 0.0
            tx = ""
            closed = False
            async with get_session() as s:
                from sqlalchemy import func
                pos = await s.get(Position, pid)
                closed = pos is None or pos.tokens_open <= 1e-9
                events = [e for e in await sell_events(s, uid) if e["ca"] == ca]
                paid_fills = (
                    await s.execute(
                        select(func.coalesce(func.sum(func.abs(Fill.native_delta)), 0.0))
                        .join(Order, Order.id == Fill.order_id)
                        .where(
                            Order.user_id == uid,
                            Order.ca == ca,
                            Order.side == "buy",
                            Order.status.in_(("sent", "filled")),
                        )
                    )
                ).scalar_one()
                paid_quotes = (
                    await s.execute(
                        select(func.coalesce(func.sum(Order.quote_amount_native), 0.0)).where(
                            Order.user_id == uid,
                            Order.ca == ca,
                            Order.side == "buy",
                            Order.status.in_(("sent", "filled")),
                        )
                    )
                ).scalar_one()
            if closed and events:
                got = sum(e["got"] for e in events)
                cost = sum(e["cost"] for e in events)
                tx = events[-1]["tx"]
            elif events:
                got, cost, tx = events[-1]["got"], events[-1]["cost"], events[-1]["tx"]
            basis = 0.0
            if pos is not None:
                basis = float(pos.cost_basis_native or 0)
            basis = max(basis, float(paid_fills or 0), float(paid_quotes or 0))
            if basis > cost + 0.0001 and (closed or pct >= 0.99):
                cost = basis
            elif cost <= 0.0001 and basis > 0:
                cost = basis * max(0.0, min(1.0, pct))
            pnl = got - cost
            # A stop with no cost is not a win. Never print the SOL received as profit.
            if rule_name in ("sl", "trail") and cost <= 0.0001:
                pnl = -abs(got)
            mark = "🟢" if pnl >= 0 else "🔴"
            mult_real = (got / cost) if cost > 0 else 0.0
            if rule_name == "notify10x":
                title = "🚀 10× — the last part is still open"
            elif rule_name == "tp3x":
                title = "💸 3× — sold the ladder"
            elif rule_name == "tp15":
                title = "💸 1.5× — sold 40%"
            elif rule_name == "sl":
                title = "🛑 Stop sold everything"
            elif rule_name == "trail":
                title = "🛑 Trail stop sold the rest"
            elif cost > 0:
                title = f"💸 Sold · {mult_real:.2f}× on that slice"
            else:
                title = f"Sold {int(pct * 100)}%"
            extra = ""
            if rule_name != "notify10x":
                extra = (
                    f"Got {got:.4f} SOL\n"
                    f"Cost {cost:.4f} SOL\n"
                    f"{mark} PnL <b>{pnl:+.4f} SOL</b>\n"
                )
            link = f"https://solscan.io/tx/{tx}" if tx and len(tx) > 40 else ""
            name = ca[:6] + "…" + ca[-4:]
            try:
                from app.chain.prices import live_mark
                sym = ((await live_mark(ca)).get("sym") or "").strip()
                if sym:
                    name = sym
            except Exception:
                pass
            caption = f"<b>{title}</b>\n{name}\n{extra}<code>{ca[:6]}…{ca[-4:]}</code>\n{link}"
            try:
                from aiogram.types import BufferedInputFile
                from app.telegram.pnl_card import render_pnl_card
                png = render_pnl_card(name=name, multiple=mult_real, pnl_sol=pnl)
                if self.bot is not None:
                    await self.bot.send_photo(
                        tg, BufferedInputFile(png, filename="pnl.png"),
                        caption=caption, parse_mode="HTML",
                    )
                else:
                    await self._dm(tg, caption)
            except Exception:
                await self._dm(tg, caption)
        log().info("exit.fire", position_id=pid, rule=rule_name, mult=round(mult, 3))

    async def _ping(self, owner, pos: Position, mult: float) -> None:
        if owner is None or self.bot is None or mult <= 0:
            return
        pct = (mult - 1.0) * 100.0
        band = int(pct // 20)
        now = time.time()
        first = self._seen.setdefault(pos.id, now)
        # The price feed lies in the first minute after a fill. Stay quiet.
        if now - first < 90:
            self._band[pos.id] = band
            return
        if now - self._ping_at.get(pos.id, 0) < 180:
            return
        if pos.id not in self._band:
            self._band[pos.id] = band
            return
        if band == self._band[pos.id]:
            return
        self._band[pos.id] = band
        self._ping_at[pos.id] = now
        name = (pos.ticker or "").strip() or (pos.ca[:6] + "…" + pos.ca[-4:])
        mark = "🟢" if pct >= 0 else "🔴"
        await self._dm(owner.tg_id, f"{mark} <b>{name}</b>  {pct:+.0f}% from entry")

    def _hit(self, rule: ExitRule, mult: float, mark: float, pos: Position) -> bool:
        if rule.rule == "sl":
            return rule.trigger_mult is not None and mult <= rule.trigger_mult + 1e-9
        if rule.rule == "trail":
            hwm = pos.hwm_price_native or 0
            if hwm <= 0 or mult < 2:
                return False
            return (hwm - mark) / hwm >= (rule.trail_pct or 0.35)
        if rule.trigger_mult is None:
            return False
        return mult + 1e-9 >= rule.trigger_mult

    async def _fire(self, session, pos: Position, rule: ExitRule, mult: float) -> bool:
        from datetime import datetime, timezone

        user = await session.get(User, pos.user_id)
        if user is None or self.bot is None:
            return False
        if rule.rule == "notify10x" or not rule.sell_pct_of_remaining:
            rule.fired = True
            rule.fired_at = datetime.now(timezone.utc)
            await self._dm(
                user.tg_id,
                f"🚀 <b>{mult:.2f}x</b>  <code>{pos.ca[:8]}…</code>\nLast bag is still riding.",
            )
            return True

        pct = float(rule.sell_pct_of_remaining)
        if await self._paper(session, pos):
            ok = await self._paper_sell(session, pos, pct, mult, rule.rule)
        else:
            uid, ca = pos.user_id, pos.ca
            await session.flush()
            session.expire(pos)
            from app.worker.executor import execute_sell
            order = await execute_sell(
                bot=self.bot, user_id=uid, ca=ca, pct=pct, kind=rule.rule,
            )
            ok = order.status in ("sent", "filled")
        if not ok:
            return False
        rule.fired = True
        rule.fired_at = datetime.now(timezone.utc)
        session.add(rule)
        new_trail = tighten_trail_after(rule.rule)
        if new_trail is not None:
            trail = (
                await session.execute(
                    select(ExitRule).where(
                        ExitRule.position_id == pos.id, ExitRule.rule == "trail"
                    )
                )
            ).scalar_one_or_none()
            if trail is not None:
                trail.trail_pct = new_trail
        label = "STOP" if rule.rule == "sl" else rule.rule.upper()
        await self._dm(
            user.tg_id,
            f"{'🛑' if rule.rule == 'sl' else '💸'} <b>{label}</b> {int(pct * 100)}% at <b>{mult:.2f}x</b>\n"
            f"<code>{pos.ca[:8]}…</code>",
        )
        log().info("exit.fire", position_id=pos.id, rule=rule.rule, mult=round(mult, 3))
        return True

    async def _paper(self, session, pos: Position) -> bool:
        rows = (
            await session.execute(
                select(Order.kind).where(
                    Order.user_id == pos.user_id, Order.ca == pos.ca, Order.side == "buy"
                )
            )
        ).all()
        return bool(rows) and all(k == "paper" for (k,) in rows)

    async def _paper_sell(self, session, pos: Position, pct: float, mult: float, kind: str) -> bool:
        from datetime import datetime, timezone

        from app.db import Fill

        sell_tokens = pos.tokens_open * max(0.0, min(1.0, pct))
        if sell_tokens <= 0:
            return False
        proceeds = sell_tokens * pos.avg_entry_native * mult * 0.99
        order = Order(
            user_id=pos.user_id, side="sell", kind="paper", ca=pos.ca, chain=pos.chain,
            token_amount=sell_tokens, slippage_bps=0, status="filled", tx_sig="paper-exit",
        )
        session.add(order)
        await session.flush()
        session.add(Fill(
            order_id=order.id,
            price_native=pos.avg_entry_native * mult,
            native_delta=proceeds,
            token_delta=-sell_tokens,
            fee_native=proceeds * 0.01,
        ))
        pos.tokens_open -= sell_tokens
        if pos.tokens_open <= 1e-9:
            pos.tokens_open = 0.0
            pos.ladder_state = "closed"
            pos.closed_at = datetime.now(timezone.utc)
        log().info("exit.paper", ca=pos.ca[:8], rule=kind, mult=round(mult, 3))
        return True

    async def _dm(self, tg_id: int, text: str) -> None:
        if self.bot is None:
            return
        try:
            await self.bot.send_message(tg_id, text, parse_mode="HTML")
        except Exception:
            log().warning("exit.dm_fail", tg_id=tg_id)
