"""Per-user auto-buy executor.

Signal fan-out flow:
  1. A parsed Signal row lands in the DB (see ``signals/ingest_bot.py`` and
     ``signals/ingest_telethon.py``).
  2. ``fanout_signal(signal_id, bot)`` is called — it iterates all users who
     are (a) subscribed, (b) not paused, (c) below daily cap, (d) below
     ``max_open_autobuys`` for their preset, and (e) haven't hit the CA in
     the dedup window.
  3. For each eligible user, ``execute_buy`` decrypts the wallet key, calls
     Jupiter (SOL) or 0x (EVM), writes Order → Fill → Position → Lot →
     ExitRule rows, then DMs a receipt.

The executor is fail-safe: any failure is captured as an Order with
``status='failed'`` and a reason string, plus a user-visible receipt. Nothing
is silently dropped.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from aiogram import Bot
from sqlalchemy import and_, func, select

from app.chain import evm_swap, solana_jupiter
from app.chain.detect import detect_chain_and_pool
from app.chain.fees import send_sol_fee
from app.chain.prices import get_price_usd
from app.config import get_settings
from app.db import (
    ExitRule,
    Fill,
    Lot,
    Order,
    Position,
    Signal,
    Subscription,
    User,
    Wallet,
    get_session,
)
from app.logging_conf import log
from app.risk.ladder import build_ladder
from app.risk.presets import PRESETS
from app.risk.smart import apply_smart_override, compute_smart
from app.wallet.crypto import decrypt_key


# ─────────────────────────────────────────────────────────────────────────────
# Eligibility gates
# ─────────────────────────────────────────────────────────────────────────────

@dataclass(slots=True)
class GateResult:
    ok: bool
    reason: str = ""


async def _active_sub(session, user_id: int) -> bool:
    now = datetime.now(timezone.utc)
    rows = (
        await session.execute(
            select(Subscription).where(Subscription.user_id == user_id)
        )
    ).scalars().all()
    for row in rows:
        if row.status == "lifetime":
            return True
        exp = row.expires_at
        if exp is not None and exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if row.status in ("active", "trial") and exp is not None and exp > now:
            return True
    return False


async def _dedup_ok(session, user_id: int, ca: str, cooldown_min: int) -> bool:
    since = datetime.now(timezone.utc) - timedelta(minutes=cooldown_min)
    recent_pending = datetime.now(timezone.utc) - timedelta(minutes=3)
    hit = (
        await session.execute(
            select(Order.id).where(
                and_(
                    Order.user_id == user_id,
                    Order.ca == ca,
                    Order.side == "buy",
                    Order.status.in_(("sent", "filled")),
                    Order.created_at >= since,
                )
            )
        )
    ).first()
    if hit is not None:
        return False
    pending = (
        await session.execute(
            select(Order.id).where(
                and_(
                    Order.user_id == user_id,
                    Order.ca == ca,
                    Order.side == "buy",
                    Order.status == "pending",
                    Order.created_at >= recent_pending,
                )
            )
        )
    ).first()
    return pending is None


async def _open_autobuy_count(session, user_id: int) -> int:
    """Slots used by coins still worth at least $0.20.

    A coin with no price only keeps its slot for 20 minutes. Dust and
    bags the wallet no longer holds do not block the next buy.
    """
    rows = (
        await session.execute(
            select(
                Position.ca,
                Position.chain,
                Position.tokens_open,
                Position.cost_basis_native,
                Position.updated_at,
            ).where(
                and_(
                    Position.user_id == user_id,
                    Position.tokens_open > 0,
                    Position.closed_at.is_(None),
                    Position.ladder_state != "dead",
                )
            )
        )
    ).all()
    if not rows:
        return 0
    from app.chain.prices import live_mark, sol_price_usd
    from app.chain.solana_jupiter import wallet_mints

    sol = await sol_price_usd() or 0.0
    now = datetime.now(timezone.utc)
    holds: dict[str, float] | None = None
    wallet = await _wallet_for(session, user_id, "solana")
    if wallet is not None:
        try:
            found = await wallet_mints(wallet.address)
            if found is not None:
                holds = {mint: float(ui) for mint, ui in found}
        except Exception:
            holds = None

    async def _uses_slot(row) -> bool:
        updated = row.updated_at
        if updated is not None and updated.tzinfo is None:
            updated = updated.replace(tzinfo=timezone.utc)
        fresh = updated is not None and (now - updated).total_seconds() < 20 * 60
        cost = float(row.cost_basis_native or 0)
        if row.chain == "solana" and holds is not None and row.ca not in holds:
            return False
        ui = holds.get(row.ca) if holds is not None and row.ca in holds else None
        try:
            meta = await asyncio.wait_for(live_mark(row.ca), timeout=4)
        except Exception:
            meta = {}
        px = float((meta or {}).get("px") or 0)
        if ui and px > 0:
            return ui * px >= 0.20
        if ui and not px:
            return fresh and cost >= 0.0015
        if px > 0 and sol > 0 and cost > 0:
            return cost * sol >= 0.20
        return fresh and cost >= 0.0015

    flags = await asyncio.gather(*[_uses_slot(row) for row in rows], return_exceptions=True)
    return sum(1 for flag in flags if flag is True)


async def _daily_budget_left_usd(session, user: User) -> float:
    today = datetime.now(timezone.utc).date().isoformat()
    if user.daily_spent_date != today:
        user.daily_spent_usd = 0.0
        user.daily_spent_date = today
    cap = get_settings().DAILY_AUTOBUY_CAP_USD
    return max(0.0, cap - user.daily_spent_usd)


async def _wallet_for(session, user_id: int, chain: str) -> Optional[Wallet]:
    wallet_chain = "solana" if chain == "solana" else "evm"
    return (
        await session.execute(
            select(Wallet).where(
                and_(Wallet.user_id == user_id, Wallet.chain == wallet_chain)
            )
        )
    ).scalar_one_or_none()


async def _eligibility(session, user: User, ca: str) -> GateResult:
    if user.auto_paused:
        return GateResult(False, "paused")
    if not await _active_sub(session, user.id):
        return GateResult(False, "no_sub")
    s = get_settings()
    if not await _dedup_ok(session, user.id, ca, s.DUPLICATE_COOLDOWN_MIN):
        return GateResult(False, "dedup")
    preset = PRESETS[user.risk_preset]
    n_open = await _open_autobuy_count(session, user.id)
    if n_open >= preset.max_open_autobuys:
        return GateResult(False, f"max_open:{n_open}/{preset.max_open_autobuys}")
    return GateResult(True)


# ─────────────────────────────────────────────────────────────────────────────
# Buy execution
# ─────────────────────────────────────────────────────────────────────────────

async def _log_failure(session, user_id: int, ca: str, chain: str, reason: str) -> Order:
    o = Order(
        user_id=user_id, side="buy", kind="auto", ca=ca, chain=chain,
        slippage_bps=0, status="failed", fail_reason=reason,
    )
    session.add(o)
    await session.flush()
    return o


async def _attach_ladder(session, position: Position, preset_name: str,
                         user: User | None = None) -> None:
    # Pull per-user TP overrides when we have the User row; preset defaults
    # otherwise. Stop loss, trail, notify10x are not tunable.
    from app.risk.ladder import overrides_from_user
    overrides = overrides_from_user(user) if user is not None else None
    plan = build_ladder(preset_name, overrides=overrides)
    for rung in plan.rungs:
        session.add(
            ExitRule(
                position_id=position.id,
                rule=rung.rule,
                trigger_mult=rung.trigger_mult,
                sell_pct_of_remaining=rung.sell_pct_of_remaining,
                trail_pct=rung.trail_pct,
            )
        )


async def sell_events(session, user_id: int) -> list[dict]:
    """Each sell as SOL in, the cost of that slice, and PnL. Adds up to got − paid."""
    rows = (
        await session.execute(
            select(Order.ca, Order.side, Fill.native_delta, Fill.token_delta, Fill.ts, Order.tx_sig)
            .join(Fill, Fill.order_id == Order.id)
            .where(
                Order.user_id == user_id,
                Order.status.in_(("sent", "filled")),
            )
            .order_by(Fill.id)
        )
    ).all()
    books: dict[str, dict] = {}
    events: list[dict] = []
    for ca, side, native, tokens, ts, tx in rows:
        book = books.setdefault(ca, {"paid": 0.0, "buy_tok": 0.0, "sold_tok": 0.0, "left": 0.0})
        if side == "buy":
            paid = abs(float(native or 0))
            book["paid"] += paid
            book["buy_tok"] += abs(float(tokens or 0))
            book["left"] += paid
            continue
        got = max(0.0, float(native or 0))
        sold = abs(float(tokens or 0))
        left = book["left"]
        cost = 0.0
        if left > 0 and book["buy_tok"] > 0 and sold > 0:
            ratio = sold / book["buy_tok"]
            # Raw units and UI units must not wipe the cost. A nonsense
            # ratio means this sell is the rest of the bag.
            if 0.2 <= ratio <= 5:
                used = min(1.0, book["sold_tok"] / book["buy_tok"])
                frac = max(0.0, min(1.0 - used, min(1.0, ratio)))
                cost = min(left, book["paid"] * frac)
            else:
                cost = left
        elif left > 0:
            cost = left
        book["left"] = max(0.0, left - cost)
        book["sold_tok"] += sold
        events.append({
            "ca": ca, "ts": ts, "got": got, "cost": cost, "pnl": got - cost, "tx": tx or "",
        })
    return events


def _mc_txt(n: float) -> str:
    if n >= 1_000_000:
        return f"${n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"${n / 1_000:.1f}K"
    if n > 0:
        return f"${n:.0f}"
    return ""


def _fmt_receipt(*, chain: str, ca: str, spent_native: float, native_sym: str,
                 tokens_out: float, tx: str, preset: str, sym: str | None,
                 mc: float = 0.0) -> str:
    name = sym or f"{ca[:6]}…{ca[-4:]}"
    return f"Bought <b>{name}</b> · {spent_native:.4f} {native_sym}"


def _fmt_fail(*, ca: str, chain: str, reason: str) -> str:
    r = (reason or "").lower()
    if "does not exist" in r:
        plain = "That contract is not on Solana. The call address is wrong. Nothing was spent."
    elif "no_routes" in r or "no routes" in r or "not tradable" in r or "no market" in r or "no route" in r:
        plain = "No market yet after 4 tries. Nothing was spent."
    elif "429" in r or "rate limit" in r or "busy" in r:
        plain = "Tried 4 times. The market was still busy. Nothing was spent."
    elif "slippage" in r or "6004" in r or "did not land" in r:
        plain = "The price moved before the buy landed. Nothing was spent."
    elif "not_supported" in r or "restrict_intermediate" in r or "free tier" in r:
        plain = "No route on the free market API. Nothing was spent."
    elif "wallet too small" in r:
        plain = "Wallet is too small. A buy needs 0.01 SOL plus 0.012 SOL for fees."
    elif len(reason) > 140:
        plain = "The buy did not land. Nothing was spent."
    else:
        plain = reason
    short = ca if len(ca) < 16 else ca[:6] + "…" + ca[-4:]
    return (
        f"⚠️ <b>AUTO-BUY FAILED</b>\n"
        f"CA: <code>{short}</code>  ·  Chain: <b>{chain}</b>\n"
        f"{plain}\n"
        f"No funds moved."
    )


def _tx_link(chain: str, sig_or_hash: str) -> str:
    if chain == "solana":
        return f"https://solscan.io/tx/{sig_or_hash}"
    if chain == "base":
        return f"https://basescan.org/tx/{sig_or_hash}"
    if chain == "bsc":
        return f"https://bscscan.com/tx/{sig_or_hash}"
    if chain == "arbitrum":
        return f"https://arbiscan.io/tx/{sig_or_hash}"
    return f"https://etherscan.io/tx/{sig_or_hash}"


_buy_inflight: set[tuple[int, str]] = set()
_buy_retrying: set[tuple[int, str]] = set()
_note_at: dict[tuple, float] = {}
_fanout_slots: asyncio.Semaphore | None = None
_MAX_SLIP_BPS = 5000


def _slots() -> asyncio.Semaphore:
    global _fanout_slots
    if _fanout_slots is None:
        _fanout_slots = asyncio.Semaphore(8)
    return _fanout_slots


def _claim_buy(user_id: int, ca: str) -> bool:
    key = (user_id, ca)
    if key in _buy_inflight or key in _buy_retrying:
        return False
    _buy_inflight.add(key)
    return True


def _note_once(key: tuple, secs: float) -> bool:
    now = time.time()
    if now - _note_at.get(key, 0) < secs:
        return False
    _note_at[key] = now
    return True


def _dup_order(user_id: int, ca: str, chain: str, kind: str) -> Order:
    return Order(
        user_id=user_id, side="buy", kind=kind, ca=ca,
        chain=chain or "solana", slippage_bps=0,
        status="failed", fail_reason="already buying",
    )


async def execute_buy(
    *, bot: Bot, user_id: int, ca: str, chain_hint: str,
    signal_id: int | None = None, kind: str = "auto",
    override_amount_native: float | None = None,
    from_retry: bool = False,
    claimed: bool = False,
) -> Order:
    """One buy per user+CA at a time. A second channel does not double-spend."""
    owns = False
    if not from_retry and not claimed:
        if not _claim_buy(user_id, ca):
            return _dup_order(user_id, ca, chain_hint, kind)
        owns = True
    try:
        return await _execute_buy_inner(
            bot=bot, user_id=user_id, ca=ca, chain_hint=chain_hint,
            signal_id=signal_id, kind=kind,
            override_amount_native=override_amount_native,
            from_retry=from_retry,
        )
    finally:
        if owns and (user_id, ca) not in _buy_retrying:
            _buy_inflight.discard((user_id, ca))


async def _execute_buy_inner(
    *, bot: Bot, user_id: int, ca: str, chain_hint: str,
    signal_id: int | None = None, kind: str = "auto",
    override_amount_native: float | None = None,
    from_retry: bool = False,
) -> Order:
    """Run a buy. Always returns an Order row (filled or failed)."""
    async with get_session() as session:
        user = await session.get(User, user_id)
        if user is None:
            raise RuntimeError("user not found")
        if not await _active_sub(session, user.id):
            o = await _log_failure(session, user.id, ca, chain_hint or "solana", "no_sub")
            await _dm_safe(
                bot, user.tg_id,
                "Buy is off. Tap Free Trial or Subscribe.\n"
                "You can still sell. Open Positions.",
            )
            return o
        preset = PRESETS[user.risk_preset]

        # Detect the actual chain (EVM CAs may resolve to base/bsc/eth/arb).
        info = await detect_chain_and_pool(ca, chain_hint)
        chain = info.chain
        wallet = await _wallet_for(session, user.id, chain)
        if wallet is None:
            o = await _log_failure(session, user.id, ca, chain, "no_wallet_for_chain")
            await _dm_safe(bot, user.tg_id, _fmt_fail(ca=ca, chain=chain, reason="no_wallet_for_chain"))
            return o

        # Size in native token.
        amt_native = override_amount_native
        if amt_native is None:
            amt_native = (
                preset.sol_size_native if chain == "solana" else preset.evm_size_native
            )
        if override_amount_native is None and user.smart_mode:
            rec = await compute_smart(user.id, session)
            amt_native = apply_smart_override(rec.preset, rec.size_multiplier, chain)
        if override_amount_native is None and chain == "solana":
            # A 0.30 SOL wallet must not spend the 0.15 STANDARD default.
            # Cap at the preset percent of the wallet, and under 0.8 SOL
            # never exceed the SAFE size unless the user picked DEGEN.
            try:
                bal = (await solana_jupiter.sol_lamports(wallet.address)) / 1e9
            except Exception:
                bal = None
            if bal is not None:
                # Keep a little SOL for the fee and a later sell.
                # The 20% cap is for a full wallet. On a small wallet it
                # shrinks the buy under 0.01 and blocks every call.
                room = max(0.0, bal - 0.012)
                sized = min(amt_native, room)
                if bal >= 0.3:
                    sized = min(sized, bal * preset.max_pct_wallet)
                if user.risk_preset != "DEGEN" and bal < 0.8:
                    sized = min(sized, PRESETS["SAFE"].sol_size_native)
                if sized < 0.01 and room >= 0.01:
                    sized = 0.01
                if sized < 0.01:
                    o = await _log_failure(
                        session, user.id, ca, chain, f"wallet too small {bal:.4f}",
                    )
                    await _dm_safe(
                        bot, user.tg_id,
                        f"⚠️ <b>AUTO-BUY FAILED</b>\n"
                        f"Wallet has <b>{bal:.4f} SOL</b>.\n"
                        f"A buy needs 0.01 SOL plus 0.012 SOL for fees.\n"
                        f"No funds moved.",
                    )
                    return o
                amt_native = sized
        slippage_bps = (
            preset.slippage_bps_sol if chain == "solana" else preset.slippage_bps_evm
        )
        # Release the database before the swap. A sell must not block the next buy.
        await session.commit()

        # Platform fee — subtract before swap. Fee goes to treasury as a
        # separate on-chain transfer that fires alongside the swap.
        s_cfg = get_settings()
        fee_bps = s_cfg.FEE_BPS_BUY
        fee_amt = amt_native * (fee_bps / 10_000)
        swap_amt = amt_native - fee_amt
        # store both on the Order for audit


        order = Order(
            user_id=user.id, signal_id=signal_id, side="buy", kind=kind,
            ca=ca, chain=chain, quote_amount_native=swap_amt,
            slippage_bps=slippage_bps, status="pending",
        )
        session.add(order)
        await session.flush()
        await session.commit()

        # ── Solana path ──────────────────────────────────────────────────
        try:
            if chain == "solana":
                # Swap first. The fee is sent only after the tokens are in the wallet.
                amount_lamports = int(swap_amt * solana_jupiter.SOL_LAMPORTS)
                secret = decrypt_key(
                    wallet.encrypted_key, wallet.nonce, wallet.salt,
                    aad=wallet.address.encode(),
                )
                from app.chain.pump_portal import buy_solana
                from app.worker.deposit_watcher import quiet_wallet
                quiet_wallet(wallet.address)
                import asyncio
                try:
                    tx_sig, tokens_out = await asyncio.wait_for(
                        buy_solana(
                            ca=ca,
                            amount_lamports=amount_lamports,
                            slippage_bps=min(_MAX_SLIP_BPS, max(slippage_bps, 2500)),
                            user_pubkey=wallet.address,
                            secret_key=secret,
                            priority_fee=preset.priority_fee,
                        ),
                        timeout=18,
                    )
                except asyncio.TimeoutError as e:
                    raise RuntimeError("buy timeout") from e
                raw_held = 0
                held_ui = 0.0
                for _ in range(12):
                    bag = await solana_jupiter.spl_holding(wallet.address, ca)
                    if bag and bag[0] > 0:
                        raw_held = bag[0]
                        held_ui = bag[1]
                        break
                    await asyncio.sleep(0.8)
                if held_ui > 0:
                    tokens_out = held_ui
                elif raw_held <= 0:
                    raise RuntimeError("buy did not land in the wallet")
                if fee_amt > 0 and (s_cfg.FEE_TREASURY_SOL or s_cfg.OPERATOR_TREASURY_SOL):
                    fee_dest = s_cfg.FEE_TREASURY_SOL or s_cfg.OPERATOR_TREASURY_SOL
                    try:
                        secret_for_fee = decrypt_key(
                            wallet.encrypted_key, wallet.nonce, wallet.salt,
                            aad=wallet.address.encode(),
                        )
                        fee_sig = await send_sol_fee(
                            from_secret=secret_for_fee,
                            from_pubkey=wallet.address,
                            to_pubkey=fee_dest,
                            lamports=int(fee_amt * solana_jupiter.SOL_LAMPORTS),
                        )
                        log().info(
                            "fee.collected user=%s amt=%.6f dest=%s tx=%s",
                            user.tg_id, fee_amt, fee_dest[:8], fee_sig[:12] if fee_sig else "-"
                        )
                    except Exception as e:
                        log().warning("fee.send_fail user=%s err=%s", user.tg_id, str(e)[:80])
                price_native = amt_native / max(tokens_out, 1e-12)
                sym = info.symbol
                native_sym = "SOL"
            else:
                # ── EVM path ────────────────────────────────────────────
                from app.chain.bridge_sol import fund_evm_from_sol
                await session.commit()
                await fund_evm_from_sol(session, user.id, chain, wallet.address, amt_native)
                sell_wei = int(amt_native * 1e18)
                q_evm = await evm_swap.quote(
                    chain=chain,
                    sell_token=evm_swap.native_sentinel(),
                    buy_token=ca,
                    sell_amount=sell_wei,
                    taker=wallet.address,
                    slippage_bps=min(_MAX_SLIP_BPS, slippage_bps),
                )
                secret = decrypt_key(
                    wallet.encrypted_key, wallet.nonce, wallet.salt,
                    aad=wallet.address.encode(),
                )
                tx_sig = await asyncio.to_thread(
                    evm_swap.sign_and_send_native_buy,
                    chain=chain, quote_res=q_evm, private_key=secret,
                )
                tokens_out = q_evm.buy_amount / 1e18
                price_native = amt_native / max(tokens_out, 1e-12)
                sym = info.symbol
                native_sym = {"base": "ETH", "arbitrum": "ETH", "ethereum": "ETH", "bsc": "BNB"}.get(chain, "ETH")

            # Persist success
            order.status = "sent"
            order.tx_sig = tx_sig
            price_usd = info.price_usd
            fill = Fill(
                order_id=order.id,
                price_native=price_native,
                price_usd=price_usd,
                native_delta=-amt_native,
                token_delta=+tokens_out,
                fee_native=0.0,
            )
            session.add(fill)

            # Position + Lot
            pos = (
                await session.execute(
                    select(Position).where(
                        and_(Position.user_id == user.id, Position.ca == ca)
                    )
                )
            ).scalar_one_or_none()
            if pos is None:
                pos = Position(
                    user_id=user.id, ca=ca, chain=chain,
                    tokens_open=tokens_out,
                    avg_entry_native=price_native,
                    cost_basis_native=amt_native,
                    hwm_price_native=price_native,
                    ladder_state="active",
                )
                session.add(pos)
                await session.flush()
                await _attach_ladder(session, pos, user.risk_preset, user=user)
            else:
                total_cost = pos.cost_basis_native + amt_native
                total_tok = pos.tokens_open + tokens_out
                pos.avg_entry_native = total_cost / max(total_tok, 1e-12)
                pos.cost_basis_native = total_cost
                pos.tokens_open = total_tok

            session.add(
                Lot(
                    position_id=pos.id, tokens=tokens_out, cost_native=amt_native,
                )
            )

            # Daily cap accounting
            spent_usd = (price_usd or 0.0) * tokens_out if price_usd else 0.0
            if spent_usd <= 0 and info.price_usd:
                spent_usd = amt_native * info.price_usd
            user.daily_spent_usd += spent_usd

            log().info(
                "buy.ok", user=user.tg_id, chain=chain, ca=ca[:10],
                spent=amt_native, tokens=tokens_out, tx=tx_sig[:12],
            )
            mc = 0.0
            try:
                import asyncio
                from app.chain.prices import live_mark
                mark = await asyncio.wait_for(live_mark(ca), timeout=2)
                mc = float(mark.get("mc") or 0)
                if mc <= 0 and mark.get("px") and str(ca).lower().endswith("pump"):
                    mc = float(mark["px"]) * 1_000_000_000
                if not sym and mark.get("sym"):
                    sym = mark["sym"]
            except Exception:
                mc = 0.0
            await _dm_safe(
                bot, user.tg_id,
                _fmt_receipt(
                    chain=chain, ca=ca, spent_native=amt_native, native_sym=native_sym,
                    tokens_out=tokens_out, tx=tx_sig, preset=user.risk_preset, sym=sym,
                    mc=mc,
                ),
            )
            return order

        except Exception as e:
            reason = _short_reason(e)
            order.status = "failed"
            order.fail_reason = reason
            log().warning("buy.fail", user=user.tg_id, chain=chain, ca=ca[:10], reason=reason)
            if (
                kind == "auto"
                and not from_retry
                and _buy_retryable(reason)
                and (user.id, ca) not in _buy_retrying
            ):
                _buy_retrying.add((user.id, ca))
                import asyncio
                asyncio.create_task(_retry_buy(
                    bot, user.id, ca, chain, signal_id, kind,
                ))
                return order
            if chain == "solana":
                try:
                    bag = await solana_jupiter.spl_holding(wallet.address, ca)
                except Exception:
                    bag = None
                if bag and bag[1] > 0:
                    order.status = "sent"
                    await _say_landed(bot, user.id, ca, chain, bag[1])
                    return order
            if kind == "manual" and _note_once((user.id, ca, "fail"), 180):
                await _dm_safe(bot, user.tg_id, _fmt_fail(ca=ca, chain=chain, reason=reason))
            return order


def _buy_retryable(reason: str) -> bool:
    r = (reason or "").lower()
    if any(s in r for s in ("not enough", "wallet has", "skipped", "no_sub", "too small")):
        return False
    return any(s in r for s in (
        "429", "rate limit", "busy", "timeout", "timed out",
        "503", "502", "500", "unreachable", "blockhash",
        "slippage", "6004", "not confirmed", "did not land",
        "no route", "no market", "not tradable", "no routes",
    ))


async def _retry_buy(bot: Bot, user_id: int, ca: str, chain: str, signal_id: int | None, kind: str) -> None:
    """The first attempt hit a busy market. Try again. One message if it still fails."""
    import asyncio
    try:
        for delay in (8, 20):
            await asyncio.sleep(delay)
            async with get_session() as session:
                done = (
                    await session.execute(
                        select(Order.id).where(
                            and_(
                                Order.user_id == user_id,
                                Order.ca == ca,
                                Order.side == "buy",
                                Order.status.in_(("sent", "filled")),
                            )
                        )
                    )
                ).first()
                wallet = await _wallet_for(session, user_id, chain)
            if done is not None:
                return
            if wallet is not None and chain == "solana":
                try:
                    held = await solana_jupiter.spl_holding(wallet.address, ca)
                except Exception:
                    held = None
                if held and held[1] > 0:
                    await _say_landed(bot, user_id, ca, chain, held[1])
                    return
            order = await execute_buy(
                bot=bot, user_id=user_id, ca=ca, chain_hint=chain,
                signal_id=signal_id, kind=kind, from_retry=True,
            )
            if order.status in ("sent", "filled"):
                return
            if not _buy_retryable(order.fail_reason or ""):
                reason = order.fail_reason or "buy failed"
                break
        else:
            reason = "429 still busy after retries"
        log().info("buy.retry_done", user=user_id, ca=ca[:10], reason=reason)
    finally:
        _buy_retrying.discard((user_id, ca))
        _buy_inflight.discard((user_id, ca))


def _short_reason(e: BaseException) -> str:
    s = str(e).strip().splitlines()[0] if str(e).strip() else e.__class__.__name__
    return s[:200]


async def _say_landed(bot: Bot, user_id: int, ca: str, chain: str, tokens: float) -> None:
    """The swap landed after the bot had already called it a miss. Say so."""
    async with get_session() as session:
        user = await session.get(User, user_id)
        if user is None:
            return
        order = (
            await session.execute(
                select(Order)
                .where(
                    and_(
                        Order.user_id == user_id,
                        Order.ca == ca,
                        Order.side == "buy",
                    )
                )
                .order_by(Order.id.desc())
            )
        ).scalar_one_or_none()
        spent = float(order.quote_amount_native or 0) if order is not None else 0.0
        tx = (order.tx_sig or "") if order is not None else ""
        if order is not None and order.status not in ("sent", "filled"):
            order.status = "sent"
            if not order.tx_sig:
                order.tx_sig = "landed"
        tg = user.tg_id
        preset = user.risk_preset
    native = "SOL" if chain == "solana" else "ETH"
    await _dm_safe(
        bot, tg,
        _fmt_receipt(
            chain=chain, ca=ca, spent_native=spent, native_sym=native,
            tokens_out=tokens, tx=tx, preset=preset, sym=None,
        ),
    )


async def _dm_safe(bot: Bot, tg_id: int, text: str) -> None:
    try:
        await bot.send_message(tg_id, text, parse_mode="HTML", disable_web_page_preview=True)
    except Exception:
        log().warning("dm.fail", tg_id=tg_id)


# ─────────────────────────────────────────────────────────────────────────────
# Sell (manual %)
# ─────────────────────────────────────────────────────────────────────────────

_sell_lock: set[tuple[int, str]] = set()


async def execute_sell(
    *, bot: Bot, user_id: int, ca: str, pct: float,
    kind: str = "manual", quiet: bool = False,
) -> Order:
    async with get_session() as session:
        user = await session.get(User, user_id)
        pos = (
            await session.execute(
                select(Position).where(
                    and_(Position.user_id == user.id, Position.ca == ca)
                )
            )
        ).scalar_one_or_none()
        if pos is None or pos.tokens_open <= 0:
            o = Order(
                user_id=user.id, side="sell", kind=kind, ca=ca,
                chain="unknown", slippage_bps=0, status="failed",
                fail_reason="no_position",
            )
            session.add(o)
            return o
        if (user.id, ca) in _sell_lock:
            return Order(
                user_id=user.id, side="sell", kind=kind, ca=ca,
                chain=pos.chain, slippage_bps=0, status="failed",
                fail_reason="already selling",
            )
        _sell_lock.add((user.id, ca))

        preset = PRESETS[user.risk_preset]
        slippage = preset.slippage_bps_sol if pos.chain == "solana" else preset.slippage_bps_evm
        if kind in ("sl", "trail"):
            slippage = _MAX_SLIP_BPS
        else:
            slippage = min(_MAX_SLIP_BPS, max(slippage, 4000 if pos.chain == "solana" else slippage))
        sell_tokens = pos.tokens_open * max(0.0, min(1.0, pct))
        order = Order(
            user_id=user.id, side="sell", kind=kind, ca=ca, chain=pos.chain,
            token_amount=sell_tokens, slippage_bps=slippage, status="pending",
        )
        session.add(order)
        await session.flush()

        wallet = await _wallet_for(session, user.id, pos.chain)
        try:
            if pos.chain == "solana":
                # Sell what the wallet holds, not the guessed 6-decimal ledger.
                # Guessing high is Jupiter error 0x1788 (InsufficientFunds).
                held = await solana_jupiter.spl_raw_balance(wallet.address, ca)
                if held <= 0:
                    pos.tokens_open = 0
                    pos.ladder_state = "dead"
                    pos.closed_at = datetime.now(timezone.utc)
                    raise RuntimeError("no tokens in the wallet")
                # A position worth less than the fee must never be sent on-chain.
                # Retries of those sells burned a user's whole SOL balance.
                if kind != "manual":
                    try:
                        from app.chain.prices import get_price_usd, sol_price_usd
                        bag = await solana_jupiter.spl_holding(wallet.address, ca)
                        px = await get_price_usd(ca, "solana")
                        sol_usd = await sol_price_usd()
                        ui = bag[1] if bag else 0.0
                        if ui > 0 and px and sol_usd and sol_usd > 5:
                            worth = ui * px / sol_usd
                            if worth < 0.006:
                                pos.tokens_open = 0
                                pos.ladder_state = "dust"
                                pos.closed_at = datetime.now(timezone.utc)
                                raise RuntimeError("no tokens in the wallet")
                    except RuntimeError:
                        raise
                    except Exception:
                        pass
                frac = max(0.0, min(1.0, pct))
                amount_raw = int(held * frac * (0.995 if frac >= 0.99 else 1.0))
                if amount_raw <= 0:
                    amount_raw = held
                await session.commit()
                secret = decrypt_key(
                    wallet.encrypted_key, wallet.nonce, wallet.salt,
                    aad=wallet.address.encode(),
                )
                from app.chain.pump_portal import sell_solana
                from app.worker.deposit_watcher import quiet_wallet
                quiet_wallet(wallet.address)
                held_before = held
                sol_before = await solana_jupiter.sol_lamports(wallet.address)
                if sol_before < 400_000:
                    raise RuntimeError("wallet too small to pay the sell fee")
                tx_sig = ""
                native_out = 0.0
                last_sell: Exception | None = None
                for attempt in range(1):
                    try:
                        held_now = await solana_jupiter.spl_raw_balance(wallet.address, ca)
                        if attempt and (held_now <= 0 or held_now < held_before * 0.8):
                            tx_sig = tx_sig or "landed"
                            break
                        if held_now <= 0:
                            raise RuntimeError("no tokens in the wallet")
                        amount_raw = int(held_now * frac * (0.995 if frac >= 0.99 else 1.0)) or held_now
                        tx_sig, native_out = await sell_solana(
                            ca=ca,
                            pct=frac,
                            amount_raw=amount_raw,
                            slippage_bps=min(_MAX_SLIP_BPS, slippage),
                            user_pubkey=wallet.address,
                            secret_key=secret,
                        )
                        held_after = held_now
                        for _ in range(6):
                            await asyncio.sleep(0.8)
                            held_after = await solana_jupiter.spl_raw_balance(wallet.address, ca)
                            if held_after < held_now * 0.85:
                                break
                        if held_after > held_now * 0.8:
                            raise RuntimeError("sell did not land")
                        break
                    except Exception as sell_err:
                        last_sell = sell_err
                        if "no tokens" in str(sell_err).lower():
                            raise
                        await asyncio.sleep(1.2)
                else:
                    if last_sell:
                        raise last_sell
                now_sol = await solana_jupiter.sol_lamports(wallet.address)
                landed = (now_sol - sol_before) / 1e9
                if landed > 0.00001:
                    native_out = landed
                s_cfg = get_settings()
                fee_dest = s_cfg.FEE_TREASURY_SOL or s_cfg.OPERATOR_TREASURY_SOL
                fee_lamports = int(native_out * (s_cfg.FEE_BPS_SELL / 10_000) * solana_jupiter.SOL_LAMPORTS)
                fee_lamports = min(fee_lamports, int(0.005 * solana_jupiter.SOL_LAMPORTS))
                if fee_dest and fee_lamports > 5_000:
                    try:
                        await send_sol_fee(
                            from_secret=secret,
                            from_pubkey=wallet.address,
                            to_pubkey=fee_dest,
                            lamports=fee_lamports,
                        )
                    except Exception as fee_err:
                        log().warning("fee.sell_fail %s", str(fee_err)[:80])
            else:
                sell_amount_raw = int(sell_tokens * 1e18)
                q_evm = await evm_swap.quote(
                    chain=pos.chain,
                    sell_token=ca,
                    buy_token=evm_swap.native_sentinel(),
                    sell_amount=sell_amount_raw,
                    taker=wallet.address,
                    slippage_bps=min(_MAX_SLIP_BPS, slippage),
                )
                await session.commit()
                secret = decrypt_key(
                    wallet.encrypted_key, wallet.nonce, wallet.salt,
                    aad=wallet.address.encode(),
                )
                tx_sig = await asyncio.to_thread(
                    evm_swap.sign_and_send_native_buy,
                    chain=pos.chain, quote_res=q_evm, private_key=secret,
                )
                native_out = q_evm.buy_amount / 1e18

            order.status = "sent"
            order.tx_sig = tx_sig
            price_native = native_out / max(sell_tokens, 1e-12)
            session.add(
                Fill(
                    order_id=order.id, price_native=price_native,
                    native_delta=+native_out, token_delta=-sell_tokens,
                )
            )
            await session.flush()
            pos.tokens_open -= sell_tokens
            if pos.tokens_open <= 1e-12 or pct >= 0.99:
                pos.tokens_open = 0.0
                pos.ladder_state = "closed"
                pos.closed_at = datetime.now(timezone.utc)

            events = await sell_events(session, user.id)
            mine = [e for e in events if e["ca"] == ca]
            if pos.tokens_open <= 0 and mine:
                got = sum(e["got"] for e in mine)
                cost = sum(e["cost"] for e in mine)
                pnl = got - cost
            elif mine:
                got, cost, pnl = mine[-1]["got"], mine[-1]["cost"], mine[-1]["pnl"]
            else:
                got, cost, pnl = native_out, 0.0, native_out
            mark = "🟢" if pnl >= 0 else "🔴"
            if not quiet:
                await _dm_safe(
                    bot, user.tg_id,
                    f"💸 <b>Sold {int(pct*100)}%</b>\n"
                    f"Got {got:.4f} SOL\n"
                    f"Cost {cost:.4f} SOL\n"
                    f"{mark} PnL <b>{pnl:+.4f} SOL</b>\n"
                    f"{_tx_link(pos.chain, tx_sig)}",
                )
            return order
        except Exception as e:
            reason = _short_reason(e)
            order.status = "failed"
            order.fail_reason = reason
            if kind == "manual" and _sell_should_dm(user.id, ca, kind):
                await _dm_safe(bot, user.tg_id, f"⚠️ {_sell_plain(reason)}")
            return order
        finally:
            _sell_lock.discard((user.id, ca))


_sell_dm_at: dict[tuple, float] = {}


def _sell_plain(reason: str) -> str:
    r = (reason or "").lower()
    if "1788" in r or "insufficient" in r:
        return "Sell did not land: the wallet does not hold that many tokens. Nothing else was spent."
    if "no tokens" in r:
        return "No tokens in the wallet to sell."
    if "too small" in r or "sell fee" in r:
        return "Not enough SOL to pay the sell fee. Send a little SOL to the wallet."
    if "no route" in r or "not tradable" in r or "no market" in r:
        return "No buyers for this coin yet. Nothing was spent. It tries again on its own."
    if "1771" in r or "slippage" in r:
        return "Price moved too fast. Tap Sell 100% again."
    if "429" in r or "busy" in r:
        return "Jupiter is busy. Tap Sell 100% again in a few seconds."
    if "unreachable" in r:
        return "Jupiter is down. Nothing was spent."
    short = (reason or "").replace("\n", " ")[:90]
    return f"Sell did not land. Nothing else was spent. {short}"


def _sell_should_dm(user_id: int, ca: str, kind: str) -> bool:
    now = time.time()
    key = (user_id, ca)
    window = 30 if kind == "manual" else 600
    if now - _sell_dm_at.get(key, 0) < window:
        return False
    _sell_dm_at[key] = now
    return True


# ─────────────────────────────────────────────────────────────────────────────
# Fan-out
# ─────────────────────────────────────────────────────────────────────────────

async def fanout_signal(signal_id: int, bot: Bot, ca: str | None = None, chain: str | None = None) -> None:
    """For a parsed Signal row, fire an auto-buy for every eligible user."""
    async with get_session() as session:
        sig = await session.get(Signal, signal_id)
        if sig is None:
            return
        target = ca or sig.parsed_ca
        if not target:
            return
        hint = chain or sig.chain or "evm"
        users = (
            await session.execute(select(User).where(User.auto_paused == False))  # noqa: E712
        ).scalars().all()
        eligible: list[int] = []
        skipped: list[tuple[int, str]] = []
        for u in users:
            g = await _eligibility(session, u, target)
            if g.ok:
                eligible.append((u.id, u.tg_id))
            else:
                skipped.append((u.tg_id, g.reason))
                log().info("skip.user", user=u.tg_id, ca=target[:10], reason=g.reason)

    short = target[:6] + "…" + target[-4:]

    async def _tell_skip(tg_id: int, reason: str) -> None:
        if int(tg_id) != 1433775371:
            return
        plain = {
            "paused": "Auto-buy is paused.",
            "no_sub": "This account has no active sub.",
            "dedup": "That coin was already bought.",
            "daily_cap": "Daily buy cap is used.",
        }.get(reason, reason)
        if reason.startswith("max_open"):
            slots = reason.split(":", 1)[-1]
            plain = f"{slots} real slots are full. Coins under $0.20 do not count. Sell one, or post the CA again."
        try:
            await bot.send_message(tg_id, f"No buy for {short}.\n{plain}")
        except Exception:
            pass

    async def _one(uid: int, tg_id: int) -> None:
        async with _slots():
            if not _claim_buy(uid, target):
                return
            try:
                await execute_buy(
                    bot=bot, user_id=uid, ca=target,
                    chain_hint=hint, signal_id=signal_id, kind="auto",
                    claimed=True,
                )
            except Exception:
                log().exception("fanout.buy_error", user_id=uid, ca=target[:10])
            finally:
                if (uid, target) not in _buy_retrying:
                    _buy_inflight.discard((uid, target))

    await asyncio.gather(*[_tell_skip(tg, reason) for tg, reason in skipped])
    await asyncio.gather(*[_one(uid, tg) for uid, tg in eligible])
