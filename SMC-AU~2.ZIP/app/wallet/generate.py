"""Per-user wallet generation. Fresh keypair per user, per chain."""
from __future__ import annotations

from dataclasses import dataclass

import base58
from eth_account import Account
from solders.keypair import Keypair

# Enable HD account for later mnemonic-based derivation (documented but not
# currently used — every wallet is a fresh keypair to avoid mnemonic leaks).
Account.enable_unaudited_hdwallet_features()


@dataclass(slots=True)
class GeneratedWallet:
    chain: str        # solana | evm
    address: str
    private_key: bytes  # RAW bytes; caller MUST encrypt immediately


def generate_solana() -> GeneratedWallet:
    kp = Keypair()
    return GeneratedWallet(
        chain="solana",
        address=str(kp.pubkey()),
        private_key=bytes(kp),   # 64-byte secret (solders convention)
    )


def generate_evm() -> GeneratedWallet:
    acct = Account.create()
    return GeneratedWallet(
        chain="evm",
        address=acct.address,
        private_key=acct.key,     # 32-byte raw
    )


def solana_secret_to_b58(secret: bytes) -> str:
    """Convert 64-byte solders secret to Phantom-style base58 string.

    For user export ONLY — never store this string, and delete the message
    after ~60 seconds.
    """
    return base58.b58encode(secret).decode()
