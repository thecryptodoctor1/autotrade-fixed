"""AES-256-GCM encryption of private keys at rest.

Master key comes from ``WALLET_MASTER_KEY`` (base64, ≥32 bytes). We derive a
per-wallet data-encryption key via HKDF using a per-wallet salt so leaking one
row does not compromise others. Rotation is supported by tagging every
ciphertext with ``KEY_ROTATION_ID`` — a rotation script re-wraps records under
the new master key without changing the plaintext.

Keys are decrypted only in memory at sign time. Callers MUST zero the returned
bytes as soon as the transaction is signed.
"""
from __future__ import annotations

import base64
import os
from dataclasses import dataclass

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from app.config import get_settings

_KEY_LEN = 32
_NONCE_LEN = 12
_SALT_LEN = 16


class WalletCryptoError(RuntimeError):
    pass


def _master_bytes() -> bytes:
    raw = get_settings().WALLET_MASTER_KEY
    if not raw:
        raise WalletCryptoError("WALLET_MASTER_KEY missing")
    try:
        b = base64.b64decode(raw, validate=True)
    except Exception as e:
        raise WalletCryptoError(f"WALLET_MASTER_KEY not valid base64: {e}") from e
    if len(b) < 32:
        raise WalletCryptoError("WALLET_MASTER_KEY must decode to >= 32 bytes")
    return b


def _derive_dek(salt: bytes, info: bytes) -> bytes:
    hkdf = HKDF(algorithm=hashes.SHA256(), length=_KEY_LEN, salt=salt, info=info)
    return hkdf.derive(_master_bytes())


@dataclass(slots=True)
class Ciphertext:
    ct: bytes
    nonce: bytes
    salt: bytes
    rotation_id: str


def encrypt_key(private_key: bytes, *, aad: bytes = b"") -> Ciphertext:
    salt = os.urandom(_SALT_LEN)
    nonce = os.urandom(_NONCE_LEN)
    dek = _derive_dek(salt, info=b"smc-autotrade|wallet|" + aad)
    ct = AESGCM(dek).encrypt(nonce, private_key, aad)
    return Ciphertext(
        ct=ct, nonce=nonce, salt=salt, rotation_id=get_settings().KEY_ROTATION_ID
    )


def decrypt_key(
    ct: bytes, nonce: bytes, salt: bytes, *, aad: bytes = b""
) -> bytes:
    dek = _derive_dek(salt, info=b"smc-autotrade|wallet|" + aad)
    try:
        return AESGCM(dek).decrypt(nonce, ct, aad)
    except Exception as e:
        raise WalletCryptoError(f"decrypt failed: {e}") from e
