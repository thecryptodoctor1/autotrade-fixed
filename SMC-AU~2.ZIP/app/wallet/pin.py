"""PIN hashing with Argon2id + a server-side pepper."""
from __future__ import annotations

import base64

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

from app.config import get_settings

_hasher = PasswordHasher(time_cost=2, memory_cost=64 * 1024, parallelism=1)


def _peppered(pin: str) -> str:
    pepper = get_settings().PIN_PEPPER
    if not pepper:
        # A missing pepper is a config error, but we don't want to leak
        # differently between "no pepper" and "wrong pin" downstream.
        pepper = ""
    return f"{pepper}::{pin}"


def hash_pin(pin: str) -> str:
    return _hasher.hash(_peppered(pin))


def verify_pin(pin: str, hashed: str) -> bool:
    try:
        return _hasher.verify(hashed, _peppered(pin))
    except VerifyMismatchError:
        return False
    except Exception:
        return False


def check_pin_rules(pin: str) -> str | None:
    if not pin or not pin.isdigit():
        return "PIN must be 4–8 digits."
    if not (4 <= len(pin) <= 8):
        return "PIN must be 4–8 digits."
    return None


def gen_ref_code() -> str:
    """Short, URL-safe referral code."""
    import secrets

    return base64.urlsafe_b64encode(secrets.token_bytes(6)).decode().rstrip("=")
