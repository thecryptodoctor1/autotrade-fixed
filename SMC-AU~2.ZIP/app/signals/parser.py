"""Extract contract addresses from raw Telegram messages.

Rules:
  * EVM: ``^0x[a-fA-F0-9]{40}$`` (checksum ignored — pump/moon CAs are often lowercase).
  * Solana: base58, length 32..44, not on the ignore list, base58 decode-able.
  * Ignore command messages (leading ``/``) and pure-URL messages.
  * When multiple CAs are present, return the FIRST match.
  * The parser does not validate whether the token exists on-chain — that's
    a downstream chain-detect step.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

import base58

# Known non-token base58 strings we should ignore (system programs / vote /
# associated-token program etc.). Small hand-picked list — the actual chain
# detect step will filter anything else that isn't a real SPL mint.
_SOLANA_IGNORE = {
    "11111111111111111111111111111111",                          # system program
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",                # token program
    "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL",                # associated token
    "So11111111111111111111111111111111111111112",                # wrapped SOL
    "ComputeBudget111111111111111111111111111111",                # compute budget
}

_EVM_RE = re.compile(r"\b0x[a-fA-F0-9]{40}\b")
# base58 alphabet excludes 0, O, I, l -> 1-9 A-H J-N P-Z a-k m-z
_SOL_RE = re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{32,44}\b")


@dataclass(slots=True)
class ParsedSignal:
    ca: str
    chain: str  # "evm" | "solana"
    raw: str

    @property
    def dedup_key(self) -> str:
        return f"{self.chain}:{self.ca.lower()}"


def _is_valid_solana(s: str) -> bool:
    if s in _SOLANA_IGNORE:
        return False
    try:
        decoded = base58.b58decode(s)
    except Exception:
        return False
    return len(decoded) == 32


def parse_message(text: str) -> Optional[ParsedSignal]:
    """Return the first CA found, or None."""
    found = parse_all(text)
    return found[0] if found else None


def parse_all(text: str) -> list[ParsedSignal]:
    """Every contract in the message, in order. A call with two mints buys both."""
    if not text:
        return []
    out: list[ParsedSignal] = []
    seen: set[str] = set()
    for raw_line in text.strip().splitlines() or [text.strip()]:
        line = raw_line.strip()
        if not line:
            continue
        for m in _EVM_RE.findall(line):
            key = "evm:" + m.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append(ParsedSignal(ca=m, chain="evm", raw=line))
        for cand in _SOL_RE.findall(line):
            if not _is_valid_solana(cand):
                continue
            key = "solana:" + cand
            if key in seen:
                continue
            seen.add(key)
            out.append(ParsedSignal(ca=cand, chain="solana", raw=line))
        if len(out) >= 4:
            break
    return out
