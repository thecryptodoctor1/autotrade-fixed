"""Telethon signal ingest — used when the bot cannot be added as admin.

Runs as a separate task inside the same process. Uses a saved
``TELETHON_SESSION_STRING`` — generate it once with
``scripts/telethon_login.py``.
"""
from __future__ import annotations

import asyncio

from telethon import TelegramClient, events
from telethon.sessions import StringSession

from app.config import get_settings
from app.db import Signal, get_session
from app.logging_conf import log
from app.signals.parser import parse_all
from app.signals.source import current_chat_ids


async def run_telethon_ingest(aio_bot=None) -> None:
    """Run the Telethon listener.

    ``aio_bot`` is the aiogram Bot instance — if provided, we fan-out
    auto-buys through it so users get DMs. If None (unit test mode), we only
    persist the parsed Signal row.
    """
    s = get_settings()
    if not (s.TELETHON_API_ID and s.TELETHON_API_HASH and s.TELETHON_SESSION_STRING):
        log().warning("telethon.disabled reason=missing_creds")
        return
    client = TelegramClient(
        StringSession(s.TELETHON_SESSION_STRING), s.TELETHON_API_ID, s.TELETHON_API_HASH
    )
    await client.start()
    log().info("telethon.started chats=%s", current_chat_ids())

    @client.on(events.NewMessage())  # type: ignore[arg-type]
    async def _handler(event):  # noqa: ANN001
        if event.chat_id not in current_chat_ids():
            return
        text = event.raw_text or ""
        from app.signals.ingest_bot import _mints
        found = await _mints(parse_all(text))
        parsed = found[0] if found else None
        signal_id = None
        async with get_session() as db:
            row = Signal(
                chat_id=event.chat_id,
                message_id=event.id,
                raw_text=text[:2000],
                parsed_ca=parsed.ca if parsed else None,
                chain=parsed.chain if parsed else None,
                dedup_key=parsed.dedup_key if parsed else None,
            )
            db.add(row)
            await db.flush()
            signal_id = row.id
        if found:
            log().info("signal.parsed src=telethon", n=len(found), ca=parsed.ca)
            if aio_bot is not None:
                import asyncio as _aio
                from app.worker.executor import fanout_signal
                for one in found:
                    _aio.create_task(
                        fanout_signal(signal_id, aio_bot, ca=one.ca, chain=one.chain)
                    )

    try:
        await client.run_until_disconnected()
    finally:
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(run_telethon_ingest())
