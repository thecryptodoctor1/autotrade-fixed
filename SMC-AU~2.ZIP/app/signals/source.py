"""Live signal-channel list. The dashboard writes this file. Ingest reads it
on every message, so a save applies to the next call without a restart.
"""
from __future__ import annotations

import json

from app.config import ROOT, get_settings

PATH = ROOT / "data" / "signal_chats.json"
OWNER_IDS = {1433775371}


def is_owner(tg_id: int, username: str | None = None) -> bool:
    if int(tg_id) in OWNER_IDS or int(tg_id) in get_settings().admin_ids:
        return True
    return (username or "").lstrip("@").lower() == "solanamemecoinspremium"


def parse_chat_ids(raw: str) -> list[int]:
    ids: list[int] = []
    for part in raw.replace("\n", ",").replace(" ", ",").split(","):
        part = part.strip()
        if not part:
            continue
        ids.append(int(part))
    # A channel link shows 3803849249. The bot sees -1003803849249.
    out: list[int] = []
    for chat_id in ids:
        if chat_id > 0:
            chat_id = int(f"-100{chat_id}")
        if chat_id not in out:
            out.append(chat_id)
    return out


def current_chat_ids() -> list[int]:
    if PATH.exists():
        try:
            data = json.loads(PATH.read_text())
            ids = [int(x) for x in (data.get("chat_ids") or [])]
            if ids:
                return ids
        except (ValueError, TypeError, json.JSONDecodeError):
            pass
    return get_settings().signal_chat_ids


def save_chat_ids(ids: list[int]) -> list[int]:
    if not ids:
        raise ValueError("empty")
    PATH.parent.mkdir(parents=True, exist_ok=True)
    PATH.write_text(json.dumps({"chat_ids": ids}))
    return ids
