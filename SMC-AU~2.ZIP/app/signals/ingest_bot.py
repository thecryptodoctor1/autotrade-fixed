"""Bot API signal ingest — attach the bot as admin to the source group and
messages there flow through this router. On every parsed CA, kick off the
per-user auto-buy fan-out.
"""
from __future__ import annotations

import asyncio

from aiogram import Router
from aiogram.types import ChatMemberUpdated, Message
from sqlalchemy.exc import IntegrityError

from app.signals.source import current_chat_ids, is_owner, save_chat_ids
from app.db import Signal, get_session
from app.logging_conf import log
from app.signals.parser import parse_all

router = Router()
_told_wrong_chat: set[int] = set()


@router.my_chat_member()
async def on_bot_added(event: ChatMemberUpdated) -> None:
    """Owner adds the bot as admin: that channel becomes the buy source."""
    status = getattr(event.new_chat_member.status, "value", event.new_chat_member.status)
    status = str(status)
    if status not in ("administrator", "member", "creator"):
        return
    user = event.from_user
    chat = event.chat
    if user is None or chat.type not in ("channel", "group", "supergroup"):
        return
    if not is_owner(user.id, user.username):
        return
    title = chat.title or "that chat"
    if chat.type == "channel" and status == "member":
        await event.bot.send_message(
            user.id,
            f"I joined {title}, but I am not an admin.\n"
            "A channel does not send posts to members, so no buy can start.\n"
            "Open the channel, Administrators, Add admin, and pick this bot.\n"
            "Then post the CA one more time.",
        )
        return
    save_chat_ids([chat.id])
    await event.bot.send_message(
        user.id,
        f"Saved. Buys now come from {title}.\n"
        f"<code>{chat.id}</code>\n"
        "Post the CA there. The next one gets bought.",
        parse_mode="HTML",
    )


async def _mints(found):
    """Keep real token mints. A pool address in the same message is not a buy."""
    if len(found) <= 1:
        return found
    from app.chain.solana_jupiter import is_spl_mint
    kept = []
    for one in found:
        if one.chain != "solana":
            kept.append(one)
            continue
        kind = await is_spl_mint(one.ca)
        if kind is False:
            continue
        kept.append(one)
    return kept or found[:1]


async def on_group_msg(msg: Message) -> None:
    """Groups use message. Channels use channel_post. Both carry the CA."""
    try:
        await _on_signal(msg)
    except Exception as e:
        log().exception("signal.crash")
        try:
            await msg.bot.send_message(1433775371, f"Signal error: {type(e).__name__}: {e}"[:300])
        except Exception:
            pass


async def _on_signal(msg: Message) -> None:
    ids = current_chat_ids()
    text = msg.text or msg.caption or ""
    found_fast = parse_all(text) if text else []
    if msg.chat.id not in ids:
        if found_fast and msg.chat.id not in _told_wrong_chat:
            _told_wrong_chat.add(msg.chat.id)
            log().info("signal.ignored", chat=msg.chat.id, want=ids)
            title = msg.chat.title or "a chat"
            await msg.bot.send_message(
                1433775371,
                f"I saw a CA in {title}, but buys are set to {', '.join(str(i) for i in ids) or 'nothing'}.\n"
                f"Real id: <code>{msg.chat.id}</code>\n"
                f"Send /channel {msg.chat.id}",
                parse_mode="HTML",
            )
        return
    if not found_fast:
        return
    ca = found_fast[0].ca
    short = ca[:6] + "…" + ca[-4:]
    try:
        await msg.bot.send_message(1433775371, f"Saw {short}. Buying now.")
    except Exception:
        pass
    found = await _mints(found_fast)
    parsed = found[0] if found else None

    async with get_session() as db:
        row = Signal(
            chat_id=msg.chat.id,
            message_id=msg.message_id,
            raw_text=text[:2000],
            parsed_ca=parsed.ca if parsed else None,
            chain=parsed.chain if parsed else None,
            dedup_key=parsed.dedup_key if parsed else None,
        )
        db.add(row)
        try:
            await db.flush()
        except IntegrityError:
            await db.rollback()
            try:
                await msg.bot.send_message(1433775371, f"{short} was already read. Post a new message.")
            except Exception:
                pass
            return
        signal_id = row.id

    if found:
        log().info("signal.parsed src=bot_api", n=len(found), ca=parsed.ca)
        from app.worker.executor import fanout_signal
        for one in found:
            asyncio.create_task(fanout_signal(signal_id, msg.bot, ca=one.ca, chain=one.chain))


router.message.register(on_group_msg)
router.channel_post.register(on_group_msg)
