"""Token-based dashboard auth. Subscribers get an expert view.

Flow:
  1. User types /dashboard in bot
  2. Bot mints a HMAC-signed token containing (tg_id, expiry, sub_active)
  3. Bot DMs URL: https://dashboard.smc.io/?token=XYZ (or http://ip:8080/?token=XYZ)
  4. HTTP server verifies HMAC, checks sub, unlocks expert data
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass

from app.config import get_settings


TOKEN_TTL_SECS = 3600 * 24  # 24 hours


def _secret() -> bytes:
    # Reuse WALLET_MASTER_KEY as HMAC secret for simplicity
    raw = get_settings().WALLET_MASTER_KEY
    if raw:
        return base64.b64decode(raw)
    return b"dev-fallback-secret-do-not-use"


def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64url_dec(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


@dataclass(slots=True)
class TokenPayload:
    tg_id: int
    exp: int
    sub_active: bool


def mint_token(tg_id: int, sub_active: bool) -> str:
    payload = {"tg": tg_id, "exp": int(time.time()) + TOKEN_TTL_SECS, "sub": bool(sub_active)}
    body = _b64url(json.dumps(payload, separators=(",", ":")).encode())
    sig = hmac.new(_secret(), body.encode(), hashlib.sha256).digest()
    return f"{body}.{_b64url(sig)}"


def verify_token(token: str) -> TokenPayload | None:
    try:
        body_b64, sig_b64 = token.split(".", 1)
        expected = hmac.new(_secret(), body_b64.encode(), hashlib.sha256).digest()
        got = _b64url_dec(sig_b64)
        if not hmac.compare_digest(expected, got):
            return None
        payload = json.loads(_b64url_dec(body_b64))
        if int(payload.get("exp", 0)) < time.time():
            return None
        return TokenPayload(
            tg_id=int(payload["tg"]),
            exp=int(payload["exp"]),
            sub_active=bool(payload.get("sub", False)),
        )
    except Exception:
        return None
