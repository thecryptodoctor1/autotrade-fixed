"""Structured logging with structlog. No secrets — sensitive fields are dropped."""
from __future__ import annotations

import logging
import sys

import structlog

SENSITIVE = {"private_key", "seed", "mnemonic", "pin", "secret", "password"}


def _redact(_: object, __: str, event_dict: dict) -> dict:
    for k in list(event_dict):
        if k.lower() in SENSITIVE:
            event_dict[k] = "***"
    return event_dict


def configure_logging(level: str = "INFO", json: bool = True) -> None:
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, level.upper(), logging.INFO),
    )
    processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        _redact,
    ]
    if json:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper(), logging.INFO)
        ),
        cache_logger_on_first_use=True,
    )


def log():
    return structlog.get_logger()
