"""ORM models — no secrets stored in plaintext."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    tg_username: Mapped[Optional[str]] = mapped_column(String(64))
    username: Mapped[Optional[str]] = mapped_column(String(24), unique=True, index=True)
    trial_used: Mapped[bool] = mapped_column(Boolean, default=False)
    risk_preset: Mapped[str] = mapped_column(String(16), default="STANDARD")
    pin_hash: Mapped[Optional[str]] = mapped_column(String(255))
    auto_paused: Mapped[bool] = mapped_column(Boolean, default=False)
    withdraw_whitelist_sol: Mapped[Optional[str]] = mapped_column(String(64))
    withdraw_whitelist_evm: Mapped[Optional[str]] = mapped_column(String(64))
    ref_code: Mapped[str] = mapped_column(String(24), unique=True, index=True)
    referred_by_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    smart_mode: Mapped[bool] = mapped_column(Boolean, default=True)
    pin_fail_count: Mapped[int] = mapped_column(Integer, default=0)
    pin_locked_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    daily_spent_usd: Mapped[float] = mapped_column(Float, default=0.0)
    daily_spent_date: Mapped[Optional[str]] = mapped_column(String(10))  # YYYY-MM-DD
    # Per-user TP overrides. Null = fall back to the preset default from
    # app/risk/ladder.py:build_ladder. Users edit these on /dashboard.
    tp1_mult: Mapped[Optional[float]] = mapped_column(Float)
    tp1_pct:  Mapped[Optional[float]] = mapped_column(Float)
    tp2_mult: Mapped[Optional[float]] = mapped_column(Float)
    tp2_pct:  Mapped[Optional[float]] = mapped_column(Float)
    tp3_mult: Mapped[Optional[float]] = mapped_column(Float)
    tp3_pct:  Mapped[Optional[float]] = mapped_column(Float)
    tp4_mult: Mapped[Optional[float]] = mapped_column(Float)
    tp4_pct:  Mapped[Optional[float]] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    wallets: Mapped[list["Wallet"]] = relationship(back_populates="user")
    subscriptions: Mapped[list["Subscription"]] = relationship(back_populates="user")


class Wallet(Base):
    __tablename__ = "wallets"
    __table_args__ = (UniqueConstraint("user_id", "chain", name="uq_wallet_user_chain"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    chain: Mapped[str] = mapped_column(String(16))  # solana | evm
    address: Mapped[str] = mapped_column(String(64), index=True)
    encrypted_key: Mapped[bytes] = mapped_column()  # AES-GCM ciphertext
    salt: Mapped[bytes] = mapped_column()             # per-wallet salt (KDF input)
    nonce: Mapped[bytes] = mapped_column()            # GCM nonce
    key_rotation_id: Mapped[str] = mapped_column(String(16))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    user: Mapped["User"] = relationship(back_populates="wallets")


class Subscription(Base):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending|active|expired|trial|lifetime
    plan: Mapped[str] = mapped_column(String(16), default="monthly")     # monthly|lifetime|trial
    invoice_amount_lamports: Mapped[Optional[int]] = mapped_column(BigInteger)
    invoice_memo: Mapped[Optional[str]] = mapped_column(String(64))
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    paid_tx_sig: Mapped[Optional[str]] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    user: Mapped["User"] = relationship(back_populates="subscriptions")


class Referral(Base):
    __tablename__ = "referrals"

    id: Mapped[int] = mapped_column(primary_key=True)
    referrer_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    referee_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True, unique=True)
    invoices_credited: Mapped[int] = mapped_column(Integer, default=0)
    credit_days_earned: Mapped[int] = mapped_column(Integer, default=0)
    credit_days_applied: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class Signal(Base):
    __tablename__ = "signals"

    id: Mapped[int] = mapped_column(primary_key=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    message_id: Mapped[int] = mapped_column(BigInteger)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    raw_text: Mapped[str] = mapped_column(Text)
    parsed_ca: Mapped[Optional[str]] = mapped_column(String(64), index=True)
    chain: Mapped[Optional[str]] = mapped_column(String(16))
    dedup_key: Mapped[Optional[str]] = mapped_column(String(96), index=True)

    __table_args__ = (
        Index("ix_signal_chat_msg", "chat_id", "message_id", unique=True),
    )


class Order(Base):
    """Buy/sell intent + on-chain result."""

    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    signal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("signals.id"))
    side: Mapped[str] = mapped_column(String(8))                # buy | sell
    kind: Mapped[str] = mapped_column(String(16))               # auto|manual|ladder|sl|trigger
    ca: Mapped[str] = mapped_column(String(64), index=True)
    chain: Mapped[str] = mapped_column(String(16))
    quote_amount_native: Mapped[Optional[float]] = mapped_column(Float)   # SOL / ETH (buy side)
    token_amount: Mapped[Optional[float]] = mapped_column(Float)          # sell side
    slippage_bps: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(16), default="pending")    # pending|sent|filled|failed|cancelled
    tx_sig: Mapped[Optional[str]] = mapped_column(String(128))
    fail_reason: Mapped[Optional[str]] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)


class Fill(Base):
    __tablename__ = "fills"

    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    price_native: Mapped[float] = mapped_column(Float)      # native/token
    price_usd: Mapped[Optional[float]] = mapped_column(Float)
    native_delta: Mapped[float] = mapped_column(Float)      # signed native flow (+ inflow / − outflow)
    token_delta: Mapped[float] = mapped_column(Float)       # signed token flow
    fee_native: Mapped[float] = mapped_column(Float, default=0.0)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)


class Position(Base):
    __tablename__ = "positions"
    __table_args__ = (UniqueConstraint("user_id", "ca", name="uq_position_user_ca"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    ca: Mapped[str] = mapped_column(String(64), index=True)
    chain: Mapped[str] = mapped_column(String(16))
    ticker: Mapped[Optional[str]] = mapped_column(String(32))
    tokens_open: Mapped[float] = mapped_column(Float, default=0.0)
    avg_entry_native: Mapped[float] = mapped_column(Float, default=0.0)   # cost basis / token
    cost_basis_native: Mapped[float] = mapped_column(Float, default=0.0)  # total native spent
    hwm_price_native: Mapped[float] = mapped_column(Float, default=0.0)   # for trailing stop
    ladder_state: Mapped[str] = mapped_column(String(32), default="active")  # active|recovered|dead
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class Lot(Base):
    """FIFO cost-basis lots for realized/unrealized PnL."""

    __tablename__ = "lots"

    id: Mapped[int] = mapped_column(primary_key=True)
    position_id: Mapped[int] = mapped_column(ForeignKey("positions.id"), index=True)
    tokens: Mapped[float] = mapped_column(Float)
    cost_native: Mapped[float] = mapped_column(Float)
    opened_ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    closed_tokens: Mapped[float] = mapped_column(Float, default=0.0)
    realized_native: Mapped[float] = mapped_column(Float, default=0.0)


class ExitRule(Base):
    """Attached to a position — one row per ladder rung / SL / trailing setting."""

    __tablename__ = "exit_rules"

    id: Mapped[int] = mapped_column(primary_key=True)
    position_id: Mapped[int] = mapped_column(ForeignKey("positions.id"), index=True)
    rule: Mapped[str] = mapped_column(String(32))  # recover|tp3x|tp5x|notify10x|trail|sl|manual_limit
    trigger_mult: Mapped[Optional[float]] = mapped_column(Float)   # e.g. 2.0 for 2x
    trigger_price_native: Mapped[Optional[float]] = mapped_column(Float)  # explicit trigger
    sell_pct_of_remaining: Mapped[Optional[float]] = mapped_column(Float)  # 0..1
    trail_pct: Mapped[Optional[float]] = mapped_column(Float)              # 0..1
    fired: Mapped[bool] = mapped_column(Boolean, default=False)
    fired_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(64))
    meta: Mapped[Optional[str]] = mapped_column(Text)   # JSON; no secrets
