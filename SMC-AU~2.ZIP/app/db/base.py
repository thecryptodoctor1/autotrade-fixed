"""Async SQLAlchemy engine + session factory."""
from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from app.config import get_settings


class Base(DeclarativeBase):
    pass


_engine = None
_sessionmaker: async_sessionmaker[AsyncSession] | None = None


def get_engine():
    global _engine, _sessionmaker
    if _engine is None:
        url = get_settings().DATABASE_URL
        kwargs = {"future": True, "pool_pre_ping": True}
        if url.startswith("sqlite"):
            kwargs["connect_args"] = {"timeout": 30}
        _engine = create_async_engine(url, **kwargs)
        if url.startswith("sqlite"):
            from sqlalchemy import event

            @event.listens_for(_engine.sync_engine, "connect")
            def _sqlite_pragmas(dbapi_conn, _record):  # noqa: ANN001
                cur = dbapi_conn.cursor()
                cur.execute("PRAGMA journal_mode=WAL")
                cur.execute("PRAGMA busy_timeout=30000")
                cur.execute("PRAGMA synchronous=NORMAL")
                cur.close()

        _sessionmaker = async_sessionmaker(
            _engine, expire_on_commit=False, class_=AsyncSession
        )
    return _engine


@asynccontextmanager
async def get_session() -> AsyncIterator[AsyncSession]:
    get_engine()
    assert _sessionmaker is not None
    async with _sessionmaker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def create_all() -> None:
    engine = get_engine()
    from app.db import models  # noqa: F401 -- import models to register

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.run_sync(_sqlite_migrate)


def _sqlite_migrate(sync_conn) -> None:
    if sync_conn.dialect.name != "sqlite":
        return
    rows = sync_conn.exec_driver_sql("PRAGMA table_info(referrals)").fetchall()
    names = {row[1] for row in rows}
    if names and "credit_days_applied" not in names:
        sync_conn.exec_driver_sql(
            "ALTER TABLE referrals ADD COLUMN credit_days_applied INTEGER NOT NULL DEFAULT 0"
        )
    # Per-user ladder overrides. Nullable float columns, no default needed.
    urows = sync_conn.exec_driver_sql("PRAGMA table_info(users)").fetchall()
    unames = {row[1] for row in urows}
    for col in ("tp1_mult","tp1_pct","tp2_mult","tp2_pct","tp3_mult","tp3_pct","tp4_mult","tp4_pct"):
        if unames and col not in unames:
            sync_conn.exec_driver_sql(f"ALTER TABLE users ADD COLUMN {col} REAL")
