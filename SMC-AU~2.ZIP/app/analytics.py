"""Analytics engine: WR by timeframe + $100 ROI simulation + leaderboard.

Feeds:
  * /simulate Telegram command
  * /api/stats HTTP endpoint (for memesolana.com widget)
  * Weekly digest DMs
  * The frontend dashboard

ROI simulation logic:
  For each signal in the window, assume $100 was auto-bought at first_fdv
  and exited via the standard ladder (50% at 2x, 25% at 3x, 25% at 5x, trail
  on rest). Use each Position's actual hwm_price_native as the "actual" peak.
  If no Position exists for a signal, use 1.0x (broke even / lost trace).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import and_, func, select

from app.db import Position, Signal, Subscription, User, get_session


@dataclass(slots=True)
class WindowStats:
    label: str
    n_signals: int
    n_positions_traced: int
    wr_2x: float
    wr_5x: float
    wr_10x: float
    avg_peak_mult: float
    best_mult: float
    roi_pct_100usd: float          # % return simulating $100 spread across signals
    ending_value_100usd: float     # $ value of the $100 starting bankroll after applying ladder


@dataclass(slots=True)
class PlatformStats:
    users: int
    active_subs: int
    total_signals: int
    total_positions: int
    windows: dict[str, dict[str, Any]]   # keyed by "24h" / "7d" / "30d" / "all"
    top_runners: list[dict[str, Any]]    # top 10 by peak mult
    updated_at: str


def _chart_url(chain: str, ca: str) -> str:
    """Real chart link on DexScreener."""
    chain_map = {
        "solana": "solana",
        "base": "base",
        "bsc": "bsc",
        "ethereum": "ethereum",
        "arbitrum": "arbitrum",
    }
    c = chain_map.get(chain, chain)
    return f"https://dexscreener.com/{c}/{ca}"


def _ladder_return(peak_mult: float, fee_one_way: float = 0.035) -> float:
    """Simulate returning $1 through the standard ladder given the peak
    multiplier reached. Returns final $ balance."""
    if peak_mult <= 1.0:
        # Assume hit SL — lose 40%
        if peak_mult < 0.6:
            return 0.60
        return max(peak_mult * (1 - fee_one_way), 0.6)
    f = 1 - fee_one_way
    # Sell 50% at 2x
    cash = 0.5 * 2.0 * f
    remaining = 0.5
    if peak_mult >= 3.0:
        cash += 0.25 * remaining * 3.0 * f
        remaining *= 0.75
    if peak_mult >= 5.0:
        cash += 0.25 * remaining * 5.0 * f
        remaining *= 0.75
    # Trailing stop on rest — assume trail catches 60% of peak on average
    trail_capture = 0.6 if peak_mult >= 10 else 0.75
    cash += remaining * (peak_mult * trail_capture) * f
    return cash


async def compute_window(hours: int | None) -> WindowStats:
    """Compute stats for a time window. hours=None = all-time."""
    async with get_session() as s:
        q = select(Signal).where(Signal.parsed_ca.isnot(None))
        if hours is not None:
            since = datetime.now(timezone.utc) - timedelta(hours=hours)
            q = q.where(Signal.ts >= since)
        signals = (await s.execute(q.order_by(Signal.ts))).scalars().all()

        # Match each signal's CA to a Position (across users, take the best hit)
        positions = (
            await s.execute(select(Position).where(Position.avg_entry_native > 0))
        ).scalars().all()

    # index positions by CA to get best peak for each
    best_peak: dict[str, float] = {}
    for p in positions:
        if p.hwm_price_native > 0 and p.avg_entry_native > 0:
            mult = p.hwm_price_native / p.avg_entry_native
            k = p.ca.lower()
            if mult > best_peak.get(k, 0):
                best_peak[k] = mult

    n_sigs = len(signals)
    n_traced = 0
    peaks_matched = []
    for sig in signals:
        m = best_peak.get(sig.parsed_ca.lower() if sig.parsed_ca else "")
        if m:
            n_traced += 1
            peaks_matched.append(m)

    n_2x = sum(1 for m in peaks_matched if m >= 2)
    n_5x = sum(1 for m in peaks_matched if m >= 5)
    n_10x = sum(1 for m in peaks_matched if m >= 10)
    wr_2x = (n_2x / max(len(peaks_matched), 1)) if peaks_matched else 0.0
    wr_5x = (n_5x / max(len(peaks_matched), 1)) if peaks_matched else 0.0
    wr_10x = (n_10x / max(len(peaks_matched), 1)) if peaks_matched else 0.0
    avg_peak = sum(peaks_matched) / len(peaks_matched) if peaks_matched else 0.0
    best = max(peaks_matched) if peaks_matched else 0.0

    # $100 ROI simulation — $100 spread evenly, each fill returns per ladder
    if peaks_matched:
        alloc = 100.0 / len(peaks_matched)
        ending = sum(alloc * _ladder_return(m) for m in peaks_matched)
    else:
        ending = 100.0
    roi_pct = (ending - 100.0) / 100.0 * 100.0

    label = {24: "24h", 168: "7d", 720: "30d"}.get(hours or -1, "all")
    return WindowStats(
        label=label,
        n_signals=n_sigs,
        n_positions_traced=n_traced,
        wr_2x=wr_2x,
        wr_5x=wr_5x,
        wr_10x=wr_10x,
        avg_peak_mult=avg_peak,
        best_mult=best,
        roi_pct_100usd=roi_pct,
        ending_value_100usd=ending,
    )


async def top_runners(limit: int = 10, hours: int | None = 720) -> list[dict[str, Any]]:
    """Top peak multipliers in window — for leaderboard."""
    async with get_session() as s:
        q = select(Position).where(Position.avg_entry_native > 0)
        rows = (await s.execute(q)).scalars().all()
    scored = []
    for p in rows:
        if p.hwm_price_native <= 0 or p.avg_entry_native <= 0:
            continue
        mult = p.hwm_price_native / p.avg_entry_native
        scored.append({
            "ca": p.ca,
            "chain": p.chain,
            "ticker": p.ticker or p.ca[:6].upper(),
            "mult": round(mult, 2),
            "opened_at": p.updated_at.isoformat() if p.updated_at else None,
            "chart_url": _chart_url(p.chain, p.ca),
        })
    scored.sort(key=lambda x: x["mult"], reverse=True)
    return scored[:limit]


async def compute_platform_stats() -> PlatformStats:
    async with get_session() as s:
        n_users = (await s.execute(select(func.count(User.id)))).scalar_one() or 0
        n_subs = (
            await s.execute(
                select(func.count(Subscription.id)).where(Subscription.status == "active")
            )
        ).scalar_one() or 0
        n_sig = (
            await s.execute(select(func.count(Signal.id)).where(Signal.parsed_ca.isnot(None)))
        ).scalar_one() or 0
        n_pos = (await s.execute(select(func.count(Position.id)))).scalar_one() or 0

    windows = {}
    for hours, label in [(24, "24h"), (168, "7d"), (720, "30d"), (None, "all")]:
        w = await compute_window(hours)
        windows[label] = asdict(w)

    runners = await top_runners()

    return PlatformStats(
        users=n_users,
        active_subs=n_subs,
        total_signals=n_sig,
        total_positions=n_pos,
        windows=windows,
        top_runners=runners,
        updated_at=datetime.now(timezone.utc).isoformat(),
    )
