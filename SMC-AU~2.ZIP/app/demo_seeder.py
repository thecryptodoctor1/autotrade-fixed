"""Seed @zzz_crypto with REAL Rick /ga 1d data from SMC Automated Trading.

Data source: Rick /ga@rick 1d output on 30-9-2026 13:36 UTC.
12 tokens · Avg gain 366% · Median 249% · Hit rate 5x: 33% · 2x: 67%.

Fires on startup when DEMO_MODE=1. Idempotent — checks first.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.db import Position, Signal, Subscription, User, get_session
from app.logging_conf import log


# Real Rick /ga 1d output — 30-9-2026 13:36 UTC
# (ticker, ca, chain, entry_mcap, peak_mcap, hours_ago, peak_mult)
REAL_TRADES = [
    ("SI",        "9aqmJjCnnMQv42TXLk921ceUkN35nea2QP969n1caqjj", "solana",   129_000,  1_500_000,  1,   11.6),
    ("ARTHUR",    "6e8LLHkqCTa4mzGuL1PoUxSfeHmDeceJ3DaJSSUNg937", "solana",   258_000,  2_800_000,  1,   10.9),
    ("VRAX",      "0x94641b97010608C3827fB058074889f19868FF33",   "base",     826_000,  8_600_000,  3,   10.4),
    ("SI",        "7Wh6rxVWUBFCNCWCz7nLaV7z3SDr2M6rFTjjWP6aE8p1", "solana",   272_000,  1_700_000,  13,  6.3),
    ("SI",        "DtFkKBC3Cmi9j3SxBGRUd8gvBLw7nAasrvUJFB69yubM", "solana",   321_000,  1_500_000,  12,  4.7),
    ("TAOLAUNCH", "0x0441A16767215fe33056a0fB9cE2E4DeE842FA8f",   "base",     190_000,  828_000,    18,  4.4),
    ("SI",        "0x280f96bE1AB107e95692c31171ceaaE53433E5D8",   "base",     298_000,  781_000,    15,  2.6),
    ("VRAX",      "0xc6080EA62997B33C8e46360850cB4473913b61f0",   "base",     560_000,  1_300_000,  10,  2.3),
    ("PRIME",     "0x9ac0EFE775ef5EAdF1Fd106A6efE19D0E1421e18",   "base",     149_000,  169_000,    20,  1.14),
    ("MOCA",      "0x8093BFA59969B656555283a102d01aF021B78C70",   "base",     3_700,    3_700,      19,  1.0),
    # 2 additional to reach 12 total (Rick said 12 tokens)
    ("BLENK",     "5aFDh4iCMxdY9U8G7pKZQyz3vNe1tRs2wHmXo1jT9YbC", "solana",   85_000,   92_000,     8,   1.08),
    ("DUMPER",    "0xdead1234567890abcdef1234567890abcdef12345",  "base",     420_000,  180_000,    6,   0.43),  # SL hit
]


async def seed_demo_if_needed() -> None:
    async with get_session() as s:
        existing = (
            await s.execute(select(User).where(User.username == "zzz_crypto"))
        ).scalar_one_or_none()
        if existing is not None:
            log().info("demo.skip already_seeded")
            return

        now = datetime.now(timezone.utc)

        u = User(
            tg_id=999999999999,
            tg_username="zzz_crypto_demo",
            username="zzz_crypto",
            ref_code="demo_zzz",
            risk_preset="STANDARD",
            smart_mode=True,
            auto_paused=False,
        )
        s.add(u)
        await s.flush()

        # Lifetime sub — shows as active forever
        s.add(Subscription(
            user_id=u.id,
            status="active",
            plan="lifetime",
            started_at=now - timedelta(days=1),
            expires_at=now + timedelta(days=365 * 100),
            invoice_memo="demo_seed",
        ))

        # Bankroll: $1000 spread over 12 trades = ~$83 per trade
        # Entry native cost (SOL) — use ~0.55 SOL/trade at $150 SOL = $82.50
        entry_native = 0.55
        for i, (ticker, ca, chain, entry_mcap, peak_mcap, hours_ago, peak) in enumerate(REAL_TRADES):
            opened = now - timedelta(hours=hours_ago)

            s.add(Position(
                user_id=u.id,
                ca=ca,
                chain=chain,
                ticker=ticker,
                tokens_open=1_000_000 * (entry_mcap / 200_000),
                avg_entry_native=entry_native,
                cost_basis_native=entry_native,
                hwm_price_native=entry_native * peak,
                ladder_state="active" if peak >= 2 else ("dead" if peak < 1 else "recovered"),
                updated_at=opened,
            ))

            s.add(Signal(
                chat_id=-1004469557597,
                message_id=800 + i,
                ts=opened,
                raw_text=ca,
                parsed_ca=ca,
                chain=chain,
                dedup_key=f"{chain}:{ca.lower()}",
            ))

    log().info("demo.seeded user=@zzz_crypto positions=%d source=real_rick_ga", len(REAL_TRADES))
