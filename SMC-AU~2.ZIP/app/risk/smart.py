"""Data-driven SMART preset — recommend risk based on real signal outcomes."""
from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import func, select

from app.db import Fill, Order, Position, Signal, get_session
from app.risk.presets import PRESETS


@dataclass(slots=True)
class SmartRecommendation:
    preset: str
    reason: str
    size_multiplier: float
    wr_2x: float
    wr_5x: float
    avg_peak_mult: float
    n_signals: int
    n_positions: int


async def compute_smart(user_id: int | None = None, session=None) -> SmartRecommendation:
    async def _run(s) -> SmartRecommendation:
        n_signals = (
            await s.execute(select(func.count(Signal.id)).where(Signal.parsed_ca.isnot(None)))
        ).scalar_one() or 0

        pos_q = select(Position).where(Position.avg_entry_native > 0)
        if user_id is not None:
            pos_q = pos_q.where(Position.user_id == user_id)
        positions = (await s.execute(pos_q)).scalars().all()

        n_pos = len(positions)
        n_2x = 0
        n_5x = 0
        peaks = []
        for p in positions:
            if p.hwm_price_native <= 0:
                continue
            mult = p.hwm_price_native / p.avg_entry_native
            peaks.append(mult)
            if mult >= 2.0:
                n_2x += 1
            if mult >= 5.0:
                n_5x += 1
        wr_2x = n_2x / n_pos if n_pos else 0.0
        wr_5x = n_5x / n_pos if n_pos else 0.0
        avg_peak = sum(peaks) / len(peaks) if peaks else 0.0

        if n_pos < 5:
            return SmartRecommendation(
                preset="SAFE",
                reason="Fewer than 5 of your own trades. Size stays small until then.",
                size_multiplier=1.0,
                wr_2x=wr_2x,
                wr_5x=wr_5x,
                avg_peak_mult=avg_peak,
                n_signals=n_signals,
                n_positions=n_pos,
            )

        if wr_2x >= 0.55 and wr_5x >= 0.25:
            preset = "DEGEN"
            size_mult = min(1.2, 0.8 + wr_5x)
            reason = (
                f"Hot streak · {wr_2x*100:.0f}% hit 2x, {wr_5x*100:.0f}% hit 5x · size ×{size_mult:.2f}"
            )
        elif wr_2x >= 0.35:
            preset = "STANDARD"
            size_mult = 1.0
            reason = f"Balanced · {wr_2x*100:.0f}% hit 2x · standard sizing"
        else:
            preset = "SAFE"
            size_mult = max(0.5, wr_2x * 2)
            reason = (
                f"Choppy · only {wr_2x*100:.0f}% hit 2x · shrink size ×{size_mult:.2f}"
            )

        return SmartRecommendation(
            preset=preset,
            reason=reason,
            size_multiplier=size_mult,
            wr_2x=wr_2x,
            wr_5x=wr_5x,
            avg_peak_mult=avg_peak,
            n_signals=n_signals,
            n_positions=n_pos,
        )

    if session is not None:
        return await _run(session)
    async with get_session() as s:
        return await _run(s)


def apply_smart_override(preset_name: str, size_mult: float, chain: str) -> float:
    p = PRESETS[preset_name]
    base = p.sol_size_native if chain == "solana" else p.evm_size_native
    return base * max(0.1, min(2.0, size_mult))
