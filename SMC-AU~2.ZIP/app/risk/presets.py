"""Risk presets — exactly three, per product spec.

Amounts are stored per chain family (SOL native vs ETH-equivalent). The
executor converts the ETH-eq amount to the destination chain's native
using DexScreener at buy time; for MVP we just treat "ETH-eq" as the
number to send in the native token of the detected EVM chain.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True, slots=True)
class RiskPreset:
    name: Literal["SAFE", "STANDARD", "DEGEN"]
    sol_size_native: float          # SOL per buy
    evm_size_native: float          # ETH-equivalent per buy (native token on the picked EVM chain)
    max_open_autobuys: int
    max_pct_wallet: float           # 0..1
    slippage_bps_sol: int
    slippage_bps_evm: int
    priority_fee: Literal["low", "medium", "high"]
    hard_sl_pct: float              # 0..1 loss from entry


PRESETS: dict[str, RiskPreset] = {
    "SAFE": RiskPreset(
        name="SAFE",
        sol_size_native=0.05,
        evm_size_native=0.002,
        max_open_autobuys=4,
        max_pct_wallet=0.10,
        slippage_bps_sol=1200,
        slippage_bps_evm=800,
        priority_fee="low",
        hard_sl_pct=0.30,
    ),
    "STANDARD": RiskPreset(
        name="STANDARD",
        sol_size_native=0.15,
        evm_size_native=0.005,
        max_open_autobuys=8,
        max_pct_wallet=0.20,
        slippage_bps_sol=2000,
        slippage_bps_evm=1200,
        priority_fee="medium",
        hard_sl_pct=0.40,
    ),
    "DEGEN": RiskPreset(
        name="DEGEN",
        sol_size_native=0.40,
        evm_size_native=0.015,
        max_open_autobuys=15,
        max_pct_wallet=0.40,
        slippage_bps_sol=3500,
        slippage_bps_evm=2000,
        priority_fee="high",
        hard_sl_pct=0.50,
    ),
}
