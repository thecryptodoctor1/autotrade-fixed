"""Exit ladder — the product's edge.

Rules (per spec):
  1. Recover initials at 2x: sell 50% (or the fee-adjusted % that actually
     returns 100% of cost basis + fees). The remaining bag is "house money".
  2. Take 25% of the *remainder* at 3x.
  3. Take 25% of the *remainder after step 2* at 5x.
  4. Notify at 10x — no auto-sell.
  5. Trailing stop on the leftover, tightening as the position climbs:
     35% below HWM after 2x sold, 25% after 5x, 20% after 10x.
  6. Hard SL from ENTRY before 2x is hit — preset-defined (30/40/50%).
  7. Manual overrides always win.

Fee model: use ``fee_rate`` as the round-trip aggregator+priority-fee bite
(default 3.5% one-way = 7% round-trip). ``recover_pct_for_2x`` computes the
sell % that returns exactly the cost basis at 2x accounting for that bite.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from .presets import PRESETS, RiskPreset


@dataclass(slots=True)
class LadderRung:
    rule: Literal[
        "recover", "tp3x", "tp5x", "notify10x", "trail", "sl"
    ]
    trigger_mult: float | None
    sell_pct_of_remaining: float | None      # 0..1 of tokens still open at trigger time
    trail_pct: float | None = None


@dataclass(slots=True)
class LadderPlan:
    preset: str
    rungs: list[LadderRung] = field(default_factory=list)


def recover_pct_for_2x(fee_rate_one_way: float = 0.035) -> float:
    """Return the fraction of tokens to sell at 2x to recover cost basis + round-trip fees.

    Cost basis is 1 unit. At 2x the tokens are worth 2x their entry each. Selling
    fraction ``f`` yields ``2 * f * (1 - fee)`` net native. We want that ≥ 1 (plus
    the buy-side fee already paid, i.e. cost basis is 1/(1 - fee)).

    Solving f * 2 * (1 - fee) = 1 / (1 - fee)  →  f = 1 / (2 * (1 - fee) ** 2).
    Cap at 0.50 (the operator wants "sell half" as the human-readable default).
    """
    denom = 2 * (1 - fee_rate_one_way) ** 2
    if denom <= 0:
        return 0.5
    f = 1.0 / denom
    return min(max(f, 0.5), 0.75)   # clamp to [0.5, 0.75] — sane bounds


DEFAULT_TPS = (
    ("tp15",    1.5, 0.40),
    ("recover", 2.0, None),   # None => use recover_pct_for_2x(fee)
    ("tp3x",    3.0, 0.25),
    ("tp5x",    5.0, 0.25),
)


def _clamp_mult(v, lo, hi, default):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return default
    if v != v or v <= lo or v >= hi:
        return default
    return v


def _clamp_pct(v, default):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return default
    if v != v or v <= 0 or v >= 1:
        return default
    return v


def build_ladder(preset_name: str, *, fee_rate_one_way: float = 0.035,
                 overrides: dict | None = None) -> LadderPlan:
    """Preset ladder, optionally with per-user TP overrides.

    overrides keys (any subset): tp1_mult, tp1_pct, tp2_mult, tp2_pct,
                                 tp3_mult, tp3_pct, tp4_mult, tp4_pct.
    Null / invalid values fall back to the preset defaults. Multipliers are
    clamped > 1.0 and strictly ascending; percentages are clamped to (0, 1).
    Stop loss, trail, and notify10x are not user-tunable.
    """
    preset: RiskPreset = PRESETS[preset_name]
    recover_frac = recover_pct_for_2x(fee_rate_one_way)
    o = overrides or {}
    rules = []
    prev_mult = 1.0
    for i, (rule, def_mult, def_pct) in enumerate(DEFAULT_TPS, start=1):
        mult = _clamp_mult(o.get(f"tp{i}_mult"), prev_mult, 1000.0, def_mult)
        if mult <= prev_mult:
            mult = def_mult if def_mult > prev_mult else prev_mult + 0.1
        pct_in = o.get(f"tp{i}_pct")
        default_pct = recover_frac if (rule == "recover" and def_pct is None) else (def_pct or 0.25)
        pct = _clamp_pct(pct_in, default_pct)
        rules.append(LadderRung(rule=rule, trigger_mult=mult, sell_pct_of_remaining=pct))
        prev_mult = mult
    return LadderPlan(
        preset=preset_name,
        rungs=[
            LadderRung(rule="sl",        trigger_mult=1.0 - preset.hard_sl_pct,
                       sell_pct_of_remaining=1.0),
            *rules,
            LadderRung(rule="notify10x", trigger_mult=10.0, sell_pct_of_remaining=None),
            LadderRung(rule="trail",     trigger_mult=None, sell_pct_of_remaining=1.0,
                       trail_pct=0.35),
        ],
    )


def overrides_from_user(user) -> dict:
    """Pull the eight nullable TP columns off a User row. Missing attrs -> {}."""
    out = {}
    for k in ("tp1_mult","tp1_pct","tp2_mult","tp2_pct",
              "tp3_mult","tp3_pct","tp4_mult","tp4_pct"):
        v = getattr(user, k, None)
        if v is not None:
            out[k] = v
    return out


def tighten_trail_after(rule_fired: str) -> float | None:
    """New trail % after a ladder leg fires. None = no change."""
    if rule_fired == "recover":
        return 0.35
    if rule_fired == "tp5x":
        return 0.25
    if rule_fired == "notify10x":
        return 0.20
    return None
